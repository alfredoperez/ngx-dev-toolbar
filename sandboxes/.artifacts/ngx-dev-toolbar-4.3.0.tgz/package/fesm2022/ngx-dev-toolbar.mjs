import * as i0 from '@angular/core';
import { InjectionToken, Injectable, inject, signal, computed, input, output, ChangeDetectionStrategy, Component, ElementRef, model, viewChild, contentChild, effect, HostListener, DestroyRef, ViewContainerRef, ViewEncapsulation, makeEnvironmentProviders, ENVIRONMENT_INITIALIZER, ApplicationRef, EnvironmentInjector, createComponent, TemplateRef, Directive, contentChildren, ViewChild } from '@angular/core';
import { CommonModule, NgTemplateOutlet, DOCUMENT } from '@angular/common';
import { toSignal, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { BehaviorSubject, combineLatest, map, firstValueFrom, fromEvent } from 'rxjs';
import { filter, throttleTime } from 'rxjs/operators';
import * as i1$1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i2 from '@angular/cdk/menu';
import { CdkMenuModule } from '@angular/cdk/menu';
import * as i1 from '@angular/cdk/overlay';
import { OverlayModule, CdkConnectedOverlay } from '@angular/cdk/overlay';

/**
 * InjectionToken for the Toolbar configuration.
 *
 * Provided automatically by `provideToolbar(config)`.
 * Can be injected to access the toolbar configuration at runtime.
 */
const TOOLBAR_CONFIG = new InjectionToken('TOOLBAR_CONFIG');
/**
 * InjectionToken for the Feature Flags service.
 *
 * Use this token for tree-shakeable injection of the feature flags service.
 * When using dynamic imports, this token enables complete tree-shaking of
 * the toolbar in production builds.
 *
 * @example
 * ```typescript
 * // In your service
 * private devToolbar = inject(TOOLBAR_FEATURE_FLAGS, { optional: true });
 *
 * // Safe to call - no-op if toolbar is not provided
 * this.devToolbar?.setAvailableOptions(flags);
 * ```
 */
const TOOLBAR_FEATURE_FLAGS = new InjectionToken('TOOLBAR_FEATURE_FLAGS');
/**
 * InjectionToken for the Permissions service.
 *
 * Use this token for tree-shakeable injection of the permissions service.
 * When using dynamic imports, this token enables complete tree-shaking of
 * the toolbar in production builds.
 *
 * @example
 * ```typescript
 * // In your service
 * private devToolbar = inject(TOOLBAR_PERMISSIONS, { optional: true });
 *
 * // Safe to call - no-op if toolbar is not provided
 * this.devToolbar?.setAvailableOptions(permissions);
 * ```
 */
const TOOLBAR_PERMISSIONS = new InjectionToken('TOOLBAR_PERMISSIONS');
/**
 * InjectionToken for the App Features service.
 *
 * Use this token for tree-shakeable injection of the app features service.
 * When using dynamic imports, this token enables complete tree-shaking of
 * the toolbar in production builds.
 *
 * @example
 * ```typescript
 * // In your service
 * private devToolbar = inject(TOOLBAR_APP_FEATURES, { optional: true });
 *
 * // Safe to call - no-op if toolbar is not provided
 * this.devToolbar?.setAvailableOptions(features);
 * ```
 */
const TOOLBAR_APP_FEATURES = new InjectionToken('TOOLBAR_APP_FEATURES');
/**
 * InjectionToken for registering custom tool components with the toolbar.
 *
 * Custom tools are Angular components that extend the toolbar with app-specific
 * functionality. They are dynamically rendered inside the toolbar at runtime.
 *
 * Use `provideToolbarCustomTools()` to register custom tool components.
 *
 * @example
 * ```typescript
 * // app.config.ts
 * import { provideToolbar, provideToolbarCustomTools } from 'ngx-dev-toolbar';
 * import { MyCustomToolComponent } from './my-custom-tool.component';
 *
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideToolbar({ ... }),
 *     provideToolbarCustomTools(MyCustomToolComponent),
 *   ],
 * };
 * ```
 */
const TOOLBAR_CUSTOM_TOOLS = new InjectionToken('TOOLBAR_CUSTOM_TOOLS');

class ToolbarStorageService {
    constructor() {
        this.PREFIX = 'AngularToolbar.';
        this.TOOLS_KEY = `${this.PREFIX}keys`;
        this.SETTINGS_KEY = `${this.PREFIX}settings`;
    }
    set(key, value) {
        const toolKey = this.getToolKey(key);
        this.addToolKey(toolKey);
        localStorage.setItem(toolKey, JSON.stringify(value));
    }
    get(key) {
        const toolKey = this.getToolKey(key);
        const item = localStorage.getItem(toolKey);
        return item ? JSON.parse(item) : null;
    }
    remove(key) {
        const toolKey = this.getToolKey(key);
        localStorage.removeItem(toolKey);
        this.removeToolKey(toolKey);
    }
    getAllSettings() {
        const settings = {};
        const keys = this.getToolKeys();
        keys.forEach((key) => {
            const value = this.get(key);
            if (value !== null) {
                settings[key] = value;
            }
        });
        return settings;
    }
    setAllSettings(settings) {
        Object.entries(settings).forEach(([key, value]) => {
            this.set(key, value);
        });
    }
    clearAllSettings() {
        const keys = this.getToolKeys();
        keys.forEach((key) => {
            this.remove(key);
        });
    }
    getToolKeys() {
        return JSON.parse(localStorage.getItem(this.TOOLS_KEY) ?? '[]');
    }
    addToolKey(key) {
        const currentKeys = this.getToolKeys();
        if (currentKeys.includes(key)) {
            return;
        }
        currentKeys.push(key);
        localStorage.setItem(this.TOOLS_KEY, JSON.stringify(currentKeys));
    }
    removeToolKey(key) {
        const currentKeys = this.getToolKeys();
        const index = currentKeys.indexOf(key);
        if (index !== -1) {
            currentKeys.splice(index, 1);
        }
        localStorage.setItem(this.TOOLS_KEY, JSON.stringify(currentKeys));
    }
    getToolKey(key) {
        return key.includes(this.PREFIX) ? key : this.PREFIX + key;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStorageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStorageService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStorageService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const SETTINGS_KEY = 'settings';
class ToolbarStateService {
    constructor() {
        this.storageService = inject(ToolbarStorageService);
        // Initial state
        this.state = signal({
            isHidden: true,
            isCompletelyHidden: false,
            position: 'bottom',
            activeToolId: null,
            delay: 3000,
            error: null,
            theme: 'dark',
            config: {},
        });
        // Selectors
        this.isVisible = computed(() => !this.state().isHidden || this.hasActiveTool());
        this.isDarkTheme = computed(() => this.state().theme === 'dark');
        this.activeToolId = computed(() => this.state().activeToolId);
        this.hasActiveTool = computed(() => this.state().activeToolId !== null);
        this.error = computed(() => this.state().error);
        this.theme = computed(() => this.state().theme);
        this.delay = computed(() => this.state().delay);
        this.config = computed(() => this.state().config);
        this.isEnabled = computed(() => this.state().config.enabled ?? true);
        this.position = computed(() => this.state().position);
        this.isCompletelyHidden = computed(() => this.state().isCompletelyHidden);
        this.loadPersistedState();
    }
    // State updates
    setVisibility(isVisible) {
        if (isVisible) {
            this.state.update((state) => ({
                ...state,
                isHidden: false,
            }));
        }
        else {
            if (this.activeToolId() === null) {
                setTimeout(() => {
                    this.state.update((state) => ({
                        ...state,
                        isHidden: true,
                    }));
                }, this.state().delay);
            }
        }
    }
    setTheme(theme) {
        this.state.update((state) => ({
            ...state,
            theme,
        }));
    }
    setActiveTool(toolId) {
        this.state.update((state) => ({
            ...state,
            activeToolId: toolId,
        }));
        if (toolId === null) {
            this.setVisibility(false);
        }
        else {
            this.setVisibility(true);
        }
    }
    // Public actions
    toggleTool(toolId) {
        const currentToolId = this.activeToolId();
        this.setActiveTool(currentToolId === toolId ? null : toolId);
    }
    toggleVisibility() {
        this.state.update((state) => ({
            ...state,
            isHidden: !state.isHidden,
        }));
    }
    setConfig(config) {
        this.state.update((state) => ({
            ...state,
            config,
        }));
        // If config specifies a position, it takes priority
        if (config.position) {
            this.setPosition(config.position);
        }
    }
    setPosition(position) {
        // Close any active tool so its overlay doesn't stay in the old position
        this.setActiveTool(null);
        this.state.update((state) => ({
            ...state,
            position,
        }));
        this.persistState();
    }
    toggleCompletelyHidden() {
        this.state.update((state) => ({
            ...state,
            isCompletelyHidden: !state.isCompletelyHidden,
        }));
        this.persistState();
    }
    loadPersistedState() {
        try {
            const stored = this.storageService.get(SETTINGS_KEY);
            if (stored) {
                this.state.update((state) => ({
                    ...state,
                    position: stored.position ?? state.position,
                    isCompletelyHidden: stored.isCompletelyHidden ?? state.isCompletelyHidden,
                }));
            }
        }
        catch {
            // Corrupted localStorage data — use defaults
        }
    }
    persistState() {
        const current = this.storageService.get(SETTINGS_KEY) ?? {};
        this.storageService.set(SETTINGS_KEY, {
            ...current,
            position: this.state().position,
            isCompletelyHidden: this.state().isCompletelyHidden,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStateService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStateService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/**
 * Collapsible group header that wraps a section of list items.
 *
 * Renders a clickable header with the group name + item count + a chevron
 * indicating collapsed/expanded state. Children projected via `<ng-content>`
 * are hidden when collapsed.
 *
 * @example
 * ```html
 * <ndt-list-group
 *   name="Authentication"
 *   [count]="3"
 *   [collapsed]="isCollapsed"
 *   (collapsedChange)="onToggle($event)"
 * >
 *   <ndt-list-item ... />
 * </ndt-list-group>
 * ```
 */
class ToolbarListGroupComponent {
    constructor() {
        /** Display name of the group, shown in the header. */
        this.name = input.required();
        /** Number of items in the group, shown next to the name. */
        this.count = input.required();
        /** Whether the group is currently collapsed. */
        this.collapsed = input(false);
        /** Emits the new collapsed value when the user clicks the header. */
        this.collapsedChange = output();
        this.ariaLabel = computed(() => `${this.collapsed() ? 'Expand' : 'Collapse'} ${this.name()} group, ${this.count()} items`);
    }
    toggle() {
        this.collapsedChange.emit(!this.collapsed());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarListGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarListGroupComponent, isStandalone: true, selector: "ndt-list-group", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, count: { classPropertyName: "count", publicName: "count", isSignal: true, isRequired: true, transformFunction: null }, collapsed: { classPropertyName: "collapsed", publicName: "collapsed", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { collapsedChange: "collapsedChange" }, ngImport: i0, template: `
    <button
      type="button"
      class="header"
      [attr.aria-expanded]="!collapsed()"
      [attr.aria-label]="ariaLabel()"
      (click)="toggle()"
    >
      <span class="chevron" [class.chevron--expanded]="!collapsed()" aria-hidden="true"></span>
      <span class="name">{{ name() }}</span>
      <span class="count" aria-hidden="true">{{ count() }}</span>
    </button>
    @if (!collapsed()) {
      <div class="content">
        <ng-content />
      </div>
    }
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);flex-shrink:0}.header{display:flex;align-items:center;gap:var(--ndt-spacing-xs);width:100%;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);background:transparent;border:none;border-radius:var(--ndt-border-radius-small);color:var(--ndt-text-secondary);font-family:inherit;font-size:var(--ndt-font-size-xs);font-weight:600;text-transform:uppercase;letter-spacing:.04em;cursor:pointer;text-align:left;transition:background-color .16s ease-out,color .16s ease-out}.header:hover{background:var(--ndt-background-secondary);color:var(--ndt-text-primary)}.header:focus-visible{outline:2px solid var(--ndt-accent, var(--ndt-text-primary));outline-offset:2px}.chevron{flex:0 0 auto;display:inline-block;width:0;height:0;border-top:4px solid transparent;border-bottom:4px solid transparent;border-left:5px solid currentColor;transition:transform .18s cubic-bezier(.22,1,.36,1)}.chevron--expanded{transform:rotate(90deg)}@media (prefers-reduced-motion: reduce){.chevron{transition:none}}.name{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.count{flex:0 0 auto;font-variant-numeric:tabular-nums;font-weight:500;color:var(--ndt-text-muted)}.content{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarListGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-list-group', standalone: true, template: `
    <button
      type="button"
      class="header"
      [attr.aria-expanded]="!collapsed()"
      [attr.aria-label]="ariaLabel()"
      (click)="toggle()"
    >
      <span class="chevron" [class.chevron--expanded]="!collapsed()" aria-hidden="true"></span>
      <span class="name">{{ name() }}</span>
      <span class="count" aria-hidden="true">{{ count() }}</span>
    </button>
    @if (!collapsed()) {
      <div class="content">
        <ng-content />
      </div>
    }
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);flex-shrink:0}.header{display:flex;align-items:center;gap:var(--ndt-spacing-xs);width:100%;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);background:transparent;border:none;border-radius:var(--ndt-border-radius-small);color:var(--ndt-text-secondary);font-family:inherit;font-size:var(--ndt-font-size-xs);font-weight:600;text-transform:uppercase;letter-spacing:.04em;cursor:pointer;text-align:left;transition:background-color .16s ease-out,color .16s ease-out}.header:hover{background:var(--ndt-background-secondary);color:var(--ndt-text-primary)}.header:focus-visible{outline:2px solid var(--ndt-accent, var(--ndt-text-primary));outline-offset:2px}.chevron{flex:0 0 auto;display:inline-block;width:0;height:0;border-top:4px solid transparent;border-bottom:4px solid transparent;border-left:5px solid currentColor;transition:transform .18s cubic-bezier(.22,1,.36,1)}.chevron--expanded{transform:rotate(90deg)}@media (prefers-reduced-motion: reduce){.chevron{transition:none}}.name{flex:1 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.count{flex:0 0 auto;font-variant-numeric:tabular-nums;font-weight:500;color:var(--ndt-text-muted)}.content{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs)}\n"] }]
        }] });

class AngularIconComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: AngularIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.0.7", type: AngularIconComponent, isStandalone: true, selector: "ndt-angular-icon", ngImport: i0, template: `
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <defs>
        <linearGradient
          id="angular-gradient"
          x1="6"
          x2="18"
          y1="20"
          y2="4"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0" stop-color="#E40035" />
          <stop offset=".24" stop-color="#F60A48" />
          <stop offset=".352" stop-color="#F20755" />
          <stop offset=".494" stop-color="#DC087D" />
          <stop offset=".745" stop-color="#9717E7" />
          <stop offset="1" stop-color="#6C00F5" />
        </linearGradient>
      </defs>
      <g fill="url(#angular-gradient)">
        <polygon points="14.1,2.7 20.1,15.7 20.7,5.8" />
        <polygon points="15.6,16.4 8.4,16.4 7.4,18.6 12,21.2 16.6,18.6" />
        <polygon points="9.6,13.5 14.4,13.5 12,7.7" />
        <polygon points="9.9,2.7 3.3,5.8 3.9,15.7" />
      </g>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: AngularIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-angular-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <defs>
        <linearGradient
          id="angular-gradient"
          x1="6"
          x2="18"
          y1="20"
          y2="4"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0" stop-color="#E40035" />
          <stop offset=".24" stop-color="#F60A48" />
          <stop offset=".352" stop-color="#F20755" />
          <stop offset=".494" stop-color="#DC087D" />
          <stop offset=".745" stop-color="#9717E7" />
          <stop offset="1" stop-color="#6C00F5" />
        </linearGradient>
      </defs>
      <g fill="url(#angular-gradient)">
        <polygon points="14.1,2.7 20.1,15.7 20.7,5.8" />
        <polygon points="15.6,16.4 8.4,16.4 7.4,18.6 12,21.2 16.6,18.6" />
        <polygon points="9.6,13.5 14.4,13.5 12,7.7" />
        <polygon points="9.9,2.7 3.3,5.8 3.9,15.7" />
      </g>
    </svg>
  `,
                }]
        }] });

class BoltIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: BoltIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: BoltIconComponent, isStandalone: true, selector: "ndt-bolt-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M160,16,144,96H208l-96,144,16-80H64Z"
        opacity="0.2"
      ></path>
      <path
        d="M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7l-112,120a8,8,0,0,0,3,13l57.63,21.61L88.16,238.43a8,8,0,0,0,13.69,7l112-120A8,8,0,0,0,215.79,118.17ZM109.37,214l10.47-52.38a8,8,0,0,0-5-9.06L62,132.71l84.62-90.66L136.16,94.43a8,8,0,0,0,5,9.06l52.8,19.8Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: BoltIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-bolt-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M160,16,144,96H208l-96,144,16-80H64Z"
        opacity="0.2"
      ></path>
      <path
        d="M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7l-112,120a8,8,0,0,0,3,13l57.63,21.61L88.16,238.43a8,8,0,0,0,13.69,7l112-120A8,8,0,0,0,215.79,118.17ZM109.37,214l10.47-52.38a8,8,0,0,0-5-9.06L62,132.71l84.62-90.66L136.16,94.43a8,8,0,0,0,5,9.06l52.8,19.8Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class BugIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: BugIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: BugIconComponent, isStandalone: true, selector: "ndt-bug-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M140,88a16,16,0,1,1,16,16A16,16,0,0,1,140,88ZM100,72a16,16,0,1,0,16,16A16,16,0,0,0,100,72Zm120,72a91.84,91.84,0,0,1-2.34,20.64L236.81,173a12,12,0,0,1-9.62,22l-18-7.85a92,92,0,0,1-162.46,0l-18,7.85a12,12,0,1,1-9.62-22l19.15-8.36A91.84,91.84,0,0,1,36,144v-4H16a12,12,0,0,1,0-24H36v-4a91.84,91.84,0,0,1,2.34-20.64L19.19,83a12,12,0,0,1,9.62-22l18,7.85a92,92,0,0,1,162.46,0l18-7.85a12,12,0,1,1,9.62,22l-19.15,8.36A91.84,91.84,0,0,1,220,112v4h20a12,12,0,0,1,0,24H220ZM60,116H196v-4a68,68,0,0,0-136,0Zm56,94.92V140H60v4A68.1,68.1,0,0,0,116,210.92ZM196,144v-4H140v70.92A68.1,68.1,0,0,0,196,144Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: BugIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-bug-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M140,88a16,16,0,1,1,16,16A16,16,0,0,1,140,88ZM100,72a16,16,0,1,0,16,16A16,16,0,0,0,100,72Zm120,72a91.84,91.84,0,0,1-2.34,20.64L236.81,173a12,12,0,0,1-9.62,22l-18-7.85a92,92,0,0,1-162.46,0l-18,7.85a12,12,0,1,1-9.62-22l19.15-8.36A91.84,91.84,0,0,1,36,144v-4H16a12,12,0,0,1,0-24H36v-4a91.84,91.84,0,0,1,2.34-20.64L19.19,83a12,12,0,0,1,9.62-22l18,7.85a92,92,0,0,1,162.46,0l18-7.85a12,12,0,1,1,9.62,22l-19.15,8.36A91.84,91.84,0,0,1,220,112v4h20a12,12,0,0,1,0,24H220ZM60,116H196v-4a68,68,0,0,0-136,0Zm56,94.92V140H60v4A68.1,68.1,0,0,0,116,210.92ZM196,144v-4H140v70.92A68.1,68.1,0,0,0,196,144Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class CodeIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: CodeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: CodeIconComponent, isStandalone: true, selector: "ndt-code-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path d="M240,128l-48,40H64L16,128,64,88H192Z" opacity="0.2"></path>
      <path
        d="M69.12,94.15,28.5,128l40.62,33.85a8,8,0,1,1-10.24,12.29l-48-40a8,8,0,0,1,0-12.29l48-40a8,8,0,0,1,10.24,12.3Zm176,27.7-48-40a8,8,0,1,0-10.24,12.3L227.5,128l-40.62,33.85a8,8,0,1,0,10.24,12.29l48-40a8,8,0,0,0,0-12.29ZM162.73,32.48a8,8,0,0,0-10.25,4.79l-64,176a8,8,0,0,0,4.79,10.26A8.14,8.14,0,0,0,96,224a8,8,0,0,0,7.52-5.27l64-176A8,8,0,0,0,162.73,32.48Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: CodeIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-code-icon',
                    standalone: true,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path d="M240,128l-48,40H64L16,128,64,88H192Z" opacity="0.2"></path>
      <path
        d="M69.12,94.15,28.5,128l40.62,33.85a8,8,0,1,1-10.24,12.29l-48-40a8,8,0,0,1,0-12.29l48-40a8,8,0,0,1,10.24,12.3Zm176,27.7-48-40a8,8,0,1,0-10.24,12.3L227.5,128l-40.62,33.85a8,8,0,1,0,10.24,12.29l48-40a8,8,0,0,0,0-12.29ZM162.73,32.48a8,8,0,0,0-10.25,4.79l-64,176a8,8,0,0,0,4.79,10.26A8.14,8.14,0,0,0,96,224a8,8,0,0,0,7.52-5.27l64-176A8,8,0,0,0,162.73,32.48Z"
      ></path>
    </svg>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });

class DatabaseIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: DatabaseIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: DatabaseIconComponent, isStandalone: true, selector: "ndt-database-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M216,80c0,26.51-39.4,48-88,48S40,106.51,40,80s39.4-48,88-48S216,53.49,216,80Z"
        opacity="0.2"
      ></path>
      <path
        d="M128,24C74.17,24,32,48.6,32,80v96c0,31.4,42.17,56,96,56s96-24.6,96-56V80C224,48.6,181.83,24,128,24Zm80,104c0,9.62-7.88,19.43-21.61,26.92C170.93,163.35,150.19,168,128,168s-42.93-4.65-58.39-13.08C55.88,147.43,48,137.62,48,128V111.36c17.06,15,46.23,24.64,80,24.64s62.94-9.68,80-24.64ZM69.61,53.08C85.07,44.65,105.81,40,128,40s42.93,4.65,58.39,13.08C200.12,60.57,208,70.38,208,80s-7.88,19.43-21.61,26.92C170.93,115.35,150.19,120,128,120s-42.93-4.65-58.39-13.08C55.88,99.43,48,89.62,48,80S55.88,60.57,69.61,53.08ZM186.39,202.92C170.93,211.35,150.19,216,128,216s-42.93-4.65-58.39-13.08C55.88,195.43,48,185.62,48,176V159.36c17.06,15,46.23,24.64,80,24.64s62.94-9.68,80-24.64V176C208,185.62,200.12,195.43,186.39,202.92Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: DatabaseIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-database-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M216,80c0,26.51-39.4,48-88,48S40,106.51,40,80s39.4-48,88-48S216,53.49,216,80Z"
        opacity="0.2"
      ></path>
      <path
        d="M128,24C74.17,24,32,48.6,32,80v96c0,31.4,42.17,56,96,56s96-24.6,96-56V80C224,48.6,181.83,24,128,24Zm80,104c0,9.62-7.88,19.43-21.61,26.92C170.93,163.35,150.19,168,128,168s-42.93-4.65-58.39-13.08C55.88,147.43,48,137.62,48,128V111.36c17.06,15,46.23,24.64,80,24.64s62.94-9.68,80-24.64ZM69.61,53.08C85.07,44.65,105.81,40,128,40s42.93,4.65,58.39,13.08C200.12,60.57,208,70.38,208,80s-7.88,19.43-21.61,26.92C170.93,115.35,150.19,120,128,120s-42.93-4.65-58.39-13.08C55.88,99.43,48,89.62,48,80S55.88,60.57,69.61,53.08ZM186.39,202.92C170.93,211.35,150.19,216,128,216s-42.93-4.65-58.39-13.08C55.88,195.43,48,185.62,48,176V159.36c17.06,15,46.23,24.64,80,24.64s62.94-9.68,80-24.64V176C208,185.62,200.12,195.43,186.39,202.92Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class DiscordIconComponent {
    constructor() {
        this.fill = input('#000000');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: DiscordIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: DiscordIconComponent, isStandalone: true, selector: "ndt-discord-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M104,140a12,12,0,1,1-12-12A12,12,0,0,1,104,140Zm60-12a12,12,0,1,0,12,12A12,12,0,0,0,164,128Zm74.45,64.9-67,29.71a16.17,16.17,0,0,1-21.71-9.1l-8.11-22q-6.72.45-13.63.46t-13.63-.46l-8.11,22a16.18,16.18,0,0,1-21.71,9.1l-67-29.71a15.93,15.93,0,0,1-9.06-18.51L38,58A16.07,16.07,0,0,1,51,46.14l36.06-5.93a16.22,16.22,0,0,1,18.26,11.88l3.26,12.84Q118.11,64,128,64t19.4.93l3.26-12.84a16.21,16.21,0,0,1,18.26-11.88L205,46.14A16.07,16.07,0,0,1,218,58l29.53,116.38A15.93,15.93,0,0,1,238.45,192.9ZM232,178.28,202.47,62s0,0-.08,0L166.33,56a.17.17,0,0,0-.17,0l-2.83,11.14c5,.94,10,2.06,14.83,3.42A8,8,0,0,1,176,86.31a8.09,8.09,0,0,1-2.16-.3A172.25,172.25,0,0,0,128,80a172.25,172.25,0,0,0-45.84,6,8,8,0,1,1-4.32-15.4c4.82-1.36,9.78-2.48,14.82-3.42L89.83,56s0,0-.12,0h0L53.61,61.93a.17.17,0,0,0-.09,0L24,178.33,91,208a.23.23,0,0,0,.22,0L98,189.72a173.2,173.2,0,0,1-20.14-4.32A8,8,0,0,1,82.16,170,171.85,171.85,0,0,0,128,176a171.85,171.85,0,0,0,45.84-6,8,8,0,0,1,4.32,15.41A173.2,173.2,0,0,1,158,189.72L164.75,208a.22.22,0,0,0,.21,0Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: DiscordIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-discord-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M104,140a12,12,0,1,1-12-12A12,12,0,0,1,104,140Zm60-12a12,12,0,1,0,12,12A12,12,0,0,0,164,128Zm74.45,64.9-67,29.71a16.17,16.17,0,0,1-21.71-9.1l-8.11-22q-6.72.45-13.63.46t-13.63-.46l-8.11,22a16.18,16.18,0,0,1-21.71,9.1l-67-29.71a15.93,15.93,0,0,1-9.06-18.51L38,58A16.07,16.07,0,0,1,51,46.14l36.06-5.93a16.22,16.22,0,0,1,18.26,11.88l3.26,12.84Q118.11,64,128,64t19.4.93l3.26-12.84a16.21,16.21,0,0,1,18.26-11.88L205,46.14A16.07,16.07,0,0,1,218,58l29.53,116.38A15.93,15.93,0,0,1,238.45,192.9ZM232,178.28,202.47,62s0,0-.08,0L166.33,56a.17.17,0,0,0-.17,0l-2.83,11.14c5,.94,10,2.06,14.83,3.42A8,8,0,0,1,176,86.31a8.09,8.09,0,0,1-2.16-.3A172.25,172.25,0,0,0,128,80a172.25,172.25,0,0,0-45.84,6,8,8,0,1,1-4.32-15.4c4.82-1.36,9.78-2.48,14.82-3.42L89.83,56s0,0-.12,0h0L53.61,61.93a.17.17,0,0,0-.09,0L24,178.33,91,208a.23.23,0,0,0,.22,0L98,189.72a173.2,173.2,0,0,1-20.14-4.32A8,8,0,0,1,82.16,170,171.85,171.85,0,0,0,128,176a171.85,171.85,0,0,0,45.84-6,8,8,0,0,1,4.32,15.41A173.2,173.2,0,0,1,158,189.72L164.75,208a.22.22,0,0,0,.21,0Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class DocsIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: DocsIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: DocsIconComponent, isStandalone: true, selector: "ndt-docs-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M213.66,66.34l-40-40A8,8,0,0,0,168,24H88A16,16,0,0,0,72,40V56H56A16,16,0,0,0,40,72V216a16,16,0,0,0,16,16H168a16,16,0,0,0,16-16V200h16a16,16,0,0,0,16-16V72A8,8,0,0,0,213.66,66.34ZM168,216H56V72h76.69L168,107.31v84.53c0,.06,0,.11,0,.16s0,.1,0,.16V216Zm32-32H184V104a8,8,0,0,0-2.34-5.66l-40-40A8,8,0,0,0,136,56H88V40h76.69L200,75.31Zm-56-32a8,8,0,0,1-8,8H88a8,8,0,0,1,0-16h48A8,8,0,0,1,144,152Zm0,32a8,8,0,0,1-8,8H88a8,8,0,0,1,0-16h48A8,8,0,0,1,144,184Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: DocsIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-docs-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M213.66,66.34l-40-40A8,8,0,0,0,168,24H88A16,16,0,0,0,72,40V56H56A16,16,0,0,0,40,72V216a16,16,0,0,0,16,16H168a16,16,0,0,0,16-16V200h16a16,16,0,0,0,16-16V72A8,8,0,0,0,213.66,66.34ZM168,216H56V72h76.69L168,107.31v84.53c0,.06,0,.11,0,.16s0,.1,0,.16V216Zm32-32H184V104a8,8,0,0,0-2.34-5.66l-40-40A8,8,0,0,0,136,56H88V40h76.69L200,75.31Zm-56-32a8,8,0,0,1-8,8H88a8,8,0,0,1,0-16h48A8,8,0,0,1,144,152Zm0,32a8,8,0,0,1-8,8H88a8,8,0,0,1,0-16h48A8,8,0,0,1,144,184Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class EditIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: EditIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: EditIconComponent, isStandalone: true, selector: "ndt-edit-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M221.66,90.34,192,120,136,64l29.66-29.66a8,8,0,0,1,11.31,0L221.66,79A8,8,0,0,1,221.66,90.34Z"
        opacity="0.2"
      ></path>
      <path
        d="M227.31,73.37,182.63,28.68a16,16,0,0,0-22.63,0L36.69,152A15.86,15.86,0,0,0,32,163.31V208a16,16,0,0,0,16,16H92.69A15.86,15.86,0,0,0,104,219.31L227.31,96a16,16,0,0,0,0-22.63ZM92.69,208H48V163.31l88-88L180.69,120ZM192,108.68,147.31,64l24-24L216,84.68Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: EditIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-edit-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M221.66,90.34,192,120,136,64l29.66-29.66a8,8,0,0,1,11.31,0L221.66,79A8,8,0,0,1,221.66,90.34Z"
        opacity="0.2"
      ></path>
      <path
        d="M227.31,73.37,182.63,28.68a16,16,0,0,0-22.63,0L36.69,152A15.86,15.86,0,0,0,32,163.31V208a16,16,0,0,0,16,16H92.69A15.86,15.86,0,0,0,104,219.31L227.31,96a16,16,0,0,0,0-22.63ZM92.69,208H48V163.31l88-88L180.69,120ZM192,108.68,147.31,64l24-24L216,84.68Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class ExportIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ExportIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: ExportIconComponent, isStandalone: true, selector: "ndt-export-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M216,112v96a16,16,0,0,1-16,16H56a16,16,0,0,1-16-16V112A16,16,0,0,1,56,96H80a8,8,0,0,1,0,16H56v96H200V112H176a8,8,0,0,1,0-16h24A16,16,0,0,1,216,112ZM93.66,69.66,120,43.31V136a8,8,0,0,0,16,0V43.31l26.34,26.35a8,8,0,0,0,11.32-11.32l-40-40a8,8,0,0,0-11.32,0l-40,40A8,8,0,0,0,93.66,69.66Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ExportIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-export-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M216,112v96a16,16,0,0,1-16,16H56a16,16,0,0,1-16-16V112A16,16,0,0,1,56,96H80a8,8,0,0,1,0,16H56v96H200V112H176a8,8,0,0,1,0-16h24A16,16,0,0,1,216,112ZM93.66,69.66,120,43.31V136a8,8,0,0,0,16,0V43.31l26.34,26.35a8,8,0,0,0,11.32-11.32l-40-40a8,8,0,0,0-11.32,0l-40,40A8,8,0,0,0,93.66,69.66Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class FilterIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: FilterIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: FilterIconComponent, isStandalone: true, selector: "ndt-filter-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M227.81,66.76l-.08.09L160,139.17v55.49A8,8,0,0,1,156.94,201l-32,21.33A8,8,0,0,1,112,216V139.17L44.27,66.85l-.08-.09A16,16,0,0,1,56,40H200a16,16,0,0,1,11.84,26.76Z"
        opacity="0.2"
      ></path>
      <path
        d="M230.6,49.53A23.94,23.94,0,0,0,200,32H56A24,24,0,0,0,38.15,65.67L104,139.37V216a8,8,0,0,0,11.58,7.16l32-16A8,8,0,0,0,152,200V139.37l65.85-73.7A23.93,23.93,0,0,0,230.6,49.53ZM203.36,54.86a8,8,0,0,1,.07,9.12L136,139.17V196.58l-16,8V139.17L52.57,64A8,8,0,0,1,56,48H200A8,8,0,0,1,203.36,54.86Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: FilterIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-filter-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M227.81,66.76l-.08.09L160,139.17v55.49A8,8,0,0,1,156.94,201l-32,21.33A8,8,0,0,1,112,216V139.17L44.27,66.85l-.08-.09A16,16,0,0,1,56,40H200a16,16,0,0,1,11.84,26.76Z"
        opacity="0.2"
      ></path>
      <path
        d="M230.6,49.53A23.94,23.94,0,0,0,200,32H56A24,24,0,0,0,38.15,65.67L104,139.37V216a8,8,0,0,0,11.58,7.16l32-16A8,8,0,0,0,152,200V139.37l65.85-73.7A23.93,23.93,0,0,0,230.6,49.53ZM203.36,54.86a8,8,0,0,1,.07,9.12L136,139.17V196.58l-16,8V139.17L52.57,64A8,8,0,0,1,56,48H200A8,8,0,0,1,203.36,54.86Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class GaugeIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: GaugeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: GaugeIconComponent, isStandalone: true, selector: "ndt-gauge-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M232,152a103.93,103.93,0,0,1-5.9,34.63,8,8,0,0,1-7.57,5.37H37.46a8.05,8.05,0,0,1-7.57-5.41A104.06,104.06,0,0,1,24,151.19C24.44,94,71.73,47.49,129,48A104,104,0,0,1,232,152Z"
        opacity="0.2"
      ></path>
      <path
        d="M114.34,154.34l96-96a8,8,0,0,1,11.32,11.32l-96,96a8,8,0,0,1-11.32-11.32ZM128,88a63.9,63.9,0,0,1,20.44,3.33,8,8,0,1,0,5.11-15.16A80,80,0,0,0,48.49,160.88,8,8,0,0,0,56.43,168c.29,0,.59,0,.89-.05a8,8,0,0,0,7.07-8.83A64.92,64.92,0,0,1,64,152,64.07,64.07,0,0,1,128,88Zm99.74,13a8,8,0,0,0-14.24,7.3,96.27,96.27,0,0,1,5,75.71l-181.1-.07A96.24,96.24,0,0,1,128,56h.88a95,95,0,0,1,42.82,10.5A8,8,0,1,0,179,52.27,110.8,110.8,0,0,0,129,40h-1A112.05,112.05,0,0,0,22.35,189.25,16.07,16.07,0,0,0,37.46,200H218.53a16,16,0,0,0,15.11-10.71,112.35,112.35,0,0,0-5.9-88.3Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: GaugeIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-gauge-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M232,152a103.93,103.93,0,0,1-5.9,34.63,8,8,0,0,1-7.57,5.37H37.46a8.05,8.05,0,0,1-7.57-5.41A104.06,104.06,0,0,1,24,151.19C24.44,94,71.73,47.49,129,48A104,104,0,0,1,232,152Z"
        opacity="0.2"
      ></path>
      <path
        d="M114.34,154.34l96-96a8,8,0,0,1,11.32,11.32l-96,96a8,8,0,0,1-11.32-11.32ZM128,88a63.9,63.9,0,0,1,20.44,3.33,8,8,0,1,0,5.11-15.16A80,80,0,0,0,48.49,160.88,8,8,0,0,0,56.43,168c.29,0,.59,0,.89-.05a8,8,0,0,0,7.07-8.83A64.92,64.92,0,0,1,64,152,64.07,64.07,0,0,1,128,88Zm99.74,13a8,8,0,0,0-14.24,7.3,96.27,96.27,0,0,1,5,75.71l-181.1-.07A96.24,96.24,0,0,1,128,56h.88a95,95,0,0,1,42.82,10.5A8,8,0,1,0,179,52.27,110.8,110.8,0,0,0,129,40h-1A112.05,112.05,0,0,0,22.35,189.25,16.07,16.07,0,0,0,37.46,200H218.53a16,16,0,0,0,15.11-10.71,112.35,112.35,0,0,0-5.9-88.3Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class GearIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: GearIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: GearIconComponent, isStandalone: true, selector: "ndt-gear-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M207.86,123.18l16.78-21a99.14,99.14,0,0,0-10.07-24.29l-26.7-3a81,81,0,0,0-6.81-6.81l-3-26.71a99.43,99.43,0,0,0-24.3-10l-21,16.77a81.59,81.59,0,0,0-9.64,0l-21-16.78A99.14,99.14,0,0,0,77.91,41.43l-3,26.7a81,81,0,0,0-6.81,6.81l-26.71,3a99.43,99.43,0,0,0-10,24.3l16.77,21a81.59,81.59,0,0,0,0,9.64l-16.78,21a99.14,99.14,0,0,0,10.07,24.29l26.7,3a81,81,0,0,0,6.81,6.81l3,26.71a99.43,99.43,0,0,0,24.3,10l21-16.77a81.59,81.59,0,0,0,9.64,0l21,16.78a99.14,99.14,0,0,0,24.29-10.07l3-26.7a81,81,0,0,0,6.81-6.81l26.71-3a99.43,99.43,0,0,0,10-24.3l-16.77-21A81.59,81.59,0,0,0,207.86,123.18ZM128,168a40,40,0,1,1,40-40A40,40,0,0,1,128,168Z"
        opacity="0.2"
      ></path>
      <path
        d="M128,80a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160Zm88-29.84q.06-2.16,0-4.32l14.92-18.64a8,8,0,0,0,1.48-7.06,107.6,107.6,0,0,0-10.88-26.25,8,8,0,0,0-6-3.93l-23.72-2.64q-1.48-1.56-3-3L186,40.54a8,8,0,0,0-3.94-6,107.29,107.29,0,0,0-26.25-10.86,8,8,0,0,0-7.06,1.48L130.16,40Q128,40,125.84,40L107.2,25.11a8,8,0,0,0-7.06-1.48A107.6,107.6,0,0,0,73.89,34.51a8,8,0,0,0-3.93,6L67.32,64.27q-1.56,1.49-3,3L40.54,70a8,8,0,0,0-6,3.94,107.71,107.71,0,0,0-10.87,26.25,8,8,0,0,0,1.49,7.06L40,125.84Q40,128,40,130.16L25.11,148.8a8,8,0,0,0-1.48,7.06,107.6,107.6,0,0,0,10.88,26.25,8,8,0,0,0,6,3.93l23.72,2.64q1.49,1.56,3,3L70,215.46a8,8,0,0,0,3.94,6,107.71,107.71,0,0,0,26.25,10.87,8,8,0,0,0,7.06-1.49L125.84,216q2.16.06,4.32,0l18.64,14.92a8,8,0,0,0,7.06,1.48,107.21,107.21,0,0,0,26.25-10.88,8,8,0,0,0,3.93-6l2.64-23.72q1.56-1.48,3-3L215.46,186a8,8,0,0,0,6-3.94,107.71,107.71,0,0,0,10.87-26.25,8,8,0,0,0-1.49-7.06Zm-16.1-6.5a73.93,73.93,0,0,1,0,8.68,8,8,0,0,0,1.74,5.48l14.19,17.73a91.57,91.57,0,0,1-6.23,15L187,173.11a8,8,0,0,0-5.1,2.64,74.11,74.11,0,0,1-6.14,6.14,8,8,0,0,0-2.64,5.1l-2.51,22.58a91.32,91.32,0,0,1-15,6.23l-17.74-14.19a8,8,0,0,0-5-1.75h-.48a73.93,73.93,0,0,1-8.68,0,8.06,8.06,0,0,0-5.48,1.74L100.45,215.8a91.57,91.57,0,0,1-15-6.23L82.89,187a8,8,0,0,0-2.64-5.1,74.11,74.11,0,0,1-6.14-6.14,8,8,0,0,0-5.1-2.64L46.43,170.6a91.32,91.32,0,0,1-6.23-15l14.19-17.74a8,8,0,0,0,1.74-5.48,73.93,73.93,0,0,1,0-8.68,8,8,0,0,0-1.74-5.48L40.2,100.45a91.57,91.57,0,0,1,6.23-15L69,82.89a8,8,0,0,0,5.1-2.64,74.11,74.11,0,0,1,6.14-6.14A8,8,0,0,0,82.89,69L85.4,46.43a91.32,91.32,0,0,1,15-6.23l17.74,14.19a8,8,0,0,0,5.48,1.74,73.93,73.93,0,0,1,8.68,0,8.06,8.06,0,0,0,5.48-1.74L155.55,40.2a91.57,91.57,0,0,1,15,6.23L173.11,69a8,8,0,0,0,2.64,5.1,74.11,74.11,0,0,1,6.14,6.14,8,8,0,0,0,5.1,2.64l22.58,2.51a91.32,91.32,0,0,1,6.23,15l-14.19,17.74A8,8,0,0,0,199.87,123.66Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: GearIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-gear-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M207.86,123.18l16.78-21a99.14,99.14,0,0,0-10.07-24.29l-26.7-3a81,81,0,0,0-6.81-6.81l-3-26.71a99.43,99.43,0,0,0-24.3-10l-21,16.77a81.59,81.59,0,0,0-9.64,0l-21-16.78A99.14,99.14,0,0,0,77.91,41.43l-3,26.7a81,81,0,0,0-6.81,6.81l-26.71,3a99.43,99.43,0,0,0-10,24.3l16.77,21a81.59,81.59,0,0,0,0,9.64l-16.78,21a99.14,99.14,0,0,0,10.07,24.29l26.7,3a81,81,0,0,0,6.81,6.81l3,26.71a99.43,99.43,0,0,0,24.3,10l21-16.77a81.59,81.59,0,0,0,9.64,0l21,16.78a99.14,99.14,0,0,0,24.29-10.07l3-26.7a81,81,0,0,0,6.81-6.81l26.71-3a99.43,99.43,0,0,0,10-24.3l-16.77-21A81.59,81.59,0,0,0,207.86,123.18ZM128,168a40,40,0,1,1,40-40A40,40,0,0,1,128,168Z"
        opacity="0.2"
      ></path>
      <path
        d="M128,80a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160Zm88-29.84q.06-2.16,0-4.32l14.92-18.64a8,8,0,0,0,1.48-7.06,107.6,107.6,0,0,0-10.88-26.25,8,8,0,0,0-6-3.93l-23.72-2.64q-1.48-1.56-3-3L186,40.54a8,8,0,0,0-3.94-6,107.29,107.29,0,0,0-26.25-10.86,8,8,0,0,0-7.06,1.48L130.16,40Q128,40,125.84,40L107.2,25.11a8,8,0,0,0-7.06-1.48A107.6,107.6,0,0,0,73.89,34.51a8,8,0,0,0-3.93,6L67.32,64.27q-1.56,1.49-3,3L40.54,70a8,8,0,0,0-6,3.94,107.71,107.71,0,0,0-10.87,26.25,8,8,0,0,0,1.49,7.06L40,125.84Q40,128,40,130.16L25.11,148.8a8,8,0,0,0-1.48,7.06,107.6,107.6,0,0,0,10.88,26.25,8,8,0,0,0,6,3.93l23.72,2.64q1.49,1.56,3,3L70,215.46a8,8,0,0,0,3.94,6,107.71,107.71,0,0,0,26.25,10.87,8,8,0,0,0,7.06-1.49L125.84,216q2.16.06,4.32,0l18.64,14.92a8,8,0,0,0,7.06,1.48,107.21,107.21,0,0,0,26.25-10.88,8,8,0,0,0,3.93-6l2.64-23.72q1.56-1.48,3-3L215.46,186a8,8,0,0,0,6-3.94,107.71,107.71,0,0,0,10.87-26.25,8,8,0,0,0-1.49-7.06Zm-16.1-6.5a73.93,73.93,0,0,1,0,8.68,8,8,0,0,0,1.74,5.48l14.19,17.73a91.57,91.57,0,0,1-6.23,15L187,173.11a8,8,0,0,0-5.1,2.64,74.11,74.11,0,0,1-6.14,6.14,8,8,0,0,0-2.64,5.1l-2.51,22.58a91.32,91.32,0,0,1-15,6.23l-17.74-14.19a8,8,0,0,0-5-1.75h-.48a73.93,73.93,0,0,1-8.68,0,8.06,8.06,0,0,0-5.48,1.74L100.45,215.8a91.57,91.57,0,0,1-15-6.23L82.89,187a8,8,0,0,0-2.64-5.1,74.11,74.11,0,0,1-6.14-6.14,8,8,0,0,0-5.1-2.64L46.43,170.6a91.32,91.32,0,0,1-6.23-15l14.19-17.74a8,8,0,0,0,1.74-5.48,73.93,73.93,0,0,1,0-8.68,8,8,0,0,0-1.74-5.48L40.2,100.45a91.57,91.57,0,0,1,6.23-15L69,82.89a8,8,0,0,0,5.1-2.64,74.11,74.11,0,0,1,6.14-6.14A8,8,0,0,0,82.89,69L85.4,46.43a91.32,91.32,0,0,1,15-6.23l17.74,14.19a8,8,0,0,0,5.48,1.74,73.93,73.93,0,0,1,8.68,0,8.06,8.06,0,0,0,5.48-1.74L155.55,40.2a91.57,91.57,0,0,1,15,6.23L173.11,69a8,8,0,0,0,2.64,5.1,74.11,74.11,0,0,1,6.14,6.14,8,8,0,0,0,5.1,2.64l22.58,2.51a91.32,91.32,0,0,1,6.23,15l-14.19,17.74A8,8,0,0,0,199.87,123.66Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class GitBranchIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: GitBranchIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: GitBranchIconComponent, isStandalone: true, selector: "ndt-git-branch-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M224,64a24,24,0,1,1-24-24A24,24,0,0,1,224,64Z"
        opacity="0.2"
      ></path>
      <path
        d="M232,64a32,32,0,1,0-40,31v17a8,8,0,0,1-8,8H96a23.84,23.84,0,0,0-8,1.38V95a32,32,0,1,0-16,0v66a32,32,0,1,0,16,0V144a8,8,0,0,1,8-8h88a24,24,0,0,0,24-24V95A32.06,32.06,0,0,0,232,64ZM64,64A16,16,0,1,1,80,80,16,16,0,0,1,64,64ZM96,192a16,16,0,1,1-16-16A16,16,0,0,1,96,192ZM200,80a16,16,0,1,1,16-16A16,16,0,0,1,200,80Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: GitBranchIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-git-branch-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M224,64a24,24,0,1,1-24-24A24,24,0,0,1,224,64Z"
        opacity="0.2"
      ></path>
      <path
        d="M232,64a32,32,0,1,0-40,31v17a8,8,0,0,1-8,8H96a23.84,23.84,0,0,0-8,1.38V95a32,32,0,1,0-16,0v66a32,32,0,1,0,16,0V144a8,8,0,0,1,8-8h88a24,24,0,0,0,24-24V95A32.06,32.06,0,0,0,232,64ZM64,64A16,16,0,1,1,80,80,16,16,0,0,1,64,64ZM96,192a16,16,0,1,1-16-16A16,16,0,0,1,96,192ZM200,80a16,16,0,1,1,16-16A16,16,0,0,1,200,80Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class GlobeIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: GlobeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: GlobeIconComponent, isStandalone: true, selector: "ndt-globe-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <path
        d="M1 16V8h2v8H1Zm3 0V8h2l2.225 4.45L8 12.5V8h2v8H8l-2.225-4.45L6 11.5V16H4Zm9 0v-6h-2V8h6v2h-2v6h-2Zm5 0V8h2v6h3v2h-5Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: GlobeIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-globe-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <path
        d="M1 16V8h2v8H1Zm3 0V8h2l2.225 4.45L8 12.5V8h2v8H8l-2.225-4.45L6 11.5V16H4Zm9 0v-6h-2V8h6v2h-2v6h-2Zm5 0V8h2v6h3v2h-5Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class ImportIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ImportIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: ImportIconComponent, isStandalone: true, selector: "ndt-import-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M224,144v64a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V144a8,8,0,0,1,16,0v56H208V144a8,8,0,0,1,16,0Zm-101.66,5.66a8,8,0,0,0,11.32,0l40-40a8,8,0,0,0-11.32-11.32L136,124.69V32a8,8,0,0,0-16,0v92.69L93.66,98.34a8,8,0,0,0-11.32,11.32Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ImportIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-import-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M224,144v64a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V144a8,8,0,0,1,16,0v56H208V144a8,8,0,0,1,16,0Zm-101.66,5.66a8,8,0,0,0,11.32,0l40-40a8,8,0,0,0-11.32-11.32L136,124.69V32a8,8,0,0,0-16,0v92.69L93.66,98.34a8,8,0,0,0-11.32,11.32Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class LayoutIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: LayoutIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: LayoutIconComponent, isStandalone: true, selector: "ndt-layout-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path d="M104,104V208H40a8,8,0,0,1-8-8V104Z" opacity="0.2"></path>
      <path
        d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,16V96H40V56ZM40,112H96v88H40Zm176,88H112V112H216v88Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: LayoutIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-layout-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path d="M104,104V208H40a8,8,0,0,1-8-8V104Z" opacity="0.2"></path>
      <path
        d="M216,40H40A16,16,0,0,0,24,56V200a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A16,16,0,0,0,216,40Zm0,16V96H40V56ZM40,112H96v88H40Zm176,88H112V112H216v88Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class LightbulbIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: LightbulbIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: LightbulbIconComponent, isStandalone: true, selector: "ndt-lightbulb-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M176,232a8,8,0,0,1-8,8H88a8,8,0,0,1,0-16h80A8,8,0,0,1,176,232Zm40-128a87.55,87.55,0,0,1-33.64,69.21A16.24,16.24,0,0,0,176,186v6a16,16,0,0,1-16,16H96a16,16,0,0,1-16-16v-6a16,16,0,0,0-6.23-12.66A87.59,87.59,0,0,1,40,104.49C39.74,56.83,78.26,17.14,125.88,16A88,88,0,0,1,216,104Zm-16,0a72,72,0,0,0-73.74-72c-39,.92-70.47,33.39-70.26,72.39a71.65,71.65,0,0,0,27.64,56.3A32,32,0,0,1,96,186v6h64v-6a32.15,32.15,0,0,1,12.47-25.35A71.65,71.65,0,0,0,200,104Zm-16.11-9.34a57.6,57.6,0,0,0-46.56-46.55,8,8,0,0,0-2.66,15.78c16.57,2.79,30.63,16.85,33.44,33.45A8,8,0,0,0,176,104a9,9,0,0,0,1.35-.11A8,8,0,0,0,183.89,94.66Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: LightbulbIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-lightbulb-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M176,232a8,8,0,0,1-8,8H88a8,8,0,0,1,0-16h80A8,8,0,0,1,176,232Zm40-128a87.55,87.55,0,0,1-33.64,69.21A16.24,16.24,0,0,0,176,186v6a16,16,0,0,1-16,16H96a16,16,0,0,1-16-16v-6a16,16,0,0,0-6.23-12.66A87.59,87.59,0,0,1,40,104.49C39.74,56.83,78.26,17.14,125.88,16A88,88,0,0,1,216,104Zm-16,0a72,72,0,0,0-73.74-72c-39,.92-70.47,33.39-70.26,72.39a71.65,71.65,0,0,0,27.64,56.3A32,32,0,0,1,96,186v6h64v-6a32.15,32.15,0,0,1,12.47-25.35A71.65,71.65,0,0,0,200,104Zm-16.11-9.34a57.6,57.6,0,0,0-46.56-46.55,8,8,0,0,0-2.66,15.78c16.57,2.79,30.63,16.85,33.44,33.45A8,8,0,0,0,176,104a9,9,0,0,0,1.35-.11A8,8,0,0,0,183.89,94.66Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class LightingIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: LightingIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: LightingIconComponent, isStandalone: true, selector: "ndt-lighting-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path d="M96,240l16-80L48,136,160,16,144,96l64,24Z" opacity="0.2"></path>
      <path
        d="M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7l-112,120a8,8,0,0,0,3,13l57.63,21.61L88.16,238.43a8,8,0,0,0,13.69,7l112-120A8,8,0,0,0,215.79,118.17ZM109.37,214l10.47-52.38a8,8,0,0,0-5-9.06L62,132.71l84.62-90.66L136.16,94.43a8,8,0,0,0,5,9.06l52.8,19.8Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: LightingIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-lighting-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path d="M96,240l16-80L48,136,160,16,144,96l64,24Z" opacity="0.2"></path>
      <path
        d="M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7l-112,120a8,8,0,0,0,3,13l57.63,21.61L88.16,238.43a8,8,0,0,0,13.69,7l112-120A8,8,0,0,0,215.79,118.17ZM109.37,214l10.47-52.38a8,8,0,0,0-5-9.06L62,132.71l84.62-90.66L136.16,94.43a8,8,0,0,0,5,9.06l52.8,19.8Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class LockIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: LockIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: LockIconComponent, isStandalone: true, selector: "ndt-lock-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M208,80H176V56a48,48,0,0,0-96,0V80H48A16,16,0,0,0,32,96V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V96A16,16,0,0,0,208,80ZM96,56a32,32,0,0,1,64,0V80H96ZM208,208H48V96H208V208Zm-68-56a12,12,0,1,1-12-12A12,12,0,0,1,140,152Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: LockIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-lock-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M208,80H176V56a48,48,0,0,0-96,0V80H48A16,16,0,0,0,32,96V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V96A16,16,0,0,0,208,80ZM96,56a32,32,0,0,1,64,0V80H96ZM208,208H48V96H208V208Zm-68-56a12,12,0,1,1-12-12A12,12,0,0,1,140,152Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class MoonIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: MoonIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: MoonIconComponent, isStandalone: true, selector: "ndt-moon-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M224.3,150.3a8.1,8.1,0,0,0-7.8-5.7l-2.2.4A84,84,0,0,1,111,41.6a5.7,5.7,0,0,0,.3-1.8A7.9,7.9,0,0,0,109,33a8.1,8.1,0,0,0-8.1-1.1A104,104,0,1,0,225.4,156.9,8.1,8.1,0,0,0,224.3,150.3Z"
        opacity="0.2"
      />
      <path
        d="M233.5,137.3a12.1,12.1,0,0,0-11.8-8.6,7.9,7.9,0,0,0-1.3.1,80,80,0,0,1-98.2-98.2,12,12,0,0,0-15.6-14A104.2,104.2,0,0,0,32,120c0,57.4,46.6,104,104,104A104.2,104.2,0,0,0,239.4,149.6,12,12,0,0,0,233.5,137.3ZM136,208A88,88,0,0,1,48,120a87.6,87.6,0,0,1,64.8-84.7,96,96,0,0,0,111.9,112A87.6,87.6,0,0,1,136,208Z"
      />
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: MoonIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-moon-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M224.3,150.3a8.1,8.1,0,0,0-7.8-5.7l-2.2.4A84,84,0,0,1,111,41.6a5.7,5.7,0,0,0,.3-1.8A7.9,7.9,0,0,0,109,33a8.1,8.1,0,0,0-8.1-1.1A104,104,0,1,0,225.4,156.9,8.1,8.1,0,0,0,224.3,150.3Z"
        opacity="0.2"
      />
      <path
        d="M233.5,137.3a12.1,12.1,0,0,0-11.8-8.6,7.9,7.9,0,0,0-1.3.1,80,80,0,0,1-98.2-98.2,12,12,0,0,0-15.6-14A104.2,104.2,0,0,0,32,120c0,57.4,46.6,104,104,104A104.2,104.2,0,0,0,239.4,149.6,12,12,0,0,0,233.5,137.3ZM136,208A88,88,0,0,1,48,120a87.6,87.6,0,0,1,64.8-84.7,96,96,0,0,0,111.9,112A87.6,87.6,0,0,1,136,208Z"
      />
    </svg>
  `,
                }]
        }] });

class NetworkIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: NetworkIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: NetworkIconComponent, isStandalone: true, selector: "ndt-network-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M152,40V72a8,8,0,0,1-8,8H112a8,8,0,0,1-8-8V40a8,8,0,0,1,8-8h32A8,8,0,0,1,152,40ZM80,168H48a8,8,0,0,0-8,8v32a8,8,0,0,0,8,8H80a8,8,0,0,0,8-8V176A8,8,0,0,0,80,168Zm128,0H176a8,8,0,0,0-8,8v32a8,8,0,0,0,8,8h32a8,8,0,0,0,8-8V176A8,8,0,0,0,208,168Z"
        opacity="0.2"
      ></path>
      <path
        d="M232,112H136V88h8a16,16,0,0,0,16-16V40a16,16,0,0,0-16-16H112A16,16,0,0,0,96,40V72a16,16,0,0,0,16,16h8v24H24a8,8,0,0,0,0,16H56v32H48a16,16,0,0,0-16,16v32a16,16,0,0,0,16,16H80a16,16,0,0,0,16-16V176a16,16,0,0,0-16-16H72V128H184v32h-8a16,16,0,0,0-16,16v32a16,16,0,0,0,16,16h32a16,16,0,0,0,16-16V176a16,16,0,0,0-16-16h-8V128h32a8,8,0,0,0,0-16ZM112,40h32V72H112ZM80,208H48V176H80Zm128,0H176V176h32Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: NetworkIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-network-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M152,40V72a8,8,0,0,1-8,8H112a8,8,0,0,1-8-8V40a8,8,0,0,1,8-8h32A8,8,0,0,1,152,40ZM80,168H48a8,8,0,0,0-8,8v32a8,8,0,0,0,8,8H80a8,8,0,0,0,8-8V176A8,8,0,0,0,80,168Zm128,0H176a8,8,0,0,0-8,8v32a8,8,0,0,0,8,8h32a8,8,0,0,0,8-8V176A8,8,0,0,0,208,168Z"
        opacity="0.2"
      ></path>
      <path
        d="M232,112H136V88h8a16,16,0,0,0,16-16V40a16,16,0,0,0-16-16H112A16,16,0,0,0,96,40V72a16,16,0,0,0,16,16h8v24H24a8,8,0,0,0,0,16H56v32H48a16,16,0,0,0-16,16v32a16,16,0,0,0,16,16H80a16,16,0,0,0,16-16V176a16,16,0,0,0-16-16H72V128H184v32h-8a16,16,0,0,0-16,16v32a16,16,0,0,0,16,16h32a16,16,0,0,0,16-16V176a16,16,0,0,0-16-16h-8V128h32a8,8,0,0,0,0-16ZM112,40h32V72H112ZM80,208H48V176H80Zm128,0H176V176h32Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class PinIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: PinIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: PinIconComponent, isStandalone: true, selector: "ndt-pin-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <path
        d="M14 12.41V5h1V4H8v1h1v7.41l-2 2V15h9v-.59l-2-2"
        opacity="0.2"
      ></path>
      <path
        d="M17 14v2h-5v4.5l-.5 1.5l-.5-1.5V16H6v-2l2-2V6H7V3h9v3h-1v6l2 2Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: PinIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-pin-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
    >
      <path
        d="M14 12.41V5h1V4H8v1h1v7.41l-2 2V15h9v-.59l-2-2"
        opacity="0.2"
      ></path>
      <path
        d="M17 14v2h-5v4.5l-.5 1.5l-.5-1.5V16H6v-2l2-2V6H7V3h9v3h-1v6l2 2Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class PuzzleIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: PuzzleIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: PuzzleIconComponent, isStandalone: true, selector: "ndt-puzzle-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M204,168a28,28,0,0,0,12-2.69V208a8,8,0,0,1-8,8H64a8,8,0,0,1-8-8V165.31a28,28,0,1,1,0-50.62V72a8,8,0,0,1,8-8h46.69a28,28,0,1,1,50.61,0H208a8,8,0,0,1,8,8v42.69A28,28,0,1,0,204,168Z"
        opacity="0.2"
      ></path>
      <path
        d="M220.27,158.54a8,8,0,0,0-7.7-.46,20,20,0,1,1,0-36.16A8,8,0,0,0,224,114.69V72a16,16,0,0,0-16-16H171.78a35.36,35.36,0,0,0,.22-4,36.15,36.15,0,0,0-11.36-26.25,36,36,0,0,0-60.55,23.63,36.56,36.56,0,0,0,.14,6.62H64A16,16,0,0,0,48,72v32.22a35.36,35.36,0,0,0-4-.22,36.12,36.12,0,0,0-26.24,11.36,35.7,35.7,0,0,0-9.69,27,36.08,36.08,0,0,0,33.31,33.6,36.56,36.56,0,0,0,6.62-.14V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V165.31A8,8,0,0,0,220.27,158.54ZM208,208H64V165.31a8,8,0,0,0-11.43-7.23,20,20,0,1,1,0-36.16A8,8,0,0,0,64,114.69V72h46.69a8,8,0,0,0,7.23-11.43,20,20,0,1,1,36.16,0A8,8,0,0,0,161.31,72H208v32.23a35.68,35.68,0,0,0-6.62-.14A36,36,0,0,0,204,176a35.36,35.36,0,0,0,4-.22Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: PuzzleIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-puzzle-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M204,168a28,28,0,0,0,12-2.69V208a8,8,0,0,1-8,8H64a8,8,0,0,1-8-8V165.31a28,28,0,1,1,0-50.62V72a8,8,0,0,1,8-8h46.69a28,28,0,1,1,50.61,0H208a8,8,0,0,1,8,8v42.69A28,28,0,1,0,204,168Z"
        opacity="0.2"
      ></path>
      <path
        d="M220.27,158.54a8,8,0,0,0-7.7-.46,20,20,0,1,1,0-36.16A8,8,0,0,0,224,114.69V72a16,16,0,0,0-16-16H171.78a35.36,35.36,0,0,0,.22-4,36.15,36.15,0,0,0-11.36-26.25,36,36,0,0,0-60.55,23.63,36.56,36.56,0,0,0,.14,6.62H64A16,16,0,0,0,48,72v32.22a35.36,35.36,0,0,0-4-.22,36.12,36.12,0,0,0-26.24,11.36,35.7,35.7,0,0,0-9.69,27,36.08,36.08,0,0,0,33.31,33.6,36.56,36.56,0,0,0,6.62-.14V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V165.31A8,8,0,0,0,220.27,158.54ZM208,208H64V165.31a8,8,0,0,0-11.43-7.23,20,20,0,1,1,0-36.16A8,8,0,0,0,64,114.69V72h46.69a8,8,0,0,0,7.23-11.43,20,20,0,1,1,36.16,0A8,8,0,0,0,161.31,72H208v32.23a35.68,35.68,0,0,0-6.62-.14A36,36,0,0,0,204,176a35.36,35.36,0,0,0,4-.22Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class RefreshIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: RefreshIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: RefreshIconComponent, isStandalone: true, selector: "ndt-refresh-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M216,128a88,88,0,1,1-88-88A88,88,0,0,1,216,128Z"
        opacity="0.2"
      ></path>
      <path
        d="M224,48V96a8,8,0,0,1-8,8H168a8,8,0,0,1,0-16h28.69L182.06,73.37a79.56,79.56,0,0,0-56.13-23.43h-.45A79.52,79.52,0,0,0,69.59,72.71,8,8,0,0,1,58.41,61.27a96,96,0,0,1,135,.79L208,76.69V48a8,8,0,0,1,16,0ZM186.41,183.29a80,80,0,0,1-112.47-.66L59.31,168H88a8,8,0,0,0,0-16H40a8,8,0,0,0-8,8v48a8,8,0,0,0,16,0V179.31l14.63,14.63A95.43,95.43,0,0,0,130,222.06h.53a95.36,95.36,0,0,0,67.07-27.33,8,8,0,0,0-11.18-11.44Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: RefreshIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-refresh-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M216,128a88,88,0,1,1-88-88A88,88,0,0,1,216,128Z"
        opacity="0.2"
      ></path>
      <path
        d="M224,48V96a8,8,0,0,1-8,8H168a8,8,0,0,1,0-16h28.69L182.06,73.37a79.56,79.56,0,0,0-56.13-23.43h-.45A79.52,79.52,0,0,0,69.59,72.71,8,8,0,0,1,58.41,61.27a96,96,0,0,1,135,.79L208,76.69V48a8,8,0,0,1,16,0ZM186.41,183.29a80,80,0,0,1-112.47-.66L59.31,168H88a8,8,0,0,0,0-16H40a8,8,0,0,0-8,8v48a8,8,0,0,0,16,0V179.31l14.63,14.63A95.43,95.43,0,0,0,130,222.06h.53a95.36,95.36,0,0,0,67.07-27.33,8,8,0,0,0-11.18-11.44Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class StarIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: StarIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: StarIconComponent, isStandalone: true, selector: "ndt-star-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M229.06,108.79l-48.7,42,14.88,62.79a8.4,8.4,0,0,1-12.52,9.17L128,189.09,73.28,222.74a8.4,8.4,0,0,1-12.52-9.17l14.88-62.79-48.7-42A8.46,8.46,0,0,1,31.73,94L95.64,88.8l24.62-59.6a8.36,8.36,0,0,1,15.48,0l24.62,59.6L224.27,94A8.46,8.46,0,0,1,229.06,108.79Z"
        opacity="0.2"
      ></path>
      <path
        d="M239.18,97.26A16.38,16.38,0,0,0,224.92,86l-59-4.76L143.14,26.15a16.36,16.36,0,0,0-30.27,0L90.11,81.23,31.08,86a16.46,16.46,0,0,0-9.37,28.86l45,38.83L53,211.75a16.38,16.38,0,0,0,24.5,17.82L128,198.49l50.53,31.08A16.4,16.4,0,0,0,203,211.75l-13.76-58.07,45-38.83A16.43,16.43,0,0,0,239.18,97.26Zm-15.34,5.47-48.7,42a8,8,0,0,0-2.56,7.91l14.88,62.8a.37.37,0,0,1-.17.48c-.18.14-.23.11-.38,0l-54.72-33.65a8,8,0,0,0-8.38,0L69.09,215.94c-.15.09-.19.12-.38,0a.37.37,0,0,1-.17-.48l14.88-62.8a8,8,0,0,0-2.56-7.91l-48.7-42c-.12-.1-.23-.19-.13-.5s.18-.27.33-.29l63.92-5.16A8,8,0,0,0,103,91.86l24.62-59.61c.08-.17.11-.25.35-.25s.27.08.35.25L153,91.86a8,8,0,0,0,6.75,4.92l63.92,5.16c.15,0,.24,0,.33.29S224,102.63,223.84,102.73Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: StarIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-star-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M229.06,108.79l-48.7,42,14.88,62.79a8.4,8.4,0,0,1-12.52,9.17L128,189.09,73.28,222.74a8.4,8.4,0,0,1-12.52-9.17l14.88-62.79-48.7-42A8.46,8.46,0,0,1,31.73,94L95.64,88.8l24.62-59.6a8.36,8.36,0,0,1,15.48,0l24.62,59.6L224.27,94A8.46,8.46,0,0,1,229.06,108.79Z"
        opacity="0.2"
      ></path>
      <path
        d="M239.18,97.26A16.38,16.38,0,0,0,224.92,86l-59-4.76L143.14,26.15a16.36,16.36,0,0,0-30.27,0L90.11,81.23,31.08,86a16.46,16.46,0,0,0-9.37,28.86l45,38.83L53,211.75a16.38,16.38,0,0,0,24.5,17.82L128,198.49l50.53,31.08A16.4,16.4,0,0,0,203,211.75l-13.76-58.07,45-38.83A16.43,16.43,0,0,0,239.18,97.26Zm-15.34,5.47-48.7,42a8,8,0,0,0-2.56,7.91l14.88,62.8a.37.37,0,0,1-.17.48c-.18.14-.23.11-.38,0l-54.72-33.65a8,8,0,0,0-8.38,0L69.09,215.94c-.15.09-.19.12-.38,0a.37.37,0,0,1-.17-.48l14.88-62.8a8,8,0,0,0-2.56-7.91l-48.7-42c-.12-.1-.23-.19-.13-.5s.18-.27.33-.29l63.92-5.16A8,8,0,0,0,103,91.86l24.62-59.61c.08-.17.11-.25.35-.25s.27.08.35.25L153,91.86a8,8,0,0,0,6.75,4.92l63.92,5.16c.15,0,.24,0,.33.29S224,102.63,223.84,102.73Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class SunIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: SunIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: SunIconComponent, isStandalone: true, selector: "ndt-sun-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M128,60a68,68,0,1,0,68,68A68.07,68.07,0,0,0,128,60Z"
        opacity="0.2"
      />
      <path
        d="M128,44a8,8,0,0,0,8-8V16a8,8,0,0,0-16,0V36A8,8,0,0,0,128,44ZM57.31,68.69a8,8,0,0,0,11.32-11.32L54.63,43.37A8,8,0,0,0,43.31,54.69ZM44,128a8,8,0,0,0-8-8H16a8,8,0,0,0,0,16H36A8,8,0,0,0,44,128Zm24.63,59.31-14,14a8,8,0,0,0,11.32,11.32l14-14a8,8,0,0,0-11.32-11.32ZM128,212a8,8,0,0,0-8,8v20a8,8,0,0,0,16,0V220A8,8,0,0,0,128,212Zm70.69-24.69a8,8,0,0,0-11.32,11.32l14,14a8,8,0,0,0,11.32-11.32ZM240,120H220a8,8,0,0,0,0,16h20a8,8,0,0,0,0-16Zm-24.69-62.63-14,14a8,8,0,0,0,11.32,11.32l14-14a8,8,0,0,0-11.32-11.32ZM128,76a52,52,0,1,0,52,52A52.06,52.06,0,0,0,128,76Zm0,88a36,36,0,1,1,36-36A36,36,0,0,1,128,164Z"
      />
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: SunIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-sun-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M128,60a68,68,0,1,0,68,68A68.07,68.07,0,0,0,128,60Z"
        opacity="0.2"
      />
      <path
        d="M128,44a8,8,0,0,0,8-8V16a8,8,0,0,0-16,0V36A8,8,0,0,0,128,44ZM57.31,68.69a8,8,0,0,0,11.32-11.32L54.63,43.37A8,8,0,0,0,43.31,54.69ZM44,128a8,8,0,0,0-8-8H16a8,8,0,0,0,0,16H36A8,8,0,0,0,44,128Zm24.63,59.31-14,14a8,8,0,0,0,11.32,11.32l14-14a8,8,0,0,0-11.32-11.32ZM128,212a8,8,0,0,0-8,8v20a8,8,0,0,0,16,0V220A8,8,0,0,0,128,212Zm70.69-24.69a8,8,0,0,0-11.32,11.32l14,14a8,8,0,0,0,11.32-11.32ZM240,120H220a8,8,0,0,0,0,16h20a8,8,0,0,0,0-16Zm-24.69-62.63-14,14a8,8,0,0,0,11.32,11.32l14-14a8,8,0,0,0-11.32-11.32ZM128,76a52,52,0,1,0,52,52A52.06,52.06,0,0,0,128,76Zm0,88a36,36,0,1,1,36-36A36,36,0,0,1,128,164Z"
      />
    </svg>
  `,
                }]
        }] });

class TerminalIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: TerminalIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: TerminalIconComponent, isStandalone: true, selector: "ndt-terminal-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M224,56V200a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V56a8,8,0,0,1,8-8H216A8,8,0,0,1,224,56Z"
        opacity="0.2"
      ></path>
      <path
        d="M128,128a8,8,0,0,1-3,6.25l-40,32a8,8,0,1,1-10-12.5L107.19,128,75,102.25a8,8,0,1,1,10-12.5l40,32A8,8,0,0,1,128,128Zm48,24H136a8,8,0,0,0,0,16h40a8,8,0,0,0,0-16Zm56-96V200a16,16,0,0,1-16,16H40a16,16,0,0,1-16-16V56A16,16,0,0,1,40,40H216A16,16,0,0,1,232,56ZM216,200V56H40V200H216Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: TerminalIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-terminal-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M224,56V200a8,8,0,0,1-8,8H40a8,8,0,0,1-8-8V56a8,8,0,0,1,8-8H216A8,8,0,0,1,224,56Z"
        opacity="0.2"
      ></path>
      <path
        d="M128,128a8,8,0,0,1-3,6.25l-40,32a8,8,0,1,1-10-12.5L107.19,128,75,102.25a8,8,0,1,1,10-12.5l40,32A8,8,0,0,1,128,128Zm48,24H136a8,8,0,0,0,0,16h40a8,8,0,0,0,0-16Zm56-96V200a16,16,0,0,1-16,16H40a16,16,0,0,1-16-16V56A16,16,0,0,1,40,40H216A16,16,0,0,1,232,56ZM216,200V56H40V200H216Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class ToggleLeftIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToggleLeftIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: ToggleLeftIconComponent, isStandalone: true, selector: "ndt-toggle-left-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M112,128A32,32,0,1,1,80,96,32,32,0,0,1,112,128Z"
        opacity="0.2"
      ></path>
      <path
        d="M176,56H80a72,72,0,0,0,0,144h96a72,72,0,0,0,0-144Zm0,128H80A56,56,0,0,1,80,72h96a56,56,0,0,1,0,112ZM80,88a40,40,0,1,0,40,40A40,40,0,0,0,80,88Zm0,64a24,24,0,1,1,24-24A24,24,0,0,1,80,152Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToggleLeftIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-toggle-left-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M112,128A32,32,0,1,1,80,96,32,32,0,0,1,112,128Z"
        opacity="0.2"
      ></path>
      <path
        d="M176,56H80a72,72,0,0,0,0,144h96a72,72,0,0,0,0-144Zm0,128H80A56,56,0,0,1,80,72h96a56,56,0,0,1,0,112ZM80,88a40,40,0,1,0,40,40A40,40,0,0,0,80,88Zm0,64a24,24,0,1,1,24-24A24,24,0,0,1,80,152Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class TranslateIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: TranslateIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: TranslateIconComponent, isStandalone: true, selector: "ndt-translate-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M250.73,210.63l-56-112a12,12,0,0,0-21.46,0l-20.52,41A84.2,84.2,0,0,1,114,126.22,107.48,107.48,0,0,0,139.33,68H160a12,12,0,0,0,0-24H108V32a12,12,0,0,0-24,0V44H32a12,12,0,0,0,0,24h83.13A83.69,83.69,0,0,1,96,110.35,84,84,0,0,1,83.6,91a12,12,0,1,0-21.81,10A107.55,107.55,0,0,0,78,126.24,83.54,83.54,0,0,1,32,140a12,12,0,0,0,0,24,107.47,107.47,0,0,0,64-21.07,108.4,108.4,0,0,0,45.39,19.44l-24.13,48.26a12,12,0,1,0,21.46,10.73L151.41,196h65.17l12.68,25.36a12,12,0,1,0,21.47-10.73ZM163.41,172,184,130.83,204.58,172Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: TranslateIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-translate-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M250.73,210.63l-56-112a12,12,0,0,0-21.46,0l-20.52,41A84.2,84.2,0,0,1,114,126.22,107.48,107.48,0,0,0,139.33,68H160a12,12,0,0,0,0-24H108V32a12,12,0,0,0-24,0V44H32a12,12,0,0,0,0,24h83.13A83.69,83.69,0,0,1,96,110.35,84,84,0,0,1,83.6,91a12,12,0,1,0-21.81,10A107.55,107.55,0,0,0,78,126.24,83.54,83.54,0,0,1,32,140a12,12,0,0,0,0,24,107.47,107.47,0,0,0,64-21.07,108.4,108.4,0,0,0,45.39,19.44l-24.13,48.26a12,12,0,1,0,21.46,10.73L151.41,196h65.17l12.68,25.36a12,12,0,1,0,21.47-10.73ZM163.41,172,184,130.83,204.58,172Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class TrashIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: TrashIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: TrashIconComponent, isStandalone: true, selector: "ndt-trash-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M216,48H176V40a24,24,0,0,0-24-24H104A24,24,0,0,0,80,40v8H40a8,8,0,0,0,0,16h8V208a16,16,0,0,0,16,16H192a16,16,0,0,0,16-16V64h8a8,8,0,0,0,0-16ZM96,40a8,8,0,0,1,8-8h48a8,8,0,0,1,8,8v8H96Zm96,168H64V64H192ZM112,104v64a8,8,0,0,1-16,0V104a8,8,0,0,1,16,0Zm48,0v64a8,8,0,0,1-16,0V104a8,8,0,0,1,16,0Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: TrashIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-trash-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M216,48H176V40a24,24,0,0,0-24-24H104A24,24,0,0,0,80,40v8H40a8,8,0,0,0,0,16h8V208a16,16,0,0,0,16,16H192a16,16,0,0,0,16-16V64h8a8,8,0,0,0,0-16ZM96,40a8,8,0,0,1,8-8h48a8,8,0,0,1,8,8v8H96Zm96,168H64V64H192ZM112,104v64a8,8,0,0,1-16,0V104a8,8,0,0,1,16,0Zm48,0v64a8,8,0,0,1-16,0V104a8,8,0,0,1,16,0Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class UsersIconComponent {
    constructor() {
        this.fill = input('#FFFF');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: UsersIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: UsersIconComponent, isStandalone: true, selector: "ndt-users-icon", inputs: { fill: { classPropertyName: "fill", publicName: "fill", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M224,128a95.76,95.76,0,0,1-31.8,71.37A72,72,0,0,0,128,160a40,40,0,1,0-40-40,40,40,0,0,0,40,40,72,72,0,0,0-64.2,39.37h0A96,96,0,1,1,224,128Z"
        opacity="0.2"
      ></path>
      <path
        d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24ZM74.08,197.5a64,64,0,0,1,107.84,0,87.83,87.83,0,0,1-107.84,0ZM96,120a32,32,0,1,1,32,32A32,32,0,0,1,96,120Zm97.76,66.41a79.66,79.66,0,0,0-36.06-28.75,48,48,0,1,0-59.4,0,79.66,79.66,0,0,0-36.06,28.75,88,88,0,1,1,131.52,0Z"
      ></path>
    </svg>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: UsersIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-users-icon',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <svg
      [attr.fill]="fill()"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 256 256"
    >
      <path
        d="M224,128a95.76,95.76,0,0,1-31.8,71.37A72,72,0,0,0,128,160a40,40,0,1,0-40-40,40,40,0,0,0,40,40,72,72,0,0,0-64.2,39.37h0A96,96,0,1,1,224,128Z"
        opacity="0.2"
      ></path>
      <path
        d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24ZM74.08,197.5a64,64,0,0,1,107.84,0,87.83,87.83,0,0,1-107.84,0ZM96,120a32,32,0,1,1,32,32A32,32,0,0,1,96,120Zm97.76,66.41a79.66,79.66,0,0,0-36.06-28.75,48,48,0,1,0-59.4,0,79.66,79.66,0,0,0-36.06,28.75,88,88,0,1,1,131.52,0Z"
      ></path>
    </svg>
  `,
                }]
        }] });

class ToolbarIconComponent {
    constructor() {
        this.stateService = inject(ToolbarStateService);
        this.name = input.required();
        this.fill = computed(() => this.stateService.theme() === 'dark' ? '#FFFFFF' : '#000000');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarIconComponent, isStandalone: true, selector: "ndt-icon", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    @switch (name()) { @case ('angular') {
    <ndt-angular-icon />
    } @case ('bolt') {
    <ndt-bolt-icon [fill]="fill()" />
    } @case ('bug') {
    <ndt-bug-icon [fill]="fill()" />
    } @case ('code') {
    <ndt-code-icon [fill]="fill()" />
    } @case ('database') {
    <ndt-database-icon [fill]="fill()" />
    } @case ('docs') {
    <ndt-docs-icon [fill]="fill()" />
    } @case ('edit') {
    <ndt-edit-icon [fill]="fill()" />
    } @case ('export') {
    <ndt-export-icon [fill]="fill()" />
    } @case ('filter') {
    <ndt-filter-icon [fill]="fill()" />
    } @case ('gauge') {
    <ndt-gauge-icon [fill]="fill()" />
    } @case ('gear') {
    <ndt-gear-icon [fill]="fill()" />
    } @case ('git-branch') {
    <ndt-git-branch-icon [fill]="fill()" />
    } @case ('globe') {
    <ndt-globe-icon [fill]="fill()" />
    } @case ('import') {
    <ndt-import-icon [fill]="fill()" />
    } @case ('layout') {
    <ndt-layout-icon [fill]="fill()" />
    } @case ('lighting') {
    <ndt-lighting-icon [fill]="fill()" />
    } @case ('lightbulb') {
    <ndt-lightbulb-icon [fill]="fill()" />
    } @case ('lock') {
    <ndt-lock-icon [fill]="fill()" />
    } @case ('network') {
    <ndt-network-icon [fill]="fill()" />
    } @case ('pin') {
    <ndt-pin-icon [fill]="fill()" />
    } @case ('puzzle') {
    <ndt-puzzle-icon [fill]="fill()" />
    } @case ('refresh') {
    <ndt-refresh-icon [fill]="fill()" />
    } @case ('star') {
    <ndt-star-icon [fill]="fill()" />
    } @case ('terminal') {
    <ndt-terminal-icon [fill]="fill()" />
    } @case ('toggle-left') {
    <ndt-toggle-left-icon [fill]="fill()" />
    } @case ('user') {
    <ndt-users-icon [fill]="fill()" />
    } @case ('sun') {
    <ndt-sun-icon [fill]="fill()" />
    } @case ('moon') {
    <ndt-moon-icon [fill]="fill()" />
    } @case ('translate') {
    <ndt-translate-icon [fill]="fill()" />
    } @case ('discord') {
    <ndt-discord-icon [fill]="fill()" />
    } @case ('trash') {
    <ndt-trash-icon [fill]="fill()" />
    } }
  `, isInline: true, dependencies: [{ kind: "component", type: AngularIconComponent, selector: "ndt-angular-icon" }, { kind: "component", type: BoltIconComponent, selector: "ndt-bolt-icon", inputs: ["fill"] }, { kind: "component", type: BugIconComponent, selector: "ndt-bug-icon", inputs: ["fill"] }, { kind: "component", type: CodeIconComponent, selector: "ndt-code-icon", inputs: ["fill"] }, { kind: "component", type: DatabaseIconComponent, selector: "ndt-database-icon", inputs: ["fill"] }, { kind: "component", type: DocsIconComponent, selector: "ndt-docs-icon", inputs: ["fill"] }, { kind: "component", type: DiscordIconComponent, selector: "ndt-discord-icon", inputs: ["fill"] }, { kind: "component", type: EditIconComponent, selector: "ndt-edit-icon", inputs: ["fill"] }, { kind: "component", type: ExportIconComponent, selector: "ndt-export-icon", inputs: ["fill"] }, { kind: "component", type: FilterIconComponent, selector: "ndt-filter-icon", inputs: ["fill"] }, { kind: "component", type: GaugeIconComponent, selector: "ndt-gauge-icon", inputs: ["fill"] }, { kind: "component", type: GearIconComponent, selector: "ndt-gear-icon", inputs: ["fill"] }, { kind: "component", type: GitBranchIconComponent, selector: "ndt-git-branch-icon", inputs: ["fill"] }, { kind: "component", type: GlobeIconComponent, selector: "ndt-globe-icon", inputs: ["fill"] }, { kind: "component", type: ImportIconComponent, selector: "ndt-import-icon", inputs: ["fill"] }, { kind: "component", type: LayoutIconComponent, selector: "ndt-layout-icon", inputs: ["fill"] }, { kind: "component", type: LightbulbIconComponent, selector: "ndt-lightbulb-icon", inputs: ["fill"] }, { kind: "component", type: LightingIconComponent, selector: "ndt-lighting-icon", inputs: ["fill"] }, { kind: "component", type: LockIconComponent, selector: "ndt-lock-icon", inputs: ["fill"] }, { kind: "component", type: NetworkIconComponent, selector: "ndt-network-icon", inputs: ["fill"] }, { kind: "component", type: PinIconComponent, selector: "ndt-pin-icon", inputs: ["fill"] }, { kind: "component", type: PuzzleIconComponent, selector: "ndt-puzzle-icon", inputs: ["fill"] }, { kind: "component", type: RefreshIconComponent, selector: "ndt-refresh-icon", inputs: ["fill"] }, { kind: "component", type: StarIconComponent, selector: "ndt-star-icon", inputs: ["fill"] }, { kind: "component", type: TerminalIconComponent, selector: "ndt-terminal-icon", inputs: ["fill"] }, { kind: "component", type: ToggleLeftIconComponent, selector: "ndt-toggle-left-icon", inputs: ["fill"] }, { kind: "component", type: UsersIconComponent, selector: "ndt-users-icon", inputs: ["fill"] }, { kind: "component", type: SunIconComponent, selector: "ndt-sun-icon", inputs: ["fill"] }, { kind: "component", type: MoonIconComponent, selector: "ndt-moon-icon", inputs: ["fill"] }, { kind: "component", type: TranslateIconComponent, selector: "ndt-translate-icon", inputs: ["fill"] }, { kind: "component", type: TrashIconComponent, selector: "ndt-trash-icon", inputs: ["fill"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ndt-icon',
                    standalone: true,
                    imports: [
                        AngularIconComponent,
                        BoltIconComponent,
                        BugIconComponent,
                        CodeIconComponent,
                        DatabaseIconComponent,
                        DocsIconComponent,
                        DiscordIconComponent,
                        EditIconComponent,
                        ExportIconComponent,
                        FilterIconComponent,
                        GaugeIconComponent,
                        GearIconComponent,
                        GitBranchIconComponent,
                        GlobeIconComponent,
                        ImportIconComponent,
                        LayoutIconComponent,
                        LightbulbIconComponent,
                        LightingIconComponent,
                        LockIconComponent,
                        NetworkIconComponent,
                        PinIconComponent,
                        PuzzleIconComponent,
                        RefreshIconComponent,
                        StarIconComponent,
                        TerminalIconComponent,
                        ToggleLeftIconComponent,
                        UsersIconComponent,
                        SunIconComponent,
                        MoonIconComponent,
                        TranslateIconComponent,
                        TrashIconComponent,
                    ],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    @switch (name()) { @case ('angular') {
    <ndt-angular-icon />
    } @case ('bolt') {
    <ndt-bolt-icon [fill]="fill()" />
    } @case ('bug') {
    <ndt-bug-icon [fill]="fill()" />
    } @case ('code') {
    <ndt-code-icon [fill]="fill()" />
    } @case ('database') {
    <ndt-database-icon [fill]="fill()" />
    } @case ('docs') {
    <ndt-docs-icon [fill]="fill()" />
    } @case ('edit') {
    <ndt-edit-icon [fill]="fill()" />
    } @case ('export') {
    <ndt-export-icon [fill]="fill()" />
    } @case ('filter') {
    <ndt-filter-icon [fill]="fill()" />
    } @case ('gauge') {
    <ndt-gauge-icon [fill]="fill()" />
    } @case ('gear') {
    <ndt-gear-icon [fill]="fill()" />
    } @case ('git-branch') {
    <ndt-git-branch-icon [fill]="fill()" />
    } @case ('globe') {
    <ndt-globe-icon [fill]="fill()" />
    } @case ('import') {
    <ndt-import-icon [fill]="fill()" />
    } @case ('layout') {
    <ndt-layout-icon [fill]="fill()" />
    } @case ('lighting') {
    <ndt-lighting-icon [fill]="fill()" />
    } @case ('lightbulb') {
    <ndt-lightbulb-icon [fill]="fill()" />
    } @case ('lock') {
    <ndt-lock-icon [fill]="fill()" />
    } @case ('network') {
    <ndt-network-icon [fill]="fill()" />
    } @case ('pin') {
    <ndt-pin-icon [fill]="fill()" />
    } @case ('puzzle') {
    <ndt-puzzle-icon [fill]="fill()" />
    } @case ('refresh') {
    <ndt-refresh-icon [fill]="fill()" />
    } @case ('star') {
    <ndt-star-icon [fill]="fill()" />
    } @case ('terminal') {
    <ndt-terminal-icon [fill]="fill()" />
    } @case ('toggle-left') {
    <ndt-toggle-left-icon [fill]="fill()" />
    } @case ('user') {
    <ndt-users-icon [fill]="fill()" />
    } @case ('sun') {
    <ndt-sun-icon [fill]="fill()" />
    } @case ('moon') {
    <ndt-moon-icon [fill]="fill()" />
    } @case ('translate') {
    <ndt-translate-icon [fill]="fill()" />
    } @case ('discord') {
    <ndt-discord-icon [fill]="fill()" />
    } @case ('trash') {
    <ndt-trash-icon [fill]="fill()" />
    } }
  `,
                }]
        }] });

class ToolbarIconButtonComponent {
    constructor() {
        this.icon = input();
        this.tooltip = input();
        this.ariaLabel = input();
        this.size = input('sm');
        this.variant = input('ghost');
        this.isHovered = signal(false);
        this.isTooltipVisible = computed(() => !!this.tooltip() && this.isHovered());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarIconButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarIconButtonComponent, isStandalone: true, selector: "ndt-icon-button", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, tooltip: { classPropertyName: "tooltip", publicName: "tooltip", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <button
      class="icon-button"
      [class.icon-button--sm]="size() === 'sm'"
      [class.icon-button--md]="size() === 'md'"
      [class.icon-button--outlined]="variant() === 'outlined'"
      [attr.aria-label]="ariaLabel() || tooltip()"
      (mouseenter)="isHovered.set(true)"
      (mouseleave)="isHovered.set(false)"
    >
      @if (isTooltipVisible()) {
        <span class="tooltip" [class.tooltip--visible]="isHovered()">
          {{ tooltip() }}
        </span>
      }
      @if (icon()) {
        <ndt-icon [name]="icon()!" />
      }
      <ng-content />
    </button>
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:inline-flex}.icon-button{appearance:none;background:none;border:none;cursor:pointer;margin:0;padding:0;border-radius:var(--ndt-border-radius-small);color:var(--ndt-text-muted);display:flex;align-items:center;justify-content:center;opacity:.6;transition:opacity .15s ease-out,color .15s ease-out,background .15s ease-out,border-color .15s ease-out;line-height:0;flex-shrink:0;position:relative}.icon-button--sm{width:22px;height:22px}.icon-button--sm ::ng-deep svg{width:12px;height:12px;display:block}.icon-button--md{width:28px;height:28px}.icon-button--md ::ng-deep svg{width:16px;height:16px;display:block}.icon-button--outlined{border:1px solid var(--ndt-border-primary)}.icon-button:hover{background:var(--ndt-hover-bg);color:var(--ndt-text-primary);opacity:1}.tooltip{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translate(-50%);background:var(--ndt-tooltip-bg);color:var(--ndt-tooltip-text);padding:3px 8px;border-radius:var(--ndt-border-radius-small);font-size:10px;font-weight:500;line-height:normal;white-space:nowrap;pointer-events:none;opacity:0;transition:opacity .15s ease-out;z-index:9999;box-shadow:var(--ndt-shadow-tooltip)}.tooltip--visible{opacity:1}.tooltip:after{content:\"\";position:absolute;top:100%;left:50%;transform:translate(-50%);border:4px solid transparent;border-top-color:var(--ndt-tooltip-bg)}\n"], dependencies: [{ kind: "component", type: ToolbarIconComponent, selector: "ndt-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarIconButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-icon-button', standalone: true, imports: [ToolbarIconComponent], template: `
    <button
      class="icon-button"
      [class.icon-button--sm]="size() === 'sm'"
      [class.icon-button--md]="size() === 'md'"
      [class.icon-button--outlined]="variant() === 'outlined'"
      [attr.aria-label]="ariaLabel() || tooltip()"
      (mouseenter)="isHovered.set(true)"
      (mouseleave)="isHovered.set(false)"
    >
      @if (isTooltipVisible()) {
        <span class="tooltip" [class.tooltip--visible]="isHovered()">
          {{ tooltip() }}
        </span>
      }
      @if (icon()) {
        <ndt-icon [name]="icon()!" />
      }
      <ng-content />
    </button>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:inline-flex}.icon-button{appearance:none;background:none;border:none;cursor:pointer;margin:0;padding:0;border-radius:var(--ndt-border-radius-small);color:var(--ndt-text-muted);display:flex;align-items:center;justify-content:center;opacity:.6;transition:opacity .15s ease-out,color .15s ease-out,background .15s ease-out,border-color .15s ease-out;line-height:0;flex-shrink:0;position:relative}.icon-button--sm{width:22px;height:22px}.icon-button--sm ::ng-deep svg{width:12px;height:12px;display:block}.icon-button--md{width:28px;height:28px}.icon-button--md ::ng-deep svg{width:16px;height:16px;display:block}.icon-button--outlined{border:1px solid var(--ndt-border-primary)}.icon-button:hover{background:var(--ndt-hover-bg);color:var(--ndt-text-primary);opacity:1}.tooltip{position:absolute;bottom:calc(100% + 8px);left:50%;transform:translate(-50%);background:var(--ndt-tooltip-bg);color:var(--ndt-tooltip-text);padding:3px 8px;border-radius:var(--ndt-border-radius-small);font-size:10px;font-weight:500;line-height:normal;white-space:nowrap;pointer-events:none;opacity:0;transition:opacity .15s ease-out;z-index:9999;box-shadow:var(--ndt-shadow-tooltip)}.tooltip--visible{opacity:1}.tooltip:after{content:\"\";position:absolute;top:100%;left:50%;transform:translate(-50%);border:4px solid transparent;border-top-color:var(--ndt-tooltip-bg)}\n"] }]
        }] });

/**
 * List item component with consistent layout, dot badge indicator,
 * and forced state highlighting.
 *
 * @example
 * ```html
 * <ndt-list-item
 *   title="Analytics Dashboard"
 *   description="Advanced reporting tools"
 *   [isForced]="false"
 *   [currentValue]="true"
 *   [originalValue]="undefined"
 * >
 *   <ndt-select ... />
 * </ndt-list-item>
 * ```
 */
class ToolbarListItemComponent {
    constructor() {
        /**
         * Display title for the list item
         * @example "Analytics Dashboard"
         */
        this.title = input.required();
        /**
         * Optional description text
         * @example "Advanced reporting and data visualization tools"
         */
        this.description = input(undefined);
        /**
         * Whether this item's state is forced via the dev toolbar
         */
        this.isForced = input(false);
        /**
         * Current enabled/granted state of the item
         */
        this.currentValue = input.required();
        /**
         * Original value before forcing (only present when isForced is true)
         */
        this.originalValue = input(undefined);
        /**
         * Whether to show the "Apply to source" button
         */
        this.showApply = input(false);
        /**
         * Current state of the apply operation
         */
        this.applyState = input('idle');
        /**
         * Whether this item is pinned to the top of the list
         */
        this.isPinned = input(false);
        /**
         * Optional identifier that can be copied to clipboard (e.g., flag ID).
         * When provided, renders a copy button in the action row.
         */
        this.copyableId = input(undefined);
        /**
         * Emits when the user clicks the pin/unpin button
         */
        this.pinToggle = output();
        /**
         * Emits when the user clicks "Apply to source"
         */
        this.applyToSource = output();
        this.pinIcon = computed(() => 'pin');
        this.pinAriaLabel = computed(() => this.isPinned() ? 'Unpin item' : 'Pin item');
        /**
         * Source-of-truth value for the dot indicator. When an item is forced and the
         * upstream original value is known, surface that; otherwise fall back to
         * currentValue. Decouples the dot color from the developer's override so the
         * server-reported state remains visible at a glance.
         */
        this.sourceValue = computed(() => {
            const original = this.originalValue();
            return this.isForced() && original !== undefined ? original : this.currentValue();
        });
        /**
         * Tooltip text explaining the current state, with override context when forced
         */
        this.tooltipText = computed(() => {
            const current = this.currentValue() ? 'enabled' : 'disabled';
            const original = this.originalValue();
            if (this.isForced() && original !== undefined && original !== this.currentValue()) {
                const originalLabel = original ? 'enabled' : 'disabled';
                return `Server: ${originalLabel} · Forced: ${current}`;
            }
            return `Currently ${current}`;
        });
        this.statusAriaLabel = computed(() => {
            const source = this.sourceValue() ? 'enabled' : 'disabled';
            return this.isForced() ? `${source}, forced` : source;
        });
        this.copyState = signal('idle');
        this.copyAriaLabel = computed(() => {
            const id = this.copyableId();
            return id ? `Copy ID "${id}" to clipboard` : 'Copy ID';
        });
    }
    async copyId(event) {
        event.stopPropagation();
        const id = this.copyableId();
        if (!id)
            return;
        try {
            await navigator.clipboard.writeText(id);
            this.copyState.set('copied');
            setTimeout(() => this.copyState.set('idle'), 1500);
        }
        catch {
            this.copyState.set('idle');
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarListItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarListItemComponent, isStandalone: true, selector: "ndt-list-item", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, isForced: { classPropertyName: "isForced", publicName: "isForced", isSignal: true, isRequired: false, transformFunction: null }, currentValue: { classPropertyName: "currentValue", publicName: "currentValue", isSignal: true, isRequired: true, transformFunction: null }, originalValue: { classPropertyName: "originalValue", publicName: "originalValue", isSignal: true, isRequired: false, transformFunction: null }, showApply: { classPropertyName: "showApply", publicName: "showApply", isSignal: true, isRequired: false, transformFunction: null }, applyState: { classPropertyName: "applyState", publicName: "applyState", isSignal: true, isRequired: false, transformFunction: null }, isPinned: { classPropertyName: "isPinned", publicName: "isPinned", isSignal: true, isRequired: false, transformFunction: null }, copyableId: { classPropertyName: "copyableId", publicName: "copyableId", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { pinToggle: "pinToggle", applyToSource: "applyToSource" }, ngImport: i0, template: `
    <div class="list-item" [class.list-item--forced]="isForced()">
      <span
        class="dot-indicator"
        [class.dot-indicator--on]="sourceValue()"
        [class.dot-indicator--off]="!sourceValue()"
        [class.dot-indicator--forced]="isForced()"
        [title]="tooltipText()"
        [attr.aria-label]="statusAriaLabel()"
        role="img"
      ></span>
      <div class="info">
        <h3>{{ title() }}</h3>
        @if (description()) {
          <p>{{ description() }}</p>
        }
      </div>
      <div class="actions">
        @if (copyableId()) {
          <button
            type="button"
            class="copy-button"
            [class.copy-button--copied]="copyState() === 'copied'"
            [attr.aria-label]="copyAriaLabel()"
            [title]="copyState() === 'copied' ? 'Copied!' : 'Copy ID'"
            (click)="copyId($event)"
          >
            @if (copyState() === 'copied') {
              <span aria-hidden="true">✓</span>
            } @else {
              <span aria-hidden="true" class="copy-icon">⧉</span>
            }
          </button>
        }
        @if (showApply() && isForced()) {
          <ndt-icon-button
            [icon]="applyState() === 'idle' ? 'export' : undefined"
            tooltip="Apply to source"
            variant="outlined"
            class="apply-button"
            [class.apply-button--loading]="applyState() === 'loading'"
            [class.apply-button--success]="applyState() === 'success'"
            [class.apply-button--error]="applyState() === 'error'"
            (click)="applyToSource.emit()"
          >
            @switch (applyState()) {
              @case ('loading') {
                <span class="apply-spinner"></span>
              }
              @case ('success') {
                <span class="apply-icon" aria-hidden="true">✓</span>
              }
              @case ('error') {
                <span class="apply-icon" aria-hidden="true">✕</span>
              }
            }
          </ndt-icon-button>
        }
        <ng-content />
        <ndt-icon-button
          [icon]="pinIcon()"
          [ariaLabel]="pinAriaLabel()"
          variant="ghost"
          class="pin-button"
          [class.pin-button--pinned]="isPinned()"
          (click)="pinToggle.emit(); $event.stopPropagation()"
        />
      </div>
    </div>
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.list-item{display:flex;flex-direction:row;align-items:flex-start;gap:var(--ndt-spacing-sm);background:var(--ndt-background-secondary);padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-medium);transition:background-color .28s cubic-bezier(.22,1,.36,1);position:relative;z-index:1;flex-shrink:0;overflow:visible}.list-item.list-item--forced{background:rgba(var(--ndt-forced-rgb),.1);box-shadow:inset 0 0 0 1px rgba(var(--ndt-forced-rgb),.25)}.list-item>.dot-indicator{flex:0 0 auto;display:inline-block;width:8px;height:8px;border-radius:50%;cursor:help;transition:background-color .26s cubic-bezier(.22,1,.36,1),border-color .26s cubic-bezier(.22,1,.36,1),box-shadow .26s cubic-bezier(.22,1,.36,1);margin-top:7px;box-sizing:border-box}@media (prefers-reduced-motion: reduce){.list-item,.list-item>.dot-indicator{transition:none}}.list-item>.dot-indicator.dot-indicator--on{background:var(--ndt-success);box-shadow:0 0 0 2px rgba(var(--ndt-success-rgb),.2)}.list-item>.dot-indicator.dot-indicator--off{background:transparent;border:1.5px solid var(--ndt-danger);box-shadow:0 0 0 2px rgba(var(--ndt-danger-rgb),.12)}.list-item .info{flex:1 1 auto;min-width:0}.list-item .info h3{margin:0;font-size:var(--ndt-font-size-sm);font-weight:500;color:var(--ndt-text-primary);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.list-item .info p{margin:1px 0 0;font-size:var(--ndt-font-size-xxs);color:var(--ndt-text-muted);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.list-item .actions{flex:0 0 auto;display:flex;align-items:center;justify-content:flex-end;gap:4px;overflow:visible}.pin-button{flex:0 0 auto;opacity:0;transition:opacity .2s ease}.pin-button ::ng-deep .icon-button{width:14px;height:14px;padding:0;box-sizing:border-box;background:transparent}.pin-button ::ng-deep .icon-button ::ng-deep svg{width:12px;height:12px}.pin-button ::ng-deep .icon-button:hover{background:transparent;color:var(--ndt-text-primary);opacity:1}.list-item:hover .pin-button,.list-item:focus-within .pin-button{opacity:.5}.list-item:hover .pin-button:hover,.list-item:focus-within .pin-button:focus-visible{opacity:1}.pin-button--pinned{opacity:1}.pin-button--pinned ::ng-deep .icon-button{opacity:1;color:var(--ndt-primary);background:transparent}.copy-button{appearance:none;border:0;background:transparent;color:var(--ndt-text-muted);width:18px;height:18px;padding:0;display:flex;align-items:center;justify-content:center;border-radius:var(--ndt-border-radius-small);cursor:pointer;font-size:12px;line-height:1;opacity:0;transition:opacity .2s ease,color .15s ease,background-color .15s ease}.copy-button:hover{background:var(--ndt-hover-bg);color:var(--ndt-text-primary)}.copy-button:focus-visible{opacity:1;outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:1px}.copy-button .copy-icon{font-family:ui-monospace,monospace}.list-item:hover .copy-button,.list-item:focus-within .copy-button{opacity:.6}.list-item:hover .copy-button:hover{opacity:1}.copy-button--copied{opacity:1!important;color:var(--ndt-success)}.apply-button--loading ::ng-deep .icon-button{opacity:1;animation:apply-pulse 1s ease-in-out infinite}.apply-button--success ::ng-deep .icon-button{opacity:1;color:var(--ndt-success);border-color:rgba(var(--ndt-success-rgb),.3);background:rgba(var(--ndt-success-rgb),.05)}.apply-button--error ::ng-deep .icon-button{opacity:1;color:var(--ndt-danger);border-color:rgba(var(--ndt-danger-rgb),.3);background:rgba(var(--ndt-danger-rgb),.05)}.apply-icon{font-size:10px;line-height:1}.apply-spinner{display:block;width:10px;height:10px;border:1.5px solid var(--ndt-border-primary);border-top-color:var(--ndt-text-primary);border-radius:50%;animation:apply-spin .6s linear infinite}@keyframes apply-pulse{0%,to{opacity:.5}50%{opacity:1}}@keyframes apply-spin{to{transform:rotate(360deg)}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: ToolbarIconButtonComponent, selector: "ndt-icon-button", inputs: ["icon", "tooltip", "ariaLabel", "size", "variant"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarListItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-list-item', standalone: true, imports: [CommonModule, ToolbarIconButtonComponent], template: `
    <div class="list-item" [class.list-item--forced]="isForced()">
      <span
        class="dot-indicator"
        [class.dot-indicator--on]="sourceValue()"
        [class.dot-indicator--off]="!sourceValue()"
        [class.dot-indicator--forced]="isForced()"
        [title]="tooltipText()"
        [attr.aria-label]="statusAriaLabel()"
        role="img"
      ></span>
      <div class="info">
        <h3>{{ title() }}</h3>
        @if (description()) {
          <p>{{ description() }}</p>
        }
      </div>
      <div class="actions">
        @if (copyableId()) {
          <button
            type="button"
            class="copy-button"
            [class.copy-button--copied]="copyState() === 'copied'"
            [attr.aria-label]="copyAriaLabel()"
            [title]="copyState() === 'copied' ? 'Copied!' : 'Copy ID'"
            (click)="copyId($event)"
          >
            @if (copyState() === 'copied') {
              <span aria-hidden="true">✓</span>
            } @else {
              <span aria-hidden="true" class="copy-icon">⧉</span>
            }
          </button>
        }
        @if (showApply() && isForced()) {
          <ndt-icon-button
            [icon]="applyState() === 'idle' ? 'export' : undefined"
            tooltip="Apply to source"
            variant="outlined"
            class="apply-button"
            [class.apply-button--loading]="applyState() === 'loading'"
            [class.apply-button--success]="applyState() === 'success'"
            [class.apply-button--error]="applyState() === 'error'"
            (click)="applyToSource.emit()"
          >
            @switch (applyState()) {
              @case ('loading') {
                <span class="apply-spinner"></span>
              }
              @case ('success') {
                <span class="apply-icon" aria-hidden="true">✓</span>
              }
              @case ('error') {
                <span class="apply-icon" aria-hidden="true">✕</span>
              }
            }
          </ndt-icon-button>
        }
        <ng-content />
        <ndt-icon-button
          [icon]="pinIcon()"
          [ariaLabel]="pinAriaLabel()"
          variant="ghost"
          class="pin-button"
          [class.pin-button--pinned]="isPinned()"
          (click)="pinToggle.emit(); $event.stopPropagation()"
        />
      </div>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.list-item{display:flex;flex-direction:row;align-items:flex-start;gap:var(--ndt-spacing-sm);background:var(--ndt-background-secondary);padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-medium);transition:background-color .28s cubic-bezier(.22,1,.36,1);position:relative;z-index:1;flex-shrink:0;overflow:visible}.list-item.list-item--forced{background:rgba(var(--ndt-forced-rgb),.1);box-shadow:inset 0 0 0 1px rgba(var(--ndt-forced-rgb),.25)}.list-item>.dot-indicator{flex:0 0 auto;display:inline-block;width:8px;height:8px;border-radius:50%;cursor:help;transition:background-color .26s cubic-bezier(.22,1,.36,1),border-color .26s cubic-bezier(.22,1,.36,1),box-shadow .26s cubic-bezier(.22,1,.36,1);margin-top:7px;box-sizing:border-box}@media (prefers-reduced-motion: reduce){.list-item,.list-item>.dot-indicator{transition:none}}.list-item>.dot-indicator.dot-indicator--on{background:var(--ndt-success);box-shadow:0 0 0 2px rgba(var(--ndt-success-rgb),.2)}.list-item>.dot-indicator.dot-indicator--off{background:transparent;border:1.5px solid var(--ndt-danger);box-shadow:0 0 0 2px rgba(var(--ndt-danger-rgb),.12)}.list-item .info{flex:1 1 auto;min-width:0}.list-item .info h3{margin:0;font-size:var(--ndt-font-size-sm);font-weight:500;color:var(--ndt-text-primary);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.list-item .info p{margin:1px 0 0;font-size:var(--ndt-font-size-xxs);color:var(--ndt-text-muted);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.list-item .actions{flex:0 0 auto;display:flex;align-items:center;justify-content:flex-end;gap:4px;overflow:visible}.pin-button{flex:0 0 auto;opacity:0;transition:opacity .2s ease}.pin-button ::ng-deep .icon-button{width:14px;height:14px;padding:0;box-sizing:border-box;background:transparent}.pin-button ::ng-deep .icon-button ::ng-deep svg{width:12px;height:12px}.pin-button ::ng-deep .icon-button:hover{background:transparent;color:var(--ndt-text-primary);opacity:1}.list-item:hover .pin-button,.list-item:focus-within .pin-button{opacity:.5}.list-item:hover .pin-button:hover,.list-item:focus-within .pin-button:focus-visible{opacity:1}.pin-button--pinned{opacity:1}.pin-button--pinned ::ng-deep .icon-button{opacity:1;color:var(--ndt-primary);background:transparent}.copy-button{appearance:none;border:0;background:transparent;color:var(--ndt-text-muted);width:18px;height:18px;padding:0;display:flex;align-items:center;justify-content:center;border-radius:var(--ndt-border-radius-small);cursor:pointer;font-size:12px;line-height:1;opacity:0;transition:opacity .2s ease,color .15s ease,background-color .15s ease}.copy-button:hover{background:var(--ndt-hover-bg);color:var(--ndt-text-primary)}.copy-button:focus-visible{opacity:1;outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:1px}.copy-button .copy-icon{font-family:ui-monospace,monospace}.list-item:hover .copy-button,.list-item:focus-within .copy-button{opacity:.6}.list-item:hover .copy-button:hover{opacity:1}.copy-button--copied{opacity:1!important;color:var(--ndt-success)}.apply-button--loading ::ng-deep .icon-button{opacity:1;animation:apply-pulse 1s ease-in-out infinite}.apply-button--success ::ng-deep .icon-button{opacity:1;color:var(--ndt-success);border-color:rgba(var(--ndt-success-rgb),.3);background:rgba(var(--ndt-success-rgb),.05)}.apply-button--error ::ng-deep .icon-button{opacity:1;color:var(--ndt-danger);border-color:rgba(var(--ndt-danger-rgb),.3);background:rgba(var(--ndt-danger-rgb),.05)}.apply-icon{font-size:10px;line-height:1}.apply-spinner{display:block;width:10px;height:10px;border:1.5px solid var(--ndt-border-primary);border-top-color:var(--ndt-text-primary);border-radius:50%;animation:apply-spin .6s linear infinite}@keyframes apply-pulse{0%,to{opacity:.5}50%{opacity:1}}@keyframes apply-spin{to{transform:rotate(360deg)}}\n"] }]
        }] });

/**
 * Container component for displaying lists of items with consistent scrolling,
 * empty states, and layout across all tools.
 *
 * @example
 * ```html
 * <ndt-list
 *   [hasItems]="items().length > 0"
 *   [hasResults]="filteredItems().length > 0"
 *   emptyMessage="No items found"
 *   noResultsMessage="No items match your filter"
 * >
 *   @for (item of filteredItems(); track item.id) {
 *     <ndt-list-item ... />
 *   }
 * </ndt-list>
 * ```
 */
class ToolbarListComponent {
    constructor() {
        /**
         * Whether the list has any items at all (before filtering).
         * When false, shows the emptyMessage.
         */
        this.hasItems = input(true);
        /**
         * Whether the list has any results after filtering.
         * When false (but hasItems is true), shows the noResultsMessage.
         */
        this.hasResults = input(true);
        /**
         * Message to display when there are no items at all.
         * @example "No feature flags found"
         */
        this.emptyMessage = input('No items found');
        /**
         * Optional hint text to display below the empty message.
         * @example "Call setAvailableOptions() to configure features"
         */
        this.emptyHint = input(undefined);
        /**
         * Message to display when items exist but none match the current filter.
         * @example "No flags match your filter"
         */
        this.noResultsMessage = input('No results match your filter');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarListComponent, isStandalone: true, selector: "ndt-list", inputs: { hasItems: { classPropertyName: "hasItems", publicName: "hasItems", isSignal: true, isRequired: false, transformFunction: null }, hasResults: { classPropertyName: "hasResults", publicName: "hasResults", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, emptyHint: { classPropertyName: "emptyHint", publicName: "emptyHint", isSignal: true, isRequired: false, transformFunction: null }, noResultsMessage: { classPropertyName: "noResultsMessage", publicName: "noResultsMessage", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    @if (!hasItems()) {
      <div class="empty-state">
        <p>{{ emptyMessage() }}</p>
        @if (emptyHint()) {
          <p class="hint">{{ emptyHint() }}</p>
        }
      </div>
    } @else if (!hasResults()) {
      <div class="empty-state">
        <p>{{ noResultsMessage() }}</p>
      </div>
    } @else {
      <div class="list-container">
        <ng-content />
      </div>
    }
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:flex;flex-direction:column;flex:1;min-height:0}.empty-state{display:flex;flex-direction:column;gap:var(--ndt-spacing-md);flex:1;min-height:0;justify-content:center;align-items:center;border:1px dashed var(--ndt-border-primary);border-radius:var(--ndt-border-radius-medium);padding:var(--ndt-spacing-md);background:var(--ndt-background-secondary);color:var(--ndt-text-muted)}.empty-state p{margin:0}.empty-state .hint{font-size:var(--ndt-font-size-xs)}.list-container{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);padding-top:var(--ndt-spacing-sm);flex:1;min-height:0;max-height:100%;overflow-y:auto;overflow-x:hidden;position:relative;scrollbar-width:thin;scrollbar-color:var(--ndt-border-primary) var(--ndt-background-secondary)}.list-container::-webkit-scrollbar{width:8px;height:8px}.list-container::-webkit-scrollbar-track{background:transparent}.list-container::-webkit-scrollbar-thumb{background-color:var(--ndt-border-primary);border-radius:4px;border:2px solid var(--ndt-bg-primary)}.list-container::-webkit-scrollbar-thumb:hover{background-color:var(--ndt-text-secondary)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-list', standalone: true, imports: [CommonModule], template: `
    @if (!hasItems()) {
      <div class="empty-state">
        <p>{{ emptyMessage() }}</p>
        @if (emptyHint()) {
          <p class="hint">{{ emptyHint() }}</p>
        }
      </div>
    } @else if (!hasResults()) {
      <div class="empty-state">
        <p>{{ noResultsMessage() }}</p>
      </div>
    } @else {
      <div class="list-container">
        <ng-content />
      </div>
    }
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:flex;flex-direction:column;flex:1;min-height:0}.empty-state{display:flex;flex-direction:column;gap:var(--ndt-spacing-md);flex:1;min-height:0;justify-content:center;align-items:center;border:1px dashed var(--ndt-border-primary);border-radius:var(--ndt-border-radius-medium);padding:var(--ndt-spacing-md);background:var(--ndt-background-secondary);color:var(--ndt-text-muted)}.empty-state p{margin:0}.empty-state .hint{font-size:var(--ndt-font-size-xs)}.list-container{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);padding-top:var(--ndt-spacing-sm);flex:1;min-height:0;max-height:100%;overflow-y:auto;overflow-x:hidden;position:relative;scrollbar-width:thin;scrollbar-color:var(--ndt-border-primary) var(--ndt-background-secondary)}.list-container::-webkit-scrollbar{width:8px;height:8px}.list-container::-webkit-scrollbar-track{background:transparent}.list-container::-webkit-scrollbar-thumb{background-color:var(--ndt-border-primary);border-radius:4px;border:2px solid var(--ndt-bg-primary)}.list-container::-webkit-scrollbar-thumb:hover{background-color:var(--ndt-text-secondary)}\n"] }]
        }] });

class ToolbarSelectComponent {
    constructor() {
        this.elementRef = inject(ElementRef);
        this.devToolbarStateService = inject(ToolbarStateService);
        this.value = model();
        this.options = input.required();
        this.ariaLabel = input('');
        this.label = input('');
        this.size = input('medium');
        this.placeholder = input('Select an option');
        this.theme = computed(() => this.devToolbarStateService.theme());
        this.selectMenuId = `select-menu-${Math.random()
            .toString(36)
            .slice(2, 11)}`;
        this.isOpen = signal(false);
        this.triggerWidth = signal(0);
        this.isPlaceholder = computed(() => {
            const options = this.options();
            return !!options?.length && !options.some((opt) => opt.value === this.value());
        });
        this.selectedLabel = computed(() => {
            const selected = this.options()?.find((opt) => opt.value === this.value());
            return selected?.label ?? this.placeholder();
        });
        this.positions = [
            {
                originX: 'end',
                originY: 'bottom',
                overlayX: 'end',
                overlayY: 'top',
                offsetY: 4,
            },
            {
                originX: 'end',
                originY: 'top',
                overlayX: 'end',
                overlayY: 'bottom',
                offsetY: -4,
            },
        ];
    }
    toggle() {
        const selectEl = this.elementRef.nativeElement.querySelector('.ndt-select');
        this.triggerWidth.set(selectEl?.offsetWidth ?? 0);
        this.isOpen.update((v) => !v);
    }
    close() {
        this.isOpen.set(false);
    }
    selectOption(option) {
        this.value.set(option.value);
        this.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarSelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarSelectComponent, isStandalone: true, selector: "ndt-select", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, ngImport: i0, template: `
    <div
      class="ndt-select"
      [class.small]="size() === 'small'"
      [class.open]="isOpen()"
      [class.placeholder]="isPlaceholder()"
      [attr.aria-label]="ariaLabel()"
      [attr.aria-expanded]="isOpen()"
      [attr.aria-controls]="selectMenuId"
      [attr.data-theme]="theme()"
      cdkOverlayOrigin
      #trigger="cdkOverlayOrigin"
      (click)="toggle()"
      (keydown.enter)="toggle()"
      (keydown.space)="toggle()"
      tabindex="0"
      role="combobox"
    >
      <span class="select__value">{{ selectedLabel() }}</span>
      <span class="select__arrow" aria-hidden="true"></span>
    </div>

    <ng-template
      cdkConnectedOverlay
      [cdkConnectedOverlayOrigin]="trigger"
      [cdkConnectedOverlayOpen]="isOpen()"
      [cdkConnectedOverlayPositions]="positions"
      [cdkConnectedOverlayMinWidth]="triggerWidth()"
      [cdkConnectedOverlayPanelClass]="['ndt-overlay-panel', 'ndt-select-overlay']"
      (overlayOutsideClick)="close()"
    >
      <div
        [id]="selectMenuId"
        class="ndt-select-menu"
        cdkMenu
        role="listbox"
        [attr.data-theme]="theme()"
      >
        @for (option of options(); track option.value) {
          <button
            class="select-menu-item"
            [class.selected]="option.value === value()"
            [attr.aria-selected]="option.value === value()"
            cdkMenuItem
            type="button"
            (click)="selectOption(option)"
          >
            {{ option.label }}
          </button>
        }
      </div>
    </ng-template>
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:inline-block;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\"}.ndt-select{position:relative;width:100%;min-width:120px;display:flex;align-items:center;justify-content:space-between;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-small);background-color:var(--ndt-bg-primary);color:var(--ndt-text-primary);font-size:var(--ndt-font-size-xs);cursor:pointer;-webkit-user-select:none;user-select:none;transition:var(--ndt-transition-default);outline:none;min-height:28px;box-sizing:border-box;box-shadow:0 1px 2px #0000000d}.ndt-select:hover{background-color:var(--ndt-hover-bg);border-color:var(--ndt-primary);box-shadow:0 1px 3px #0000001a}.ndt-select:focus-visible{outline:none;border-color:var(--ndt-primary);box-shadow:0 0 0 2px rgba(var(--ndt-primary-rgb),.2),0 1px 3px #0000001a}.ndt-select.small{padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);font-size:var(--ndt-font-size-xs);height:22px}.ndt-select.open{border-color:var(--ndt-primary);box-shadow:0 0 0 2px rgba(var(--ndt-primary-rgb),.2),0 1px 3px #0000001a}.ndt-select.open .select__arrow{transform:rotate(180deg)}.ndt-select.placeholder{color:var(--ndt-text-muted)}.ndt-select__value{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:1.4;margin-right:4px;min-width:0;display:flex;align-items:center}.ndt-select__arrow{width:12px;height:12px;flex-shrink:0;background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E\");background-repeat:no-repeat;background-position:center;background-size:contain;transition:transform .2s ease;opacity:.9}.ndt-select-menu{display:inline-flex;flex-direction:column;min-width:120px;background-color:var(--ndt-bg-primary);padding:var(--ndt-spacing-xs) 0;border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-medium);box-shadow:0 4px 12px #00000026,0 2px 4px #0000001a;color:var(--ndt-text-primary);max-height:min(400px,70vh);overflow-y:auto;backdrop-filter:blur(8px);z-index:1000}.ndt-select-menu::-webkit-scrollbar{width:8px;height:8px}.ndt-select-menu::-webkit-scrollbar-track{background:transparent}.ndt-select-menu::-webkit-scrollbar-thumb{background-color:var(--ndt-border-primary);border-radius:4px;border:2px solid var(--ndt-bg-primary)}.ndt-select-menu::-webkit-scrollbar-thumb:hover{background-color:var(--ndt-text-secondary)}.select-menu-item{background-color:transparent;cursor:pointer;border:none;color:var(--ndt-text-primary);-webkit-user-select:none;user-select:none;min-width:64px;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm) var(--ndt-spacing-xs) var(--ndt-spacing-md);display:flex;align-items:center;flex-direction:row;flex:1;font-size:var(--ndt-font-size-xs);font-family:inherit;position:relative;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-weight:400;line-height:1.3;transition:background-color .15s ease}.select-menu-item:hover{background-color:#0000000f}.select-menu-item:active{background-color:rgba(var(--ndt-primary-rgb),.15)}.select-menu-item.selected{color:var(--ndt-primary);background-color:rgba(var(--ndt-primary-rgb),.08);font-weight:400}.select-menu-item.selected:hover{background-color:rgba(var(--ndt-primary-rgb),.12)}.select-menu-item.selected:before{content:\"\";position:absolute;left:0;top:4px;width:3px;height:calc(100% - 8px);background-color:var(--ndt-primary);border-radius:2px}.select-menu-item:focus-visible{outline:none;background-color:#0000000f;box-shadow:inset 0 0 0 2px rgba(var(--ndt-primary-rgb),.5)}.select-menu-item:first-child{margin-top:0}.select-menu-item:last-child{margin-bottom:0}.select-overlay{backdrop-filter:blur(8px)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i1.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i1.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "ngmodule", type: CdkMenuModule }, { kind: "directive", type: i2.CdkMenu, selector: "[cdkMenu]", outputs: ["closed"], exportAs: ["cdkMenu"] }, { kind: "directive", type: i2.CdkMenuItem, selector: "[cdkMenuItem]", inputs: ["cdkMenuItemDisabled", "cdkMenuitemTypeaheadLabel"], outputs: ["cdkMenuItemTriggered"], exportAs: ["cdkMenuItem"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-select', standalone: true, imports: [CommonModule, FormsModule, OverlayModule, CdkMenuModule], template: `
    <div
      class="ndt-select"
      [class.small]="size() === 'small'"
      [class.open]="isOpen()"
      [class.placeholder]="isPlaceholder()"
      [attr.aria-label]="ariaLabel()"
      [attr.aria-expanded]="isOpen()"
      [attr.aria-controls]="selectMenuId"
      [attr.data-theme]="theme()"
      cdkOverlayOrigin
      #trigger="cdkOverlayOrigin"
      (click)="toggle()"
      (keydown.enter)="toggle()"
      (keydown.space)="toggle()"
      tabindex="0"
      role="combobox"
    >
      <span class="select__value">{{ selectedLabel() }}</span>
      <span class="select__arrow" aria-hidden="true"></span>
    </div>

    <ng-template
      cdkConnectedOverlay
      [cdkConnectedOverlayOrigin]="trigger"
      [cdkConnectedOverlayOpen]="isOpen()"
      [cdkConnectedOverlayPositions]="positions"
      [cdkConnectedOverlayMinWidth]="triggerWidth()"
      [cdkConnectedOverlayPanelClass]="['ndt-overlay-panel', 'ndt-select-overlay']"
      (overlayOutsideClick)="close()"
    >
      <div
        [id]="selectMenuId"
        class="ndt-select-menu"
        cdkMenu
        role="listbox"
        [attr.data-theme]="theme()"
      >
        @for (option of options(); track option.value) {
          <button
            class="select-menu-item"
            [class.selected]="option.value === value()"
            [attr.aria-selected]="option.value === value()"
            cdkMenuItem
            type="button"
            (click)="selectOption(option)"
          >
            {{ option.label }}
          </button>
        }
      </div>
    </ng-template>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:inline-block;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\"}.ndt-select{position:relative;width:100%;min-width:120px;display:flex;align-items:center;justify-content:space-between;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-small);background-color:var(--ndt-bg-primary);color:var(--ndt-text-primary);font-size:var(--ndt-font-size-xs);cursor:pointer;-webkit-user-select:none;user-select:none;transition:var(--ndt-transition-default);outline:none;min-height:28px;box-sizing:border-box;box-shadow:0 1px 2px #0000000d}.ndt-select:hover{background-color:var(--ndt-hover-bg);border-color:var(--ndt-primary);box-shadow:0 1px 3px #0000001a}.ndt-select:focus-visible{outline:none;border-color:var(--ndt-primary);box-shadow:0 0 0 2px rgba(var(--ndt-primary-rgb),.2),0 1px 3px #0000001a}.ndt-select.small{padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);font-size:var(--ndt-font-size-xs);height:22px}.ndt-select.open{border-color:var(--ndt-primary);box-shadow:0 0 0 2px rgba(var(--ndt-primary-rgb),.2),0 1px 3px #0000001a}.ndt-select.open .select__arrow{transform:rotate(180deg)}.ndt-select.placeholder{color:var(--ndt-text-muted)}.ndt-select__value{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:1.4;margin-right:4px;min-width:0;display:flex;align-items:center}.ndt-select__arrow{width:12px;height:12px;flex-shrink:0;background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E\");background-repeat:no-repeat;background-position:center;background-size:contain;transition:transform .2s ease;opacity:.9}.ndt-select-menu{display:inline-flex;flex-direction:column;min-width:120px;background-color:var(--ndt-bg-primary);padding:var(--ndt-spacing-xs) 0;border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-medium);box-shadow:0 4px 12px #00000026,0 2px 4px #0000001a;color:var(--ndt-text-primary);max-height:min(400px,70vh);overflow-y:auto;backdrop-filter:blur(8px);z-index:1000}.ndt-select-menu::-webkit-scrollbar{width:8px;height:8px}.ndt-select-menu::-webkit-scrollbar-track{background:transparent}.ndt-select-menu::-webkit-scrollbar-thumb{background-color:var(--ndt-border-primary);border-radius:4px;border:2px solid var(--ndt-bg-primary)}.ndt-select-menu::-webkit-scrollbar-thumb:hover{background-color:var(--ndt-text-secondary)}.select-menu-item{background-color:transparent;cursor:pointer;border:none;color:var(--ndt-text-primary);-webkit-user-select:none;user-select:none;min-width:64px;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm) var(--ndt-spacing-xs) var(--ndt-spacing-md);display:flex;align-items:center;flex-direction:row;flex:1;font-size:var(--ndt-font-size-xs);font-family:inherit;position:relative;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-weight:400;line-height:1.3;transition:background-color .15s ease}.select-menu-item:hover{background-color:#0000000f}.select-menu-item:active{background-color:rgba(var(--ndt-primary-rgb),.15)}.select-menu-item.selected{color:var(--ndt-primary);background-color:rgba(var(--ndt-primary-rgb),.08);font-weight:400}.select-menu-item.selected:hover{background-color:rgba(var(--ndt-primary-rgb),.12)}.select-menu-item.selected:before{content:\"\";position:absolute;left:0;top:4px;width:3px;height:calc(100% - 8px);background-color:var(--ndt-primary);border-radius:2px}.select-menu-item:focus-visible{outline:none;background-color:#0000000f;box-shadow:inset 0 0 0 2px rgba(var(--ndt-primary-rgb),.5)}.select-menu-item:first-child{margin-top:0}.select-menu-item:last-child{margin-bottom:0}.select-overlay{backdrop-filter:blur(8px)}\n"] }]
        }] });

class ToolbarInputComponent {
    constructor() {
        this.value = model.required();
        this.type = input('text');
        this.placeholder = input('');
        this.ariaLabel = input('');
        this.inputClass = input('input');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: ToolbarInputComponent, isStandalone: true, selector: "ndt-input", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, inputClass: { classPropertyName: "inputClass", publicName: "inputClass", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, ngImport: i0, template: `
    <input
      [attr.aria-label]="ariaLabel()"
      [type]="type()"
      [class]="inputClass()"
      [ngModel]="value()"
      [placeholder]="placeholder()"
      (ngModelChange)="value.set($event)"
    />
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:block}.input{width:100%;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-small);background-color:var(--ndt-bg-primary);color:var(--ndt-text-primary);font-size:var(--ndt-font-size-xs);transition:var(--ndt-transition-default);box-sizing:border-box;min-height:28px}.input::placeholder{color:var(--ndt-text-muted)}.input:focus-visible{outline:none;border-color:var(--ndt-primary);box-shadow:0 0 0 2px rgba(var(--ndt-primary-rgb),.2)}.input:disabled{background-color:var(--ndt-bg-secondary);cursor:not-allowed;color:var(--ndt-text-muted)}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-input', standalone: true, imports: [FormsModule], template: `
    <input
      [attr.aria-label]="ariaLabel()"
      [type]="type()"
      [class]="inputClass()"
      [ngModel]="value()"
      [placeholder]="placeholder()"
      (ngModelChange)="value.set($event)"
    />
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:block}.input{width:100%;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-small);background-color:var(--ndt-bg-primary);color:var(--ndt-text-primary);font-size:var(--ndt-font-size-xs);transition:var(--ndt-transition-default);box-sizing:border-box;min-height:28px}.input::placeholder{color:var(--ndt-text-muted)}.input:focus-visible{outline:none;border-color:var(--ndt-primary);box-shadow:0 0 0 2px rgba(var(--ndt-primary-rgb),.2)}.input:disabled{background-color:var(--ndt-bg-secondary);cursor:not-allowed;color:var(--ndt-text-muted)}\n"] }]
        }] });

class ToolbarToolHeaderComponent {
    constructor() {
        this.searchQuery = model('');
        this.activeFilter = model('');
        this.searchPlaceholder = input('Search...');
        this.searchAriaLabel = input('');
        this.filterOptions = input([]);
        this.filterAriaLabel = input('Filter items');
    }
    clearSearch() {
        this.searchQuery.set('');
    }
    onFilterClick(value) {
        this.activeFilter.set(value);
    }
    onFilterKeydown(event, value) {
        const options = this.filterOptions();
        const index = options.findIndex((o) => o.value === value);
        if (index === -1)
            return;
        let nextIndex = index;
        if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
            nextIndex = (index + 1) % options.length;
        }
        else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
            nextIndex = (index - 1 + options.length) % options.length;
        }
        else if (event.key === 'Home') {
            nextIndex = 0;
        }
        else if (event.key === 'End') {
            nextIndex = options.length - 1;
        }
        else {
            return;
        }
        event.preventDefault();
        const next = options[nextIndex];
        this.activeFilter.set(next.value);
        const buttons = event.currentTarget.parentElement?.querySelectorAll('.filter-segment');
        buttons?.[nextIndex]?.focus();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarToolHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarToolHeaderComponent, isStandalone: true, selector: "ndt-tool-header", inputs: { searchQuery: { classPropertyName: "searchQuery", publicName: "searchQuery", isSignal: true, isRequired: false, transformFunction: null }, activeFilter: { classPropertyName: "activeFilter", publicName: "activeFilter", isSignal: true, isRequired: false, transformFunction: null }, searchPlaceholder: { classPropertyName: "searchPlaceholder", publicName: "searchPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, searchAriaLabel: { classPropertyName: "searchAriaLabel", publicName: "searchAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, filterOptions: { classPropertyName: "filterOptions", publicName: "filterOptions", isSignal: true, isRequired: false, transformFunction: null }, filterAriaLabel: { classPropertyName: "filterAriaLabel", publicName: "filterAriaLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { searchQuery: "searchQueryChange", activeFilter: "activeFilterChange" }, ngImport: i0, template: `
    <div class="tool-header">
      <div class="search-wrapper">
        <ndt-input
          [(value)]="searchQuery"
          [placeholder]="searchPlaceholder()"
          [ariaLabel]="searchAriaLabel() || searchPlaceholder()"
        />
        @if (searchQuery()) {
          <button
            type="button"
            class="clear-button"
            aria-label="Clear search"
            (click)="clearSearch()"
          >
            <span aria-hidden="true">&times;</span>
          </button>
        }
      </div>

      @if (filterOptions().length > 0) {
        <div
          class="filter-group"
          role="radiogroup"
          [attr.aria-label]="filterAriaLabel()"
        >
          @for (opt of filterOptions(); track opt.value) {
            <button
              type="button"
              class="filter-segment"
              [class.filter-segment--active]="opt.value === activeFilter()"
              role="radio"
              [attr.aria-checked]="opt.value === activeFilter()"
              [attr.aria-label]="opt.ariaLabel || opt.label"
              (click)="onFilterClick(opt.value)"
              (keydown)="onFilterKeydown($event, opt.value)"
            >
              {{ opt.label }}
            </button>
          }
        </div>
      }
    </div>
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:block}.tool-header{display:flex;align-items:center;gap:var(--ndt-spacing-sm);margin-bottom:var(--ndt-spacing-sm);flex-shrink:0;flex-wrap:wrap}.search-wrapper{position:relative;flex:1 1 180px;min-width:0;display:flex}.search-wrapper ndt-input{flex:1;min-width:0;display:block}.clear-button{position:absolute;top:50%;right:4px;transform:translateY(-50%);display:flex;align-items:center;justify-content:center;width:18px;height:18px;padding:0;border:0;background:transparent;color:var(--ndt-text-muted);border-radius:50%;cursor:pointer;transition:background-color .15s ease,color .15s ease}.clear-button:hover{background:var(--ndt-hover-bg);color:var(--ndt-text-primary)}.clear-button:focus-visible{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:1px}.clear-button span{font-size:14px;line-height:1}.filter-group{display:inline-flex;padding:2px;background:var(--ndt-hover-bg);border-radius:var(--ndt-border-radius-medium);flex:0 0 auto}.filter-segment{appearance:none;border:0;background:transparent;color:var(--ndt-text-muted);font-family:inherit;font-size:var(--ndt-font-size-xxs);font-weight:500;padding:3px var(--ndt-spacing-sm);border-radius:calc(var(--ndt-border-radius-medium) - 2px);cursor:pointer;transition:background-color .15s ease,color .15s ease;white-space:nowrap}.filter-segment:hover:not(.filter-segment--active){color:var(--ndt-text-primary)}.filter-segment:focus-visible{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:1px}.filter-segment--active{background:var(--ndt-background-secondary);color:var(--ndt-text-primary);box-shadow:0 1px 2px #0000000f}\n"], dependencies: [{ kind: "component", type: ToolbarInputComponent, selector: "ndt-input", inputs: ["value", "type", "placeholder", "ariaLabel", "inputClass"], outputs: ["valueChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarToolHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-tool-header', standalone: true, imports: [ToolbarInputComponent], template: `
    <div class="tool-header">
      <div class="search-wrapper">
        <ndt-input
          [(value)]="searchQuery"
          [placeholder]="searchPlaceholder()"
          [ariaLabel]="searchAriaLabel() || searchPlaceholder()"
        />
        @if (searchQuery()) {
          <button
            type="button"
            class="clear-button"
            aria-label="Clear search"
            (click)="clearSearch()"
          >
            <span aria-hidden="true">&times;</span>
          </button>
        }
      </div>

      @if (filterOptions().length > 0) {
        <div
          class="filter-group"
          role="radiogroup"
          [attr.aria-label]="filterAriaLabel()"
        >
          @for (opt of filterOptions(); track opt.value) {
            <button
              type="button"
              class="filter-segment"
              [class.filter-segment--active]="opt.value === activeFilter()"
              role="radio"
              [attr.aria-checked]="opt.value === activeFilter()"
              [attr.aria-label]="opt.ariaLabel || opt.label"
              (click)="onFilterClick(opt.value)"
              (keydown)="onFilterKeydown($event, opt.value)"
            >
              {{ opt.label }}
            </button>
          }
        </div>
      }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:block}.tool-header{display:flex;align-items:center;gap:var(--ndt-spacing-sm);margin-bottom:var(--ndt-spacing-sm);flex-shrink:0;flex-wrap:wrap}.search-wrapper{position:relative;flex:1 1 180px;min-width:0;display:flex}.search-wrapper ndt-input{flex:1;min-width:0;display:block}.clear-button{position:absolute;top:50%;right:4px;transform:translateY(-50%);display:flex;align-items:center;justify-content:center;width:18px;height:18px;padding:0;border:0;background:transparent;color:var(--ndt-text-muted);border-radius:50%;cursor:pointer;transition:background-color .15s ease,color .15s ease}.clear-button:hover{background:var(--ndt-hover-bg);color:var(--ndt-text-primary)}.clear-button:focus-visible{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:1px}.clear-button span{font-size:14px;line-height:1}.filter-group{display:inline-flex;padding:2px;background:var(--ndt-hover-bg);border-radius:var(--ndt-border-radius-medium);flex:0 0 auto}.filter-segment{appearance:none;border:0;background:transparent;color:var(--ndt-text-muted);font-family:inherit;font-size:var(--ndt-font-size-xxs);font-weight:500;padding:3px var(--ndt-spacing-sm);border-radius:calc(var(--ndt-border-radius-medium) - 2px);cursor:pointer;transition:background-color .15s ease,color .15s ease;white-space:nowrap}.filter-segment:hover:not(.filter-segment--active){color:var(--ndt-text-primary)}.filter-segment:focus-visible{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:1px}.filter-segment--active{background:var(--ndt-background-secondary);color:var(--ndt-text-primary);box-shadow:0 1px 2px #0000000f}\n"] }]
        }] });

const TOOLBAR_POSITIONS = [
    'top',
    'right',
    'bottom',
    'left',
    'sidebar-right',
    'sidebar-left',
];
function isHorizontalPosition(position) {
    return position === 'top' || position === 'bottom';
}
function isSidebarPosition(position) {
    return position === 'sidebar-right' || position === 'sidebar-left';
}

class ToolbarToolButtonComponent {
    constructor() {
        // Injects
        this.state = inject(ToolbarStateService);
        // Inputs
        this.toolLabel = input.required();
        this.toolId = input.required();
        this.badge = input();
        this.position = input('bottom');
        // Outputs
        this.open = output();
        // Signals
        this.isActive = computed(() => this.state.activeToolId() === this.toolId());
        this.isToolbarVisible = this.state.isVisible;
        this.isFocused = signal(false);
        this.tooltip = computed(() => this.toolLabel());
        this.isTooltipVisible = computed(() => this.tooltip() && !this.isActive() && this.isToolbarVisible());
        // Sidebar positions point tooltips toward the viewport interior by
        // remapping onto the existing cardinal SCSS rules. Cardinals pass
        // through unchanged.
        this.tooltipDirection = computed(() => {
            const p = this.position();
            return p === 'sidebar-left'
                ? 'left'
                : p === 'sidebar-right'
                    ? 'right'
                    : p;
        });
        // Properties
        this.tooltipState = signal(false);
        this.hideDelay = 3000;
    }
    // Public methods
    onClick() {
        this.isFocused.set(false);
        this.open.emit();
    }
    onMouseEnter() {
        this.tooltipState.set(true);
    }
    onMouseLeave() {
        this.tooltipState.set(false);
    }
    onEscape() {
        this.isFocused.set(false);
    }
    onFocus() {
        this.isFocused.set(true);
    }
    onBlur() {
        this.isFocused.set(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarToolButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarToolButtonComponent, isStandalone: true, selector: "ndt-tool-button", inputs: { toolLabel: { classPropertyName: "toolLabel", publicName: "toolLabel", isSignal: true, isRequired: true, transformFunction: null }, toolId: { classPropertyName: "toolId", publicName: "toolId", isSignal: true, isRequired: true, transformFunction: null }, badge: { classPropertyName: "badge", publicName: "badge", isSignal: true, isRequired: false, transformFunction: null }, position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { open: "open" }, host: { properties: { "class": "\"tooltip-position-\" + tooltipDirection()" } }, ngImport: i0, template: `
    <button
      class="tool-button"
      [class.tool-button--active]="isActive()"
      [class.tool-button--focus]="isFocused()"
      (mouseenter)="onMouseEnter()"
      (focusin)="onFocus()"
      (focusout)="onBlur()"
      (mouseleave)="onMouseLeave()"
      (keydown.escape)="onEscape()"
    >
      @if (isTooltipVisible()) {
      <span
        class="tooltip"
        [class.tooltip--visible]="tooltipState()"
      >
        {{ tooltip() }}
      </span>
      }
      <ng-content />
      @if (badge()) {
        <span class="tool-button__badge">{{ badge() }}</span>
      }
    </button>
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.tool-button{display:flex;justify-content:center;align-items:center;width:30px;height:30px;border:0;background:transparent;color:var(--ndt-text-primary);transition:var(--ndt-transition-default);cursor:pointer;opacity:.5;position:relative;border-radius:var(--ndt-border-radius-medium)}.tool-button--active,.tool-button:hover{background:var(--ndt-hover-bg);opacity:1}.tool-button ::ng-deep svg{width:16px;height:16px;display:block;margin:auto}.tool-button__badge{position:absolute;top:.1875rem;right:.125rem;background:var(--ndt-danger);color:#fff;border-radius:50%;width:.6875rem;height:.6875rem;font-size:.4375rem;font-weight:600;display:flex;align-items:center;justify-content:center;padding:0;box-shadow:0 1px 2px #0003;line-height:1}.tooltip{position:absolute;background:var(--ndt-tooltip-bg);color:var(--ndt-tooltip-text);padding:.375rem .625rem;border-radius:var(--ndt-border-radius-medium);font-size:.75rem;font-weight:500;white-space:nowrap;pointer-events:none;z-index:1000;box-shadow:var(--ndt-shadow-tooltip);opacity:0;transition:opacity .15s ease-out}.tooltip--visible{opacity:1}.tooltip:after{content:\"\";position:absolute;border:5px solid transparent}:host(.tooltip-position-bottom) .tooltip{bottom:calc(100% + 9px);left:50%;transform:translate(-50%)}:host(.tooltip-position-bottom) .tooltip:after{top:100%;left:50%;transform:translate(-50%);border-top-color:var(--ndt-tooltip-bg)}:host(.tooltip-position-top) .tooltip{top:calc(100% + 9px);left:50%;transform:translate(-50%)}:host(.tooltip-position-top) .tooltip:after{bottom:100%;left:50%;transform:translate(-50%);border-bottom-color:var(--ndt-tooltip-bg)}:host(.tooltip-position-left) .tooltip{left:calc(100% + 9px);top:50%;transform:translateY(-50%)}:host(.tooltip-position-left) .tooltip:after{right:100%;top:50%;transform:translateY(-50%);border-right-color:var(--ndt-tooltip-bg)}:host(.tooltip-position-right) .tooltip{right:calc(100% + 9px);top:50%;transform:translateY(-50%)}:host(.tooltip-position-right) .tooltip:after{left:100%;top:50%;transform:translateY(-50%);border-left-color:var(--ndt-tooltip-bg)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarToolButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-tool-button', standalone: true, host: {
                        '[class]': '"tooltip-position-" + tooltipDirection()',
                    }, template: `
    <button
      class="tool-button"
      [class.tool-button--active]="isActive()"
      [class.tool-button--focus]="isFocused()"
      (mouseenter)="onMouseEnter()"
      (focusin)="onFocus()"
      (focusout)="onBlur()"
      (mouseleave)="onMouseLeave()"
      (keydown.escape)="onEscape()"
    >
      @if (isTooltipVisible()) {
      <span
        class="tooltip"
        [class.tooltip--visible]="tooltipState()"
      >
        {{ tooltip() }}
      </span>
      }
      <ng-content />
      @if (badge()) {
        <span class="tool-button__badge">{{ badge() }}</span>
      }
    </button>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.tool-button{display:flex;justify-content:center;align-items:center;width:30px;height:30px;border:0;background:transparent;color:var(--ndt-text-primary);transition:var(--ndt-transition-default);cursor:pointer;opacity:.5;position:relative;border-radius:var(--ndt-border-radius-medium)}.tool-button--active,.tool-button:hover{background:var(--ndt-hover-bg);opacity:1}.tool-button ::ng-deep svg{width:16px;height:16px;display:block;margin:auto}.tool-button__badge{position:absolute;top:.1875rem;right:.125rem;background:var(--ndt-danger);color:#fff;border-radius:50%;width:.6875rem;height:.6875rem;font-size:.4375rem;font-weight:600;display:flex;align-items:center;justify-content:center;padding:0;box-shadow:0 1px 2px #0003;line-height:1}.tooltip{position:absolute;background:var(--ndt-tooltip-bg);color:var(--ndt-tooltip-text);padding:.375rem .625rem;border-radius:var(--ndt-border-radius-medium);font-size:.75rem;font-weight:500;white-space:nowrap;pointer-events:none;z-index:1000;box-shadow:var(--ndt-shadow-tooltip);opacity:0;transition:opacity .15s ease-out}.tooltip--visible{opacity:1}.tooltip:after{content:\"\";position:absolute;border:5px solid transparent}:host(.tooltip-position-bottom) .tooltip{bottom:calc(100% + 9px);left:50%;transform:translate(-50%)}:host(.tooltip-position-bottom) .tooltip:after{top:100%;left:50%;transform:translate(-50%);border-top-color:var(--ndt-tooltip-bg)}:host(.tooltip-position-top) .tooltip{top:calc(100% + 9px);left:50%;transform:translate(-50%)}:host(.tooltip-position-top) .tooltip:after{bottom:100%;left:50%;transform:translate(-50%);border-bottom-color:var(--ndt-tooltip-bg)}:host(.tooltip-position-left) .tooltip{left:calc(100% + 9px);top:50%;transform:translateY(-50%)}:host(.tooltip-position-left) .tooltip:after{right:100%;top:50%;transform:translateY(-50%);border-right-color:var(--ndt-tooltip-bg)}:host(.tooltip-position-right) .tooltip{right:calc(100% + 9px);top:50%;transform:translateY(-50%)}:host(.tooltip-position-right) .tooltip:after{left:100%;top:50%;transform:translateY(-50%);border-left-color:var(--ndt-tooltip-bg)}\n"] }]
        }] });

class ToolbarWindowComponent {
    constructor() {
        this.devToolbarStateService = inject(ToolbarStateService);
        this.config = input.required();
        this.closed = output();
        this.maximize = output();
        this.minimize = output();
        this.theme = computed(() => this.devToolbarStateService.theme());
        this.isCompact = computed(() => {
            const explicit = this.config().compact;
            if (typeof explicit === 'boolean')
                return explicit;
            return isSidebarPosition(this.devToolbarStateService.position());
        });
    }
    onClose() {
        this.closed.emit();
    }
    onMaximize() {
        this.maximize.emit();
    }
    onMinimize() {
        this.minimize.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarWindowComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarWindowComponent, isStandalone: true, selector: "ndt-window", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { closed: "closed", maximize: "maximize", minimize: "minimize" }, ngImport: i0, template: `
    <div
      class="ndt-window"
      [class.ndt-window--compact]="isCompact()"
      [attr.data-theme]="theme()"
    >
      <div class="ndt-header">
        <div class="ndt-header__content">
          <div class="ndt-header__title">
            <h1>{{ config().title }}</h1>
            @if (config().isBeta) {
              <span class="beta-tag">BETA</span>
            }
          </div>
          @if (!isCompact() && config().description) {
            <p class="ndt-header__description">{{ config().description }}</p>
          }
        </div>
        <div class="ndt-header__controls">
          @if (config().isMinimizable) {
            <button aria-label="Minimize" class="control" (click)="onMinimize()">
              −
            </button>
          }
          @if (config().isMaximizable) {
            <button aria-label="Maximize" class="control" (click)="onMaximize()">
              □
            </button>
          }
          @if (config().isClosable) {
            <button
              aria-label="Close"
              class="control control--close"
              (click)="onClose()"
            >
              ×
            </button>
          }
        </div>
      </div>

      @if (!isCompact()) {
        <div class="divider"></div>
      }

      <div class="ndt-content">
        <ng-content></ng-content>
      </div>
    </div>
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:block;width:100%;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\"}.ndt-window{box-sizing:border-box;display:flex;flex-direction:column;position:relative;width:100%;height:100%;background:var(--ndt-bg-primary);border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-large);padding:var(--ndt-spacing-md) var(--ndt-spacing-md) var(--ndt-spacing-xs);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";color:var(--ndt-text-secondary);z-index:999999999;box-shadow:var(--ndt-shadow-window);contain:layout style}.ndt-window--compact{padding:var(--ndt-spacing-sm) var(--ndt-spacing-md) var(--ndt-spacing-sm)}.ndt-header{display:flex;flex-direction:row;justify-content:space-between;align-items:flex-start;position:relative;z-index:10;flex-shrink:0}.ndt-header h1{font-size:1.25rem;font-weight:700;line-height:1.15;letter-spacing:-.02em;margin:0;color:var(--ndt-text-primary)}.ndt-window--compact .ndt-header{align-items:center;min-height:28px}.ndt-window--compact .ndt-header h1{font-size:var(--ndt-font-size-md);font-weight:600;letter-spacing:-.01em}.ndt-header__title{display:flex;align-items:center;gap:var(--ndt-spacing-sm);flex-wrap:wrap;margin-bottom:var(--ndt-spacing-xs)}.ndt-window--compact .ndt-header__title{margin-bottom:0}.ndt-header__title .beta-tag{font-size:var(--ndt-font-size-xxs, .65rem);background:var(--ndt-purple, #8b5cf6);color:#fff;padding:2px 6px;border-radius:var(--ndt-border-radius-small);font-weight:600;text-transform:uppercase;letter-spacing:.5px;line-height:1;white-space:nowrap}.ndt-header__description{font-size:var(--ndt-font-size-xs);color:var(--ndt-text-muted);word-wrap:break-word;overflow-wrap:break-word;max-width:100%;line-height:1.4;margin:0}.ndt-header__content{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);flex:1;min-width:0}.ndt-header__controls{display:flex;gap:var(--ndt-spacing-sm);flex-shrink:0;align-items:flex-start}.ndt-content{position:relative;flex:1;overflow:auto;min-height:0}.ndt-window--compact .ndt-content{padding-top:var(--ndt-spacing-sm)}.divider{height:1px;background-color:var(--ndt-border-primary);margin-bottom:var(--ndt-spacing-sm);margin-top:var(--ndt-spacing-sm);flex-shrink:0;position:relative;z-index:5}.control{background:none;border:none;color:var(--ndt-text-secondary);cursor:pointer;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-small);font-size:var(--ndt-font-size-md);line-height:1;transition:var(--ndt-transition-smooth)}.control:hover{background:var(--ndt-hover-bg);color:var(--ndt-text-primary)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarWindowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-window', standalone: true, template: `
    <div
      class="ndt-window"
      [class.ndt-window--compact]="isCompact()"
      [attr.data-theme]="theme()"
    >
      <div class="ndt-header">
        <div class="ndt-header__content">
          <div class="ndt-header__title">
            <h1>{{ config().title }}</h1>
            @if (config().isBeta) {
              <span class="beta-tag">BETA</span>
            }
          </div>
          @if (!isCompact() && config().description) {
            <p class="ndt-header__description">{{ config().description }}</p>
          }
        </div>
        <div class="ndt-header__controls">
          @if (config().isMinimizable) {
            <button aria-label="Minimize" class="control" (click)="onMinimize()">
              −
            </button>
          }
          @if (config().isMaximizable) {
            <button aria-label="Maximize" class="control" (click)="onMaximize()">
              □
            </button>
          }
          @if (config().isClosable) {
            <button
              aria-label="Close"
              class="control control--close"
              (click)="onClose()"
            >
              ×
            </button>
          }
        </div>
      </div>

      @if (!isCompact()) {
        <div class="divider"></div>
      }

      <div class="ndt-content">
        <ng-content></ng-content>
      </div>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:block;width:100%;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\"}.ndt-window{box-sizing:border-box;display:flex;flex-direction:column;position:relative;width:100%;height:100%;background:var(--ndt-bg-primary);border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-large);padding:var(--ndt-spacing-md) var(--ndt-spacing-md) var(--ndt-spacing-xs);font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\";color:var(--ndt-text-secondary);z-index:999999999;box-shadow:var(--ndt-shadow-window);contain:layout style}.ndt-window--compact{padding:var(--ndt-spacing-sm) var(--ndt-spacing-md) var(--ndt-spacing-sm)}.ndt-header{display:flex;flex-direction:row;justify-content:space-between;align-items:flex-start;position:relative;z-index:10;flex-shrink:0}.ndt-header h1{font-size:1.25rem;font-weight:700;line-height:1.15;letter-spacing:-.02em;margin:0;color:var(--ndt-text-primary)}.ndt-window--compact .ndt-header{align-items:center;min-height:28px}.ndt-window--compact .ndt-header h1{font-size:var(--ndt-font-size-md);font-weight:600;letter-spacing:-.01em}.ndt-header__title{display:flex;align-items:center;gap:var(--ndt-spacing-sm);flex-wrap:wrap;margin-bottom:var(--ndt-spacing-xs)}.ndt-window--compact .ndt-header__title{margin-bottom:0}.ndt-header__title .beta-tag{font-size:var(--ndt-font-size-xxs, .65rem);background:var(--ndt-purple, #8b5cf6);color:#fff;padding:2px 6px;border-radius:var(--ndt-border-radius-small);font-weight:600;text-transform:uppercase;letter-spacing:.5px;line-height:1;white-space:nowrap}.ndt-header__description{font-size:var(--ndt-font-size-xs);color:var(--ndt-text-muted);word-wrap:break-word;overflow-wrap:break-word;max-width:100%;line-height:1.4;margin:0}.ndt-header__content{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);flex:1;min-width:0}.ndt-header__controls{display:flex;gap:var(--ndt-spacing-sm);flex-shrink:0;align-items:flex-start}.ndt-content{position:relative;flex:1;overflow:auto;min-height:0}.ndt-window--compact .ndt-content{padding-top:var(--ndt-spacing-sm)}.divider{height:1px;background-color:var(--ndt-border-primary);margin-bottom:var(--ndt-spacing-sm);margin-top:var(--ndt-spacing-sm);flex-shrink:0;position:relative;z-index:5}.control{background:none;border:none;color:var(--ndt-text-secondary);cursor:pointer;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-small);font-size:var(--ndt-font-size-md);line-height:1;transition:var(--ndt-transition-smooth)}.control:hover{background:var(--ndt-hover-bg);color:var(--ndt-text-primary)}\n"] }]
        }] });

const SIDEBAR_PILL_FOOTPRINT = 38;
const SIDEBAR_GUTTER = 16;
const SIDEBAR_WIDTH = 420;
class ToolbarToolComponent {
    constructor() {
        this.state = inject(ToolbarStateService);
        this.buttonContainer = viewChild.required('buttonContainer');
        this.buttonComponent = contentChild(ToolbarToolButtonComponent);
        this.options = input.required();
        this.icon = input.required();
        this.toolTitle = input.required();
        this.badge = input();
        this.isActive = computed(() => this.state.activeToolId() === this.options().id);
        this.slideDirection = computed(() => {
            switch (this.state.position()) {
                case 'bottom': return 'up';
                case 'top': return 'down';
                case 'left': return 'right';
                case 'right': return 'left';
                case 'sidebar-right': return 'left';
                case 'sidebar-left': return 'right';
            }
        });
        this.height = computed(() => {
            if (isSidebarPosition(this.state.position())) {
                return Math.max(360, window.innerHeight - SIDEBAR_GUTTER * 2);
            }
            switch (this.options().size) {
                case 'small':
                    return 320;
                case 'medium':
                    return 480;
                case 'tall':
                    return 620;
                case 'large':
                    return 620;
                default:
                    return 480;
            }
        });
        this.width = computed(() => {
            if (isSidebarPosition(this.state.position())) {
                return SIDEBAR_WIDTH;
            }
            switch (this.options().size) {
                case 'small':
                    return 320;
                case 'medium':
                    return 480;
                case 'tall':
                    return 480;
                case 'large':
                    return 620;
                default:
                    return 400;
            }
        });
        this.positions = computed(() => {
            const position = this.state.position();
            const triggerRect = this.getButtonContainerRect();
            switch (position) {
                case 'bottom': {
                    // Original logic: overlay centered above toolbar
                    const windowCenter = window.innerWidth / 2;
                    const offsetX = windowCenter - (triggerRect?.left ?? 0) - 22;
                    return [{
                            originX: 'center',
                            originY: 'center',
                            overlayX: 'center',
                            overlayY: 'center',
                            offsetY: -(Math.ceil(this.height() / 2) + 36),
                            offsetX,
                        }];
                }
                case 'top': {
                    // Overlay centered below toolbar
                    const windowCenter = window.innerWidth / 2;
                    const offsetX = windowCenter - (triggerRect?.left ?? 0) - 22;
                    return [{
                            originX: 'center',
                            originY: 'center',
                            overlayX: 'center',
                            overlayY: 'center',
                            offsetY: Math.ceil(this.height() / 2) + 36,
                            offsetX,
                        }];
                }
                case 'left': {
                    // Overlay centered to the right of toolbar
                    const windowMiddle = window.innerHeight / 2;
                    const offsetY = windowMiddle - (triggerRect?.top ?? 0) - 22;
                    return [{
                            originX: 'center',
                            originY: 'center',
                            overlayX: 'center',
                            overlayY: 'center',
                            offsetX: Math.ceil(this.width() / 2) + 36,
                            offsetY,
                        }];
                }
                case 'right': {
                    // Overlay centered to the left of toolbar
                    const windowMiddle = window.innerHeight / 2;
                    const offsetY = windowMiddle - (triggerRect?.top ?? 0) - 22;
                    return [{
                            originX: 'center',
                            originY: 'center',
                            overlayX: 'center',
                            overlayY: 'center',
                            offsetX: -(Math.ceil(this.width() / 2) + 36),
                            offsetY,
                        }];
                }
                case 'sidebar-right': {
                    // Panel docks to the right edge, left of the vertical pill, top-aligned.
                    const triggerLeft = triggerRect?.left ?? window.innerWidth;
                    const triggerTop = triggerRect?.top ?? SIDEBAR_GUTTER;
                    const panelLeft = window.innerWidth - SIDEBAR_PILL_FOOTPRINT - SIDEBAR_WIDTH - SIDEBAR_GUTTER;
                    return [{
                            originX: 'start',
                            originY: 'top',
                            overlayX: 'start',
                            overlayY: 'top',
                            offsetX: panelLeft - triggerLeft,
                            offsetY: SIDEBAR_GUTTER - triggerTop,
                        }];
                }
                case 'sidebar-left': {
                    // Panel docks to the left edge, right of the vertical pill, top-aligned.
                    const triggerLeft = triggerRect?.left ?? 0;
                    const triggerTop = triggerRect?.top ?? SIDEBAR_GUTTER;
                    const panelLeft = SIDEBAR_PILL_FOOTPRINT + SIDEBAR_GUTTER;
                    return [{
                            originX: 'start',
                            originY: 'top',
                            overlayX: 'start',
                            overlayY: 'top',
                            offsetX: panelLeft - triggerLeft,
                            offsetY: SIDEBAR_GUTTER - triggerTop,
                        }];
                }
            }
        });
    }
    onOpen() {
        this.state.setActiveTool(this.options().id);
    }
    onClose() {
        this.state.setActiveTool(null);
    }
    getButtonContainerRect() {
        return this.buttonContainer()?.nativeElement?.getBoundingClientRect();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarToolComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarToolComponent, isStandalone: true, selector: "ndt-toolbar-tool", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: true, transformFunction: null }, toolTitle: { classPropertyName: "toolTitle", publicName: "toolTitle", isSignal: true, isRequired: true, transformFunction: null }, badge: { classPropertyName: "badge", publicName: "badge", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "buttonComponent", first: true, predicate: ToolbarToolButtonComponent, descendants: true, isSignal: true }], viewQueries: [{ propertyName: "buttonContainer", first: true, predicate: ["buttonContainer"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div #trigger="cdkOverlayOrigin" class="ndt-toolbar-tool" cdkOverlayOrigin>
      <div
        class="ndt-toolbar-tool__icon"
        (click)="onOpen()"
        (keydown.enter)="onOpen()"
        (keydown.space)="onOpen()"
        tabindex="0"
      >
        <div #buttonContainer>
          @if (icon()) {
          <ndt-tool-button [toolLabel]="toolTitle()" [toolId]="options().id" [badge]="badge()" [position]="state.position()">
            <ndt-icon [name]="icon()" />
          </ndt-tool-button>
          } @else {
          <ng-content select="ndt-tool-button"></ng-content>
          }
        </div>
      </div>

      @if (isActive()) {
      <ng-template
        #contentTemplate
        [cdkConnectedOverlayOrigin]="trigger"
        [cdkConnectedOverlayOpen]="isActive()"
        [cdkConnectedOverlayPositions]="positions()"
        [cdkConnectedOverlayWidth]="width()"
        [cdkConnectedOverlayHeight]="height()"
        [cdkConnectedOverlayPanelClass]="['ndt-overlay-panel', 'ndt-tool-overlay']"
        cdkConnectedOverlay
      >
        <ndt-window [class]="'ndt-slide-' + slideDirection()" [config]="options()" (closed)="onClose()">
          <ng-content />
        </ndt-window>
      </ng-template>
      }
    </div>
  `, isInline: true, styles: [":host{display:flex;--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.tool{position:relative}.trigger{cursor:pointer}\n"], dependencies: [{ kind: "directive", type: CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i1.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "component", type: ToolbarWindowComponent, selector: "ndt-window", inputs: ["config"], outputs: ["closed", "maximize", "minimize"] }, { kind: "component", type: ToolbarToolButtonComponent, selector: "ndt-tool-button", inputs: ["toolLabel", "toolId", "badge", "position"], outputs: ["open"] }, { kind: "component", type: ToolbarIconComponent, selector: "ndt-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarToolComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-toolbar-tool', standalone: true, imports: [
                        CdkConnectedOverlay,
                        OverlayModule,
                        ToolbarWindowComponent,
                        ToolbarToolButtonComponent,
                        ToolbarIconComponent,
                    ], template: `
    <div #trigger="cdkOverlayOrigin" class="ndt-toolbar-tool" cdkOverlayOrigin>
      <div
        class="ndt-toolbar-tool__icon"
        (click)="onOpen()"
        (keydown.enter)="onOpen()"
        (keydown.space)="onOpen()"
        tabindex="0"
      >
        <div #buttonContainer>
          @if (icon()) {
          <ndt-tool-button [toolLabel]="toolTitle()" [toolId]="options().id" [badge]="badge()" [position]="state.position()">
            <ndt-icon [name]="icon()" />
          </ndt-tool-button>
          } @else {
          <ng-content select="ndt-tool-button"></ng-content>
          }
        </div>
      </div>

      @if (isActive()) {
      <ng-template
        #contentTemplate
        [cdkConnectedOverlayOrigin]="trigger"
        [cdkConnectedOverlayOpen]="isActive()"
        [cdkConnectedOverlayPositions]="positions()"
        [cdkConnectedOverlayWidth]="width()"
        [cdkConnectedOverlayHeight]="height()"
        [cdkConnectedOverlayPanelClass]="['ndt-overlay-panel', 'ndt-tool-overlay']"
        cdkConnectedOverlay
      >
        <ndt-window [class]="'ndt-slide-' + slideDirection()" [config]="options()" (closed)="onClose()">
          <ng-content />
        </ndt-window>
      </ng-template>
      }
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:flex;--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.tool{position:relative}.trigger{cursor:pointer}\n"] }]
        }] });

/**
 * Partitions items into pinned + named groups + ungrouped sections, applying
 * the same alphabetical-name ordering used elsewhere in the toolbar.
 *
 * Backward-compatible: if no item has a `group`, `groups` is `[]` and the
 * result is equivalent to the legacy pinned-first flat list.
 *
 * Pure function — no side effects, returns a new object.
 */
function groupItems(items, pinnedIds) {
    const byName = (a, b) => a.name.localeCompare(b.name);
    const pinned = [];
    const grouped = new Map();
    const ungrouped = [];
    for (const item of items) {
        if (pinnedIds.has(item.id)) {
            pinned.push(item);
            continue;
        }
        if (item.group) {
            const bucket = grouped.get(item.group);
            if (bucket) {
                bucket.push(item);
            }
            else {
                grouped.set(item.group, [item]);
            }
        }
        else {
            ungrouped.push(item);
        }
    }
    pinned.sort(byName);
    ungrouped.sort(byName);
    const groups = [...grouped.entries()]
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([name, list]) => ({ name, items: list.sort(byName) }));
    return { pinned, groups, ungrouped };
}

/**
 * Internal service for managing app features state and forced overrides.
 *
 * This service handles:
 * - Feature configuration storage
 * - Forced feature state management
 * - localStorage persistence
 * - State validation and cleanup
 *
 * @internal This service is for internal toolbar use only. Consumers should use ToolbarAppFeaturesService.
 */
class ToolbarInternalAppFeaturesService {
    constructor() {
        this.STORAGE_KEY = 'app-features';
        this.storageService = inject(ToolbarStorageService);
        this.stateService = inject(ToolbarStateService);
        this.appFeaturesSubject = new BehaviorSubject([]);
        this.forcedFeaturesSubject = new BehaviorSubject({
            enabled: [],
            disabled: [],
        });
        this.forcedFeatures$ = this.forcedFeaturesSubject.asObservable();
        /**
         * Observable stream of all features with merged forced state
         */
        this.features$ = combineLatest([
            this.appFeaturesSubject.asObservable(),
            this.forcedFeatures$,
        ]).pipe(map(([appFeatures, forcedState]) => this.mergeForcedState(appFeatures, forcedState)));
        /**
         * Signal containing current features with merged forced state
         */
        this.features = toSignal(this.features$, { initialValue: [] });
        // Apply to source
        this.applyCallback = signal(null);
        this.applyStates = signal({});
        this.hasApplyCallback = computed(() => this.applyCallback() !== null);
        this.loadForcedFeatures();
    }
    /**
     * Set available app features for the application.
     * Validates features, trims whitespace, and triggers validation of forced state.
     *
     * @param features - Array of app features to configure
     * @throws Error if duplicate feature IDs or empty IDs are detected
     */
    setAppFeatures(features) {
        // Validate for empty IDs
        const emptyIdFeature = features.find((f) => !f.id || f.id.trim() === '');
        if (emptyIdFeature) {
            throw new Error('Feature ID cannot be empty');
        }
        // Validate for duplicate IDs
        const ids = features.map((f) => f.id);
        const duplicateIds = ids.filter((id, index) => ids.indexOf(id) !== index);
        if (duplicateIds.length > 0) {
            throw new Error(`Duplicate feature IDs detected: ${duplicateIds.join(', ')}`);
        }
        // Trim whitespace from names and warn about empty names
        const processedFeatures = features.map((feature) => {
            const trimmedName = feature.name.trim();
            if (!trimmedName) {
                console.warn(`Feature '${feature.id}' has empty name`);
            }
            return {
                ...feature,
                name: trimmedName || feature.name,
            };
        });
        this.appFeaturesSubject.next(processedFeatures);
        this.validateAndCleanForcedState();
    }
    /**
     * Get observable stream of app features (natural state, no forced state merged)
     */
    getAppFeatures() {
        return this.appFeaturesSubject.asObservable();
    }
    /**
     * Get observable stream of features that have forced overrides
     */
    getForcedFeatures() {
        return this.features$.pipe(map((features) => {
            // If toolbar is disabled, return empty array (no forced values)
            if (!this.stateService.isEnabled()) {
                return [];
            }
            return features.filter((feature) => feature.isForced);
        }));
    }
    /**
     * Force a feature to enabled or disabled state.
     * Persists the forced state to localStorage.
     *
     * @param featureId - ID of the feature to force
     * @param isEnabled - Whether to force feature to enabled (true) or disabled (false)
     */
    setFeature(featureId, isEnabled) {
        const { enabled, disabled } = this.forcedFeaturesSubject.value;
        // Remove feature from both arrays
        const newEnabled = enabled.filter((id) => id !== featureId);
        const newDisabled = disabled.filter((id) => id !== featureId);
        // Add to appropriate array
        if (isEnabled) {
            newEnabled.push(featureId);
        }
        else {
            newDisabled.push(featureId);
        }
        const newState = { enabled: newEnabled, disabled: newDisabled };
        this.forcedFeaturesSubject.next(newState);
        this.saveForcedFeatures(newState);
    }
    /**
     * Remove forced override for a feature, returning it to natural state.
     * Persists the change to localStorage.
     *
     * @param featureId - ID of the feature to unforce
     */
    removeFeatureOverride(featureId) {
        const { enabled, disabled } = this.forcedFeaturesSubject.value;
        const newState = {
            enabled: enabled.filter((id) => id !== featureId),
            disabled: disabled.filter((id) => id !== featureId),
        };
        this.forcedFeaturesSubject.next(newState);
        this.saveForcedFeatures(newState);
    }
    /**
     * Apply a preset forced state (for preset integration).
     * Validates and cleans invalid feature IDs before applying.
     *
     * @param state - Forced features state from preset
     */
    applyForcedState(state) {
        const configuredFeatureIds = this.appFeaturesSubject.value.map((f) => f.id);
        // Validate and filter to only valid IDs
        const validEnabled = state.enabled.filter((id) => configuredFeatureIds.includes(id));
        const validDisabled = state.disabled.filter((id) => configuredFeatureIds.includes(id));
        const invalidIds = [
            ...state.enabled.filter((id) => !configuredFeatureIds.includes(id)),
            ...state.disabled.filter((id) => !configuredFeatureIds.includes(id)),
        ];
        if (invalidIds.length > 0) {
            console.warn(`Preset contains invalid feature IDs (ignored): ${invalidIds.join(', ')}`);
        }
        const cleanedState = { enabled: validEnabled, disabled: validDisabled };
        this.forcedFeaturesSubject.next(cleanedState);
        this.saveForcedFeatures(cleanedState);
    }
    /**
     * Get current forced state as a snapshot (defensive copy).
     * Useful for preset exports and debugging.
     *
     * @returns Current forced features state
     */
    getCurrentForcedState() {
        const state = this.forcedFeaturesSubject.value;
        return {
            enabled: [...state.enabled],
            disabled: [...state.disabled],
        };
    }
    setApplyToSource(callback) {
        this.applyCallback.set(callback);
    }
    async applyToSource(id, value) {
        const callback = this.applyCallback();
        if (!callback)
            return;
        this.applyStates.update((s) => ({ ...s, [id]: 'loading' }));
        try {
            await callback(id, value);
            this.applyStates.update((s) => ({ ...s, [id]: 'success' }));
            setTimeout(() => this.applyStates.update((s) => ({ ...s, [id]: 'idle' })), 1500);
        }
        catch {
            this.applyStates.update((s) => ({ ...s, [id]: 'error' }));
            setTimeout(() => this.applyStates.update((s) => ({ ...s, [id]: 'idle' })), 1500);
        }
    }
    /**
     * Merge natural app features with forced state.
     *
     * @param appFeatures - Natural feature configuration
     * @param forcedState - Forced overrides from localStorage/toolbar
     * @returns Features with merged forced state
     */
    mergeForcedState(appFeatures, forcedState) {
        // If toolbar is disabled, return app features without overrides
        if (!this.stateService.isEnabled()) {
            return appFeatures;
        }
        return appFeatures.map((feature) => {
            const isInEnabled = forcedState.enabled.includes(feature.id);
            const isInDisabled = forcedState.disabled.includes(feature.id);
            const isForced = isInEnabled || isInDisabled;
            return {
                ...feature,
                isEnabled: isInEnabled ? true : isInDisabled ? false : feature.isEnabled,
                isForced,
                originalValue: isForced ? feature.isEnabled : undefined,
            };
        });
    }
    /**
     * Load forced features state from localStorage on initialization.
     * Handles missing or corrupted data gracefully.
     */
    loadForcedFeatures() {
        try {
            const savedState = this.storageService.get(this.STORAGE_KEY);
            if (savedState) {
                this.forcedFeaturesSubject.next(savedState);
            }
        }
        catch (error) {
            console.error('Failed to load forced app features from localStorage:', error);
            // Use default empty state on error
        }
    }
    /**
     * Persist forced features state to localStorage.
     * Handles quota exceeded errors gracefully.
     *
     * @param state - Forced state to persist
     */
    saveForcedFeatures(state) {
        try {
            this.storageService.set(this.STORAGE_KEY, state);
        }
        catch (error) {
            console.error('Failed to persist app features to localStorage:', error);
            // Continue execution - state is still valid in memory for current session
        }
    }
    /**
     * Validate forced feature IDs against configured features and clean up invalid ones.
     * Called after setAppFeatures() to ensure forced state references valid features.
     */
    validateAndCleanForcedState() {
        const configuredFeatureIds = this.appFeaturesSubject.value.map((f) => f.id);
        const currentForcedState = this.forcedFeaturesSubject.value;
        const validEnabled = currentForcedState.enabled.filter((id) => configuredFeatureIds.includes(id));
        const validDisabled = currentForcedState.disabled.filter((id) => configuredFeatureIds.includes(id));
        const removedIds = [
            ...currentForcedState.enabled.filter((id) => !configuredFeatureIds.includes(id)),
            ...currentForcedState.disabled.filter((id) => !configuredFeatureIds.includes(id)),
        ];
        if (removedIds.length > 0) {
            console.warn(`Removed invalid feature IDs from forced state: ${removedIds.join(', ')}`);
            const cleanedState = { enabled: validEnabled, disabled: validDisabled };
            this.forcedFeaturesSubject.next(cleanedState);
            this.saveForcedFeatures(cleanedState);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalAppFeaturesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalAppFeaturesService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalAppFeaturesService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

/**
 * Component for managing app features in the dev toolbar.
 *
 * Provides UI for:
 * - Searching features by name and description
 * - Filtering features by state (all/forced/enabled/disabled)
 * - Forcing features to enabled/disabled state via 3-state dropdown
 * - Viewing feature descriptions and current state
 *
 * @example
 * ```html
 * <ndt-app-features-tool />
 * ```
 */
class ToolbarAppFeaturesToolComponent {
    constructor() {
        // Injects
        this.appFeaturesService = inject(ToolbarInternalAppFeaturesService);
        this.storageService = inject(ToolbarStorageService);
        // Constants
        this.VIEW_STATE_KEY = 'app-features-view';
        // Signals
        this.activeFilter = signal('all');
        this.searchQuery = signal('');
        this.pinnedIds = signal(new Set());
        this.collapsedGroups = signal(new Set());
        this.features = this.appFeaturesService.features;
        // Computed badge count for forced values
        this.badgeCount = computed(() => {
            const count = this.features().filter((f) => f.isForced).length;
            if (count === 0)
                return '';
            if (count > 99)
                return '99+';
            return count.toString();
        });
        this.hasNoFeatures = computed(() => this.features().length === 0);
        this.filteredFeatures = computed(() => {
            return this.features().filter((feature) => {
                const searchTerm = this.searchQuery().toLowerCase();
                const featureName = feature.name.toLowerCase();
                const featureDescription = feature.description?.toLowerCase() ?? '';
                const matchesSearch = !this.searchQuery() ||
                    featureName.includes(searchTerm) ||
                    featureDescription.includes(searchTerm);
                const matchesFilter = this.activeFilter() === 'all' ||
                    (this.activeFilter() === 'forced' && feature.isForced) ||
                    (this.activeFilter() === 'enabled' && feature.isEnabled) ||
                    (this.activeFilter() === 'disabled' && !feature.isEnabled);
                return matchesSearch && matchesFilter;
            });
        });
        this.groupedFeatures = computed(() => groupItems(this.filteredFeatures(), this.pinnedIds()));
        this.flatFeatures = computed(() => {
            const { pinned, ungrouped } = this.groupedFeatures();
            return [...pinned, ...ungrouped];
        });
        this.hasAnyGroups = computed(() => this.groupedFeatures().groups.length > 0);
        this.hasNoFilteredFeatures = computed(() => this.filteredFeatures().length === 0);
        // Other properties
        this.options = {
            title: 'App Features',
            description: 'Override product features to test different tiers and configurations',
            isClosable: true,
            size: 'tall',
            id: 'ndt-app-features',
        };
        this.filterOptions = [
            { value: 'all', label: 'All' },
            { value: 'forced', label: 'Forced' },
            { value: 'enabled', label: 'Enabled' },
            { value: 'disabled', label: 'Disabled' },
        ];
        this.featureValueOptions = [
            { value: 'not-forced', label: 'Not Forced' },
            { value: 'off', label: 'Disabled' },
            { value: 'on', label: 'Enabled' },
        ];
        // Apply to source (delegated to internal service)
        this.hasApplyCallback = this.appFeaturesService.hasApplyCallback;
        this.loadViewState();
        // Save view state on changes
        effect(() => {
            const state = {
                searchQuery: this.searchQuery(),
                filter: this.activeFilter(),
                sortOrder: 'asc',
                pinnedIds: [...this.pinnedIds()],
                collapsedGroups: [...this.collapsedGroups()],
            };
            this.storageService.set(this.VIEW_STATE_KEY, state);
        });
    }
    loadViewState() {
        try {
            const saved = this.storageService.get(this.VIEW_STATE_KEY);
            if (saved) {
                this.searchQuery.set(saved.searchQuery ?? '');
                const filter = saved.filter;
                if (['all', 'forced', 'enabled', 'disabled'].includes(filter)) {
                    this.activeFilter.set(filter);
                }
                if (saved.pinnedIds?.length) {
                    this.pinnedIds.set(new Set(saved.pinnedIds));
                }
                if (saved.collapsedGroups?.length) {
                    this.collapsedGroups.set(new Set(saved.collapsedGroups));
                }
            }
        }
        catch {
            // Use defaults on error
        }
    }
    getApplyState(featureId) {
        return this.appFeaturesService.applyStates()[featureId] ?? 'idle';
    }
    onApplyToSource(featureId, value) {
        this.appFeaturesService.applyToSource(featureId, value);
    }
    // Public methods
    /**
     * Handle filter dropdown change.
     * Updates the active filter to show all/forced/enabled/disabled features.
     */
    onFilterChange(value) {
        const filter = this.filterOptions.find((f) => f.value === value);
        if (filter) {
            this.activeFilter.set(filter.value);
        }
    }
    /**
     * Handle feature value change from 3-state dropdown.
     * - 'not-forced': Remove forced override
     * - 'on': Force feature to enabled
     * - 'off': Force feature to disabled
     */
    onFeatureChange(featureId, value) {
        switch (value) {
            case 'not-forced':
                this.appFeaturesService.removeFeatureOverride(featureId);
                break;
            case 'on':
                this.appFeaturesService.setFeature(featureId, true);
                break;
            case 'off':
                this.appFeaturesService.setFeature(featureId, false);
                break;
        }
    }
    /**
     * Handle search input change.
     * Updates the search query to filter features by name/description.
     */
    onSearchChange(query) {
        this.searchQuery.set(query);
    }
    togglePin(featureId) {
        this.pinnedIds.update((ids) => {
            const next = new Set(ids);
            if (next.has(featureId)) {
                next.delete(featureId);
            }
            else {
                next.add(featureId);
            }
            return next;
        });
    }
    isCollapsed(name) {
        return this.collapsedGroups().has(name);
    }
    setCollapsed(name, collapsed) {
        this.collapsedGroups.update((set) => {
            const next = new Set(set);
            if (collapsed) {
                next.add(name);
            }
            else {
                next.delete(name);
            }
            return next;
        });
    }
    // Protected methods
    /**
     * Get the dropdown value for a feature's current state.
     * - Returns empty string if not forced (natural state)
     * - Returns 'on' if forced to enabled
     * - Returns 'off' if forced to disabled
     */
    getFeatureValue(feature) {
        if (!feature.isForced)
            return '';
        return feature.isEnabled ? 'on' : 'off';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarAppFeaturesToolComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarAppFeaturesToolComponent, isStandalone: true, selector: "ndt-app-features-tool", ngImport: i0, template: `
    <ndt-toolbar-tool
      [options]="options"
      toolTitle="App Features"
      icon="puzzle"
      [badge]="badgeCount()"
    >
      <div class="container">
        <ndt-tool-header
          [(searchQuery)]="searchQuery"
          [activeFilter]="activeFilter()"
          (activeFilterChange)="onFilterChange($event)"
          searchPlaceholder="Search features by name or description"
          searchAriaLabel="Search app features"
          filterAriaLabel="Filter app features by state"
          [filterOptions]="filterOptions"
        />

        <ndt-list
          [hasItems]="!hasNoFeatures()"
          [hasResults]="!hasNoFilteredFeatures()"
          emptyMessage="No app features found"
          [emptyHint]="'Call setAvailableOptions() to configure features'"
          noResultsMessage="No features match your filter"
        >
          @if (hasAnyGroups()) {
            @if (groupedFeatures().pinned.length) {
              <ndt-list-group
                name="Pinned"
                [count]="groupedFeatures().pinned.length"
                [collapsed]="isCollapsed('Pinned')"
                (collapsedChange)="setCollapsed('Pinned', $event)"
              >
                @for (feature of groupedFeatures().pinned; track feature.id) {
                  <ng-container
                    *ngTemplateOutlet="
                      featureItem;
                      context: { $implicit: feature }
                    "
                  />
                }
              </ndt-list-group>
            }
            @for (group of groupedFeatures().groups; track group.name) {
              <ndt-list-group
                [name]="group.name"
                [count]="group.items.length"
                [collapsed]="isCollapsed(group.name)"
                (collapsedChange)="setCollapsed(group.name, $event)"
              >
                @for (feature of group.items; track feature.id) {
                  <ng-container
                    *ngTemplateOutlet="
                      featureItem;
                      context: { $implicit: feature }
                    "
                  />
                }
              </ndt-list-group>
            }
            @if (groupedFeatures().ungrouped.length) {
              <ndt-list-group
                name="Other"
                [count]="groupedFeatures().ungrouped.length"
                [collapsed]="isCollapsed('Other')"
                (collapsedChange)="setCollapsed('Other', $event)"
              >
                @for (feature of groupedFeatures().ungrouped; track feature.id) {
                  <ng-container
                    *ngTemplateOutlet="
                      featureItem;
                      context: { $implicit: feature }
                    "
                  />
                }
              </ndt-list-group>
            }
          } @else {
            @for (feature of flatFeatures(); track feature.id) {
              <ng-container
                *ngTemplateOutlet="
                  featureItem;
                  context: { $implicit: feature }
                "
              />
            }
          }
        </ndt-list>

        <ng-template #featureItem let-feature>
          <ndt-list-item
            [title]="feature.name"
            [description]="feature.description"
            [isForced]="feature.isForced"
            [currentValue]="feature.isEnabled"
            [originalValue]="feature.originalValue"
            [isPinned]="pinnedIds().has(feature.id)"
            [copyableId]="feature.id"
            (pinToggle)="togglePin(feature.id)"
            [showApply]="hasApplyCallback()"
            [applyState]="getApplyState(feature.id)"
            (applyToSource)="onApplyToSource(feature.id, feature.isEnabled)"
          >
            <ndt-select
              [value]="getFeatureValue(feature)"
              [options]="featureValueOptions"
              [ariaLabel]="'Set value for ' + feature.name"
              (valueChange)="onFeatureChange(feature.id, $event ?? '')"
              size="small"
            />
          </ndt-list-item>
        </ng-template>
      </div>
    </ndt-toolbar-tool>
  `, isInline: true, styles: [".container{position:relative;display:flex;flex-direction:column;height:100%;padding:0}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: FormsModule }, { kind: "component", type: ToolbarToolComponent, selector: "ndt-toolbar-tool", inputs: ["options", "icon", "toolTitle", "badge"] }, { kind: "component", type: ToolbarToolHeaderComponent, selector: "ndt-tool-header", inputs: ["searchQuery", "activeFilter", "searchPlaceholder", "searchAriaLabel", "filterOptions", "filterAriaLabel"], outputs: ["searchQueryChange", "activeFilterChange"] }, { kind: "component", type: ToolbarSelectComponent, selector: "ndt-select", inputs: ["value", "options", "ariaLabel", "label", "size", "placeholder"], outputs: ["valueChange"] }, { kind: "component", type: ToolbarListComponent, selector: "ndt-list", inputs: ["hasItems", "hasResults", "emptyMessage", "emptyHint", "noResultsMessage"] }, { kind: "component", type: ToolbarListGroupComponent, selector: "ndt-list-group", inputs: ["name", "count", "collapsed"], outputs: ["collapsedChange"] }, { kind: "component", type: ToolbarListItemComponent, selector: "ndt-list-item", inputs: ["title", "description", "isForced", "currentValue", "originalValue", "showApply", "applyState", "isPinned", "copyableId"], outputs: ["pinToggle", "applyToSource"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarAppFeaturesToolComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-app-features-tool', standalone: true, imports: [
                        NgTemplateOutlet,
                        FormsModule,
                        ToolbarToolComponent,
                        ToolbarToolHeaderComponent,
                        ToolbarSelectComponent,
                        ToolbarListComponent,
                        ToolbarListGroupComponent,
                        ToolbarListItemComponent,
                    ], template: `
    <ndt-toolbar-tool
      [options]="options"
      toolTitle="App Features"
      icon="puzzle"
      [badge]="badgeCount()"
    >
      <div class="container">
        <ndt-tool-header
          [(searchQuery)]="searchQuery"
          [activeFilter]="activeFilter()"
          (activeFilterChange)="onFilterChange($event)"
          searchPlaceholder="Search features by name or description"
          searchAriaLabel="Search app features"
          filterAriaLabel="Filter app features by state"
          [filterOptions]="filterOptions"
        />

        <ndt-list
          [hasItems]="!hasNoFeatures()"
          [hasResults]="!hasNoFilteredFeatures()"
          emptyMessage="No app features found"
          [emptyHint]="'Call setAvailableOptions() to configure features'"
          noResultsMessage="No features match your filter"
        >
          @if (hasAnyGroups()) {
            @if (groupedFeatures().pinned.length) {
              <ndt-list-group
                name="Pinned"
                [count]="groupedFeatures().pinned.length"
                [collapsed]="isCollapsed('Pinned')"
                (collapsedChange)="setCollapsed('Pinned', $event)"
              >
                @for (feature of groupedFeatures().pinned; track feature.id) {
                  <ng-container
                    *ngTemplateOutlet="
                      featureItem;
                      context: { $implicit: feature }
                    "
                  />
                }
              </ndt-list-group>
            }
            @for (group of groupedFeatures().groups; track group.name) {
              <ndt-list-group
                [name]="group.name"
                [count]="group.items.length"
                [collapsed]="isCollapsed(group.name)"
                (collapsedChange)="setCollapsed(group.name, $event)"
              >
                @for (feature of group.items; track feature.id) {
                  <ng-container
                    *ngTemplateOutlet="
                      featureItem;
                      context: { $implicit: feature }
                    "
                  />
                }
              </ndt-list-group>
            }
            @if (groupedFeatures().ungrouped.length) {
              <ndt-list-group
                name="Other"
                [count]="groupedFeatures().ungrouped.length"
                [collapsed]="isCollapsed('Other')"
                (collapsedChange)="setCollapsed('Other', $event)"
              >
                @for (feature of groupedFeatures().ungrouped; track feature.id) {
                  <ng-container
                    *ngTemplateOutlet="
                      featureItem;
                      context: { $implicit: feature }
                    "
                  />
                }
              </ndt-list-group>
            }
          } @else {
            @for (feature of flatFeatures(); track feature.id) {
              <ng-container
                *ngTemplateOutlet="
                  featureItem;
                  context: { $implicit: feature }
                "
              />
            }
          }
        </ndt-list>

        <ng-template #featureItem let-feature>
          <ndt-list-item
            [title]="feature.name"
            [description]="feature.description"
            [isForced]="feature.isForced"
            [currentValue]="feature.isEnabled"
            [originalValue]="feature.originalValue"
            [isPinned]="pinnedIds().has(feature.id)"
            [copyableId]="feature.id"
            (pinToggle)="togglePin(feature.id)"
            [showApply]="hasApplyCallback()"
            [applyState]="getApplyState(feature.id)"
            (applyToSource)="onApplyToSource(feature.id, feature.isEnabled)"
          >
            <ndt-select
              [value]="getFeatureValue(feature)"
              [options]="featureValueOptions"
              [ariaLabel]="'Set value for ' + feature.name"
              (valueChange)="onFeatureChange(feature.id, $event ?? '')"
              size="small"
            />
          </ndt-list-item>
        </ng-template>
      </div>
    </ndt-toolbar-tool>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".container{position:relative;display:flex;flex-direction:column;height:100%;padding:0}\n"] }]
        }], ctorParameters: () => [] });

class ToolbarInternalFeatureFlagService {
    constructor() {
        this.STORAGE_KEY = 'feature-flags';
        this.storageService = inject(ToolbarStorageService);
        this.stateService = inject(ToolbarStateService);
        this.appFlags$ = new BehaviorSubject([]);
        this.forcedFlagsSubject = new BehaviorSubject({
            enabled: [],
            disabled: [],
        });
        this.forcedFlags$ = this.forcedFlagsSubject.asObservable();
        this.flags$ = combineLatest([
            this.appFlags$,
            this.forcedFlags$,
        ]).pipe(map(([appFlags, { enabled, disabled }]) => {
            // If toolbar is disabled, return app flags without overrides
            if (!this.stateService.isEnabled()) {
                return appFlags;
            }
            return appFlags.map((flag) => {
                const isForced = enabled.includes(flag.id) || disabled.includes(flag.id);
                return {
                    ...flag,
                    isForced,
                    isEnabled: enabled.includes(flag.id)
                        ? true
                        : disabled.includes(flag.id)
                            ? false
                            : flag.isEnabled,
                    originalValue: isForced ? flag.isEnabled : undefined,
                };
            });
        }));
        this.flags = toSignal(this.flags$, { initialValue: [] });
        // Apply to source
        this.applyCallback = signal(null);
        this.applyStates = signal({});
        this.hasApplyCallback = computed(() => this.applyCallback() !== null);
        this.loadForcedFlags();
    }
    setAppFlags(flags) {
        this.appFlags$.next(flags);
    }
    getAppFlags() {
        return this.appFlags$.asObservable();
    }
    getForcedFlags() {
        return this.flags$.pipe(map((flags) => {
            // If toolbar is disabled, return empty array (no forced values)
            if (!this.stateService.isEnabled()) {
                return [];
            }
            return flags.filter((flag) => flag.isForced);
        }));
    }
    setFlag(flagId, isEnabled) {
        const { enabled, disabled } = this.forcedFlagsSubject.value;
        const newEnabled = enabled.filter((id) => id !== flagId);
        const newDisabled = disabled.filter((id) => id !== flagId);
        if (isEnabled) {
            newEnabled.push(flagId);
        }
        else {
            newDisabled.push(flagId);
        }
        const newState = { enabled: newEnabled, disabled: newDisabled };
        this.forcedFlagsSubject.next(newState);
        this.storageService.set(this.STORAGE_KEY, newState);
    }
    removeFlagOverride(flagId) {
        const { enabled, disabled } = this.forcedFlagsSubject.value;
        const newState = {
            enabled: enabled.filter((id) => id !== flagId),
            disabled: disabled.filter((id) => id !== flagId),
        };
        this.forcedFlagsSubject.next(newState);
        this.storageService.set(this.STORAGE_KEY, newState);
    }
    loadForcedFlags() {
        const savedFlags = this.storageService.get(this.STORAGE_KEY);
        if (savedFlags) {
            this.forcedFlagsSubject.next(savedFlags);
        }
    }
    /**
     * Apply feature flags from a preset (used by Presets Tool)
     * This method directly sets the forced flags state without user interaction
     */
    applyPresetFlags(presetState) {
        this.forcedFlagsSubject.next(presetState);
        this.storageService.set(this.STORAGE_KEY, presetState);
    }
    /**
     * Get current forced state for saving to preset
     * Returns the raw state of enabled and disabled flag IDs
     */
    getCurrentForcedState() {
        return this.forcedFlagsSubject.value;
    }
    setApplyToSource(callback) {
        this.applyCallback.set(callback);
    }
    async applyToSource(id, value) {
        const callback = this.applyCallback();
        if (!callback)
            return;
        this.applyStates.update((s) => ({ ...s, [id]: 'loading' }));
        try {
            await callback(id, value);
            this.applyStates.update((s) => ({ ...s, [id]: 'success' }));
            setTimeout(() => this.applyStates.update((s) => ({ ...s, [id]: 'idle' })), 1500);
        }
        catch {
            this.applyStates.update((s) => ({ ...s, [id]: 'error' }));
            setTimeout(() => this.applyStates.update((s) => ({ ...s, [id]: 'idle' })), 1500);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalFeatureFlagService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalFeatureFlagService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalFeatureFlagService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

class ToolbarFeatureFlagsToolComponent {
    constructor() {
        // Injects
        this.featureFlags = inject(ToolbarInternalFeatureFlagService);
        this.storageService = inject(ToolbarStorageService);
        // Constants
        this.VIEW_STATE_KEY = 'feature-flags-view';
        // Signals
        this.activeFilter = signal('all');
        this.searchQuery = signal('');
        this.pinnedIds = signal(new Set());
        this.collapsedGroups = signal(new Set());
        this.flags = this.featureFlags.flags;
        // Computed badge count for forced values
        this.badgeCount = computed(() => {
            const count = this.flags().filter((flag) => flag.isForced).length;
            if (count === 0)
                return '';
            if (count > 99)
                return '99+';
            return count.toString();
        });
        this.hasNoFlags = computed(() => this.flags().length === 0);
        // Filter step — search + filter applied to the raw flag list
        this.filteredFlags = computed(() => {
            return this.flags().filter((flag) => {
                const searchTerm = this.searchQuery().toLowerCase();
                const flagName = flag.name.toLowerCase();
                const flagDescription = flag.description?.toLowerCase() ?? '';
                const matchesSearch = !this.searchQuery() ||
                    flagName.includes(searchTerm) ||
                    flagDescription.includes(searchTerm);
                const matchesFilter = this.activeFilter() === 'all' ||
                    (this.activeFilter() === 'forced' && flag.isForced) ||
                    (this.activeFilter() === 'enabled' && flag.isEnabled) ||
                    (this.activeFilter() === 'disabled' && !flag.isEnabled);
                return matchesSearch && matchesFilter;
            });
        });
        // Grouped view — pinned + named groups + ungrouped
        this.groupedFlags = computed(() => groupItems(this.filteredFlags(), this.pinnedIds()));
        // Backward-compat flat list (pinned-first then ungrouped) used when no item has a group
        this.flatFlags = computed(() => {
            const { pinned, ungrouped } = this.groupedFlags();
            return [...pinned, ...ungrouped];
        });
        this.hasAnyGroups = computed(() => this.groupedFlags().groups.length > 0);
        this.hasNoFilteredFlags = computed(() => this.filteredFlags().length === 0);
        // Other properties
        this.options = {
            title: 'Feature Flags',
            description: 'Manage the feature flags for your current session',
            isClosable: true,
            size: 'tall',
            id: 'ndt-feature-flags',
        };
        this.filterOptions = [
            { value: 'all', label: 'All' },
            { value: 'forced', label: 'Forced' },
            { value: 'enabled', label: 'Enabled' },
            { value: 'disabled', label: 'Disabled' },
        ];
        this.flagValueOptions = [
            { value: 'not-forced', label: 'Not Forced' },
            { value: 'off', label: 'Forced Off' },
            { value: 'on', label: 'Forced On' },
        ];
        // Apply to source (delegated to internal service)
        this.hasApplyCallback = this.featureFlags.hasApplyCallback;
        this.loadViewState();
        // Save view state on changes
        effect(() => {
            const state = {
                searchQuery: this.searchQuery(),
                filter: this.activeFilter(),
                sortOrder: 'asc',
                pinnedIds: [...this.pinnedIds()],
                collapsedGroups: [...this.collapsedGroups()],
            };
            this.storageService.set(this.VIEW_STATE_KEY, state);
        });
    }
    loadViewState() {
        try {
            const saved = this.storageService.get(this.VIEW_STATE_KEY);
            if (saved) {
                this.searchQuery.set(saved.searchQuery ?? '');
                const filter = saved.filter;
                if (['all', 'forced', 'enabled', 'disabled'].includes(filter)) {
                    this.activeFilter.set(filter);
                }
                if (saved.pinnedIds?.length) {
                    this.pinnedIds.set(new Set(saved.pinnedIds));
                }
                if (saved.collapsedGroups?.length) {
                    this.collapsedGroups.set(new Set(saved.collapsedGroups));
                }
            }
        }
        catch {
            // Use defaults on error
        }
    }
    getApplyState(flagId) {
        return this.featureFlags.applyStates()[flagId] ?? 'idle';
    }
    onApplyToSource(flagId, value) {
        this.featureFlags.applyToSource(flagId, value);
    }
    // Public methods
    onFilterChange(value) {
        const filter = this.filterOptions.find((f) => f.value === value);
        if (filter) {
            this.activeFilter.set(filter.value);
        }
    }
    onFlagChange(flagId, value) {
        switch (value) {
            case 'not-forced':
                this.featureFlags.removeFlagOverride(flagId);
                break;
            case 'on':
                this.featureFlags.setFlag(flagId, true);
                break;
            case 'off':
                this.featureFlags.setFlag(flagId, false);
                break;
        }
    }
    onSearchChange(query) {
        this.searchQuery.set(query);
    }
    togglePin(flagId) {
        this.pinnedIds.update((ids) => {
            const next = new Set(ids);
            if (next.has(flagId)) {
                next.delete(flagId);
            }
            else {
                next.add(flagId);
            }
            return next;
        });
    }
    isCollapsed(name) {
        return this.collapsedGroups().has(name);
    }
    setCollapsed(name, collapsed) {
        this.collapsedGroups.update((set) => {
            const next = new Set(set);
            if (collapsed) {
                next.add(name);
            }
            else {
                next.delete(name);
            }
            return next;
        });
    }
    // Protected methods
    getFlagValue(flag) {
        if (!flag.isForced)
            return '';
        return flag.isEnabled ? 'on' : 'off';
    }
    getFlagPlaceholder(flag) {
        return flag.isEnabled ? 'On' : 'Off';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarFeatureFlagsToolComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarFeatureFlagsToolComponent, isStandalone: true, selector: "ndt-feature-flags-tool", ngImport: i0, template: `
    <ndt-toolbar-tool
      [options]="options"
      toolTitle="Feature Flags"
      icon="toggle-left"
      [badge]="badgeCount()"
    >
      <div class="container">
        <ndt-tool-header
          [(searchQuery)]="searchQuery"
          [activeFilter]="activeFilter()"
          (activeFilterChange)="onFilterChange($event)"
          searchPlaceholder="Search flags by name or description"
          searchAriaLabel="Search feature flags"
          filterAriaLabel="Filter feature flags by state"
          [filterOptions]="filterOptions"
        />

        <ndt-list
          [hasItems]="!hasNoFlags()"
          [hasResults]="!hasNoFilteredFlags()"
          emptyMessage="No flags found"
          noResultsMessage="No flags found matching your filter"
        >
          @if (hasAnyGroups()) {
            @if (groupedFlags().pinned.length) {
              <ndt-list-group
                name="Pinned"
                [count]="groupedFlags().pinned.length"
                [collapsed]="isCollapsed('Pinned')"
                (collapsedChange)="setCollapsed('Pinned', $event)"
              >
                @for (flag of groupedFlags().pinned; track flag.id) {
                  <ng-container
                    *ngTemplateOutlet="flagItem; context: { $implicit: flag }"
                  />
                }
              </ndt-list-group>
            }
            @for (group of groupedFlags().groups; track group.name) {
              <ndt-list-group
                [name]="group.name"
                [count]="group.items.length"
                [collapsed]="isCollapsed(group.name)"
                (collapsedChange)="setCollapsed(group.name, $event)"
              >
                @for (flag of group.items; track flag.id) {
                  <ng-container
                    *ngTemplateOutlet="flagItem; context: { $implicit: flag }"
                  />
                }
              </ndt-list-group>
            }
            @if (groupedFlags().ungrouped.length) {
              <ndt-list-group
                name="Other"
                [count]="groupedFlags().ungrouped.length"
                [collapsed]="isCollapsed('Other')"
                (collapsedChange)="setCollapsed('Other', $event)"
              >
                @for (flag of groupedFlags().ungrouped; track flag.id) {
                  <ng-container
                    *ngTemplateOutlet="flagItem; context: { $implicit: flag }"
                  />
                }
              </ndt-list-group>
            }
          } @else {
            @for (flag of flatFlags(); track flag.id) {
              <ng-container
                *ngTemplateOutlet="flagItem; context: { $implicit: flag }"
              />
            }
          }
        </ndt-list>

        <ng-template #flagItem let-flag>
          <ndt-list-item
            [title]="flag.name"
            [description]="flag.description"
            [isForced]="flag.isForced"
            [currentValue]="flag.isEnabled"
            [originalValue]="flag.originalValue"
            [isPinned]="pinnedIds().has(flag.id)"
            [copyableId]="flag.id"
            (pinToggle)="togglePin(flag.id)"
            [showApply]="hasApplyCallback()"
            [applyState]="getApplyState(flag.id)"
            (applyToSource)="onApplyToSource(flag.id, flag.isEnabled)"
          >
            <ndt-select
              [value]="getFlagValue(flag)"
              [options]="flagValueOptions"
              [placeholder]="getFlagPlaceholder(flag)"
              [ariaLabel]="'Set value for ' + flag.name"
              (valueChange)="onFlagChange(flag.id, $event ?? '')"
              size="small"
            />
          </ndt-list-item>
        </ng-template>
      </div>
    </ndt-toolbar-tool>
  `, isInline: true, styles: [".container{position:relative;display:flex;flex-direction:column;height:100%;padding:0}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: FormsModule }, { kind: "component", type: ToolbarToolComponent, selector: "ndt-toolbar-tool", inputs: ["options", "icon", "toolTitle", "badge"] }, { kind: "component", type: ToolbarToolHeaderComponent, selector: "ndt-tool-header", inputs: ["searchQuery", "activeFilter", "searchPlaceholder", "searchAriaLabel", "filterOptions", "filterAriaLabel"], outputs: ["searchQueryChange", "activeFilterChange"] }, { kind: "component", type: ToolbarSelectComponent, selector: "ndt-select", inputs: ["value", "options", "ariaLabel", "label", "size", "placeholder"], outputs: ["valueChange"] }, { kind: "component", type: ToolbarListComponent, selector: "ndt-list", inputs: ["hasItems", "hasResults", "emptyMessage", "emptyHint", "noResultsMessage"] }, { kind: "component", type: ToolbarListGroupComponent, selector: "ndt-list-group", inputs: ["name", "count", "collapsed"], outputs: ["collapsedChange"] }, { kind: "component", type: ToolbarListItemComponent, selector: "ndt-list-item", inputs: ["title", "description", "isForced", "currentValue", "originalValue", "showApply", "applyState", "isPinned", "copyableId"], outputs: ["pinToggle", "applyToSource"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarFeatureFlagsToolComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-feature-flags-tool', standalone: true, imports: [
                        NgTemplateOutlet,
                        FormsModule,
                        ToolbarToolComponent,
                        ToolbarToolHeaderComponent,
                        ToolbarSelectComponent,
                        ToolbarListComponent,
                        ToolbarListGroupComponent,
                        ToolbarListItemComponent,
                    ], template: `
    <ndt-toolbar-tool
      [options]="options"
      toolTitle="Feature Flags"
      icon="toggle-left"
      [badge]="badgeCount()"
    >
      <div class="container">
        <ndt-tool-header
          [(searchQuery)]="searchQuery"
          [activeFilter]="activeFilter()"
          (activeFilterChange)="onFilterChange($event)"
          searchPlaceholder="Search flags by name or description"
          searchAriaLabel="Search feature flags"
          filterAriaLabel="Filter feature flags by state"
          [filterOptions]="filterOptions"
        />

        <ndt-list
          [hasItems]="!hasNoFlags()"
          [hasResults]="!hasNoFilteredFlags()"
          emptyMessage="No flags found"
          noResultsMessage="No flags found matching your filter"
        >
          @if (hasAnyGroups()) {
            @if (groupedFlags().pinned.length) {
              <ndt-list-group
                name="Pinned"
                [count]="groupedFlags().pinned.length"
                [collapsed]="isCollapsed('Pinned')"
                (collapsedChange)="setCollapsed('Pinned', $event)"
              >
                @for (flag of groupedFlags().pinned; track flag.id) {
                  <ng-container
                    *ngTemplateOutlet="flagItem; context: { $implicit: flag }"
                  />
                }
              </ndt-list-group>
            }
            @for (group of groupedFlags().groups; track group.name) {
              <ndt-list-group
                [name]="group.name"
                [count]="group.items.length"
                [collapsed]="isCollapsed(group.name)"
                (collapsedChange)="setCollapsed(group.name, $event)"
              >
                @for (flag of group.items; track flag.id) {
                  <ng-container
                    *ngTemplateOutlet="flagItem; context: { $implicit: flag }"
                  />
                }
              </ndt-list-group>
            }
            @if (groupedFlags().ungrouped.length) {
              <ndt-list-group
                name="Other"
                [count]="groupedFlags().ungrouped.length"
                [collapsed]="isCollapsed('Other')"
                (collapsedChange)="setCollapsed('Other', $event)"
              >
                @for (flag of groupedFlags().ungrouped; track flag.id) {
                  <ng-container
                    *ngTemplateOutlet="flagItem; context: { $implicit: flag }"
                  />
                }
              </ndt-list-group>
            }
          } @else {
            @for (flag of flatFlags(); track flag.id) {
              <ng-container
                *ngTemplateOutlet="flagItem; context: { $implicit: flag }"
              />
            }
          }
        </ndt-list>

        <ng-template #flagItem let-flag>
          <ndt-list-item
            [title]="flag.name"
            [description]="flag.description"
            [isForced]="flag.isForced"
            [currentValue]="flag.isEnabled"
            [originalValue]="flag.originalValue"
            [isPinned]="pinnedIds().has(flag.id)"
            [copyableId]="flag.id"
            (pinToggle)="togglePin(flag.id)"
            [showApply]="hasApplyCallback()"
            [applyState]="getApplyState(flag.id)"
            (applyToSource)="onApplyToSource(flag.id, flag.isEnabled)"
          >
            <ndt-select
              [value]="getFlagValue(flag)"
              [options]="flagValueOptions"
              [placeholder]="getFlagPlaceholder(flag)"
              [ariaLabel]="'Set value for ' + flag.name"
              (valueChange)="onFlagChange(flag.id, $event ?? '')"
              size="small"
            />
          </ndt-list-item>
        </ng-template>
      </div>
    </ndt-toolbar-tool>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".container{position:relative;display:flex;flex-direction:column;height:100%;padding:0}\n"] }]
        }], ctorParameters: () => [] });

class ToolbarButtonComponent {
    constructor() {
        this.type = input('button');
        this.variant = input('default');
        this.icon = input();
        this.label = input();
        this.ariaLabel = input();
        this.isActive = input(false);
        this.disabled = input(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarButtonComponent, isStandalone: true, selector: "ndt-button", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, isActive: { classPropertyName: "isActive", publicName: "isActive", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <button
      class="button"
      [attr.aria-label]="ariaLabel()"
      [type]="type()"
      [disabled]="disabled()"
      [class.button--active]="isActive()"
      [class.button--icon]="variant() === 'icon'"
    >
      @if (icon()) {
        <ndt-icon [name]="icon() || 'star'" />
      }
      @if (label()) {
        <span class="button__label">{{ label() }}</span>
      }
      <ng-content />
    </button>
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.button{display:inline-flex;align-items:center;gap:var(--ndt-spacing-xs);padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);min-height:36px;border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-medium);background:var(--ndt-bg-primary);color:var(--ndt-text-primary);cursor:pointer;transition:var(--ndt-transition-default);outline:none;font-family:inherit}.button:hover{background:var(--ndt-hover-bg);border-color:var(--ndt-primary)}.button:focus-visible{outline:none;background:var(--ndt-hover-bg);box-shadow:0 0 0 2px rgba(var(--ndt-primary-rgb),.2)}.button.primary{background:var(--ndt-primary);color:var(--ndt-text-on-primary);border-color:var(--ndt-primary)}.button.primary:hover{background:var(--ndt-primary);border-color:var(--ndt-primary)}.button.icon-only{padding:var(--ndt-spacing-xs);width:32px;height:32px;justify-content:center}.button.small{font-size:var(--ndt-font-size-sm)}.button:disabled{opacity:.5;cursor:not-allowed}.button:disabled:hover{background:var(--ndt-bg-primary);border-color:var(--ndt-border-primary)}\n"], dependencies: [{ kind: "component", type: ToolbarIconComponent, selector: "ndt-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-button', standalone: true, imports: [ToolbarIconComponent], template: `
    <button
      class="button"
      [attr.aria-label]="ariaLabel()"
      [type]="type()"
      [disabled]="disabled()"
      [class.button--active]="isActive()"
      [class.button--icon]="variant() === 'icon'"
    >
      @if (icon()) {
        <ndt-icon [name]="icon() || 'star'" />
      }
      @if (label()) {
        <span class="button__label">{{ label() }}</span>
      }
      <ng-content />
    </button>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.button{display:inline-flex;align-items:center;gap:var(--ndt-spacing-xs);padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);min-height:36px;border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-medium);background:var(--ndt-bg-primary);color:var(--ndt-text-primary);cursor:pointer;transition:var(--ndt-transition-default);outline:none;font-family:inherit}.button:hover{background:var(--ndt-hover-bg);border-color:var(--ndt-primary)}.button:focus-visible{outline:none;background:var(--ndt-hover-bg);box-shadow:0 0 0 2px rgba(var(--ndt-primary-rgb),.2)}.button.primary{background:var(--ndt-primary);color:var(--ndt-text-on-primary);border-color:var(--ndt-primary)}.button.primary:hover{background:var(--ndt-primary);border-color:var(--ndt-primary)}.button.icon-only{padding:var(--ndt-spacing-xs);width:32px;height:32px;justify-content:center}.button.small{font-size:var(--ndt-font-size-sm)}.button:disabled{opacity:.5;cursor:not-allowed}.button:disabled:hover{background:var(--ndt-bg-primary);border-color:var(--ndt-border-primary)}\n"] }]
        }] });

class ToolbarConfirmDialogComponent {
    constructor() {
        this.title = input.required();
        this.message = input('');
        this.confirmLabel = input('Confirm');
        this.cancelLabel = input('Cancel');
        this.danger = input(false);
        this.confirmed = output();
        this.cancelled = output();
        this.dialogRef = viewChild.required('dialog');
        this.result = null;
    }
    show() {
        this.result = null;
        this.dialogRef().nativeElement.showModal();
    }
    confirm() {
        this.result = 'confirm';
        this.dialogRef().nativeElement.close();
    }
    cancel() {
        this.result = 'cancel';
        this.dialogRef().nativeElement.close();
    }
    onBackdropClick(event) {
        if (event.target === this.dialogRef().nativeElement) {
            this.cancel();
        }
    }
    onDialogClose() {
        if (this.result === 'confirm') {
            this.confirmed.emit();
        }
        else {
            this.cancelled.emit();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarConfirmDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarConfirmDialogComponent, isStandalone: true, selector: "ndt-confirm-dialog", inputs: { title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, confirmLabel: { classPropertyName: "confirmLabel", publicName: "confirmLabel", isSignal: true, isRequired: false, transformFunction: null }, cancelLabel: { classPropertyName: "cancelLabel", publicName: "cancelLabel", isSignal: true, isRequired: false, transformFunction: null }, danger: { classPropertyName: "danger", publicName: "danger", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { confirmed: "confirmed", cancelled: "cancelled" }, viewQueries: [{ propertyName: "dialogRef", first: true, predicate: ["dialog"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <dialog
      #dialog
      class="confirm-dialog"
      tabindex="-1"
      [class.confirm-dialog--danger]="danger()"
      (click)="onBackdropClick($event)"
      (keydown.escape)="cancel()"
      (close)="onDialogClose()"
    >
      <div class="confirm-dialog__content">
        <h2 class="confirm-dialog__title">{{ title() }}</h2>
        @if (message()) {
          <p class="confirm-dialog__message">{{ message() }}</p>
        }
        <div class="confirm-dialog__actions">
          <button
            type="button"
            class="confirm-dialog__btn confirm-dialog__btn--secondary"
            (click)="cancel()"
          >
            {{ cancelLabel() }}
          </button>
          <button
            type="button"
            class="confirm-dialog__btn"
            [class.confirm-dialog__btn--danger]="danger()"
            [class.confirm-dialog__btn--primary]="!danger()"
            (click)="confirm()"
          >
            {{ confirmLabel() }}
          </button>
        </div>
      </div>
    </dialog>
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.confirm-dialog{padding:0;border:0;background:var(--ndt-bg-primary);color:var(--ndt-text-primary);border-radius:var(--ndt-border-radius-medium);box-shadow:var(--ndt-shadow-window);max-width:380px;width:calc(100vw - 2rem);font-family:inherit;contain:layout style}.confirm-dialog::backdrop{background:#00000059;backdrop-filter:blur(2px);-webkit-backdrop-filter:blur(2px)}.confirm-dialog__content{display:flex;flex-direction:column;gap:var(--ndt-spacing-md);padding:var(--ndt-spacing-lg)}.confirm-dialog__title{margin:0;font-size:var(--ndt-font-size-md);font-weight:600;color:var(--ndt-text-primary);line-height:1.3}.confirm-dialog__message{margin:0;font-size:var(--ndt-font-size-sm);color:var(--ndt-text-secondary);line-height:1.5}.confirm-dialog__actions{display:flex;justify-content:flex-end;gap:var(--ndt-spacing-sm);margin-top:var(--ndt-spacing-xs)}.confirm-dialog__btn{appearance:none;border:1px solid transparent;padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);border-radius:var(--ndt-border-radius-small);font-size:var(--ndt-font-size-sm);font-weight:500;font-family:inherit;cursor:pointer;transition:background-color .15s ease,border-color .15s ease,color .15s ease}.confirm-dialog__btn:focus-visible{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:2px}.confirm-dialog__btn--secondary{background:transparent;border-color:var(--ndt-border-primary);color:var(--ndt-text-primary)}.confirm-dialog__btn--secondary:hover{background:var(--ndt-hover-bg)}.confirm-dialog__btn--primary{background:var(--ndt-primary);color:var(--ndt-text-on-primary)}.confirm-dialog__btn--primary:hover{filter:brightness(.95)}.confirm-dialog__btn--danger{background:var(--ndt-danger);color:#fff}.confirm-dialog__btn--danger:hover{filter:brightness(.95)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarConfirmDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-confirm-dialog', standalone: true, template: `
    <dialog
      #dialog
      class="confirm-dialog"
      tabindex="-1"
      [class.confirm-dialog--danger]="danger()"
      (click)="onBackdropClick($event)"
      (keydown.escape)="cancel()"
      (close)="onDialogClose()"
    >
      <div class="confirm-dialog__content">
        <h2 class="confirm-dialog__title">{{ title() }}</h2>
        @if (message()) {
          <p class="confirm-dialog__message">{{ message() }}</p>
        }
        <div class="confirm-dialog__actions">
          <button
            type="button"
            class="confirm-dialog__btn confirm-dialog__btn--secondary"
            (click)="cancel()"
          >
            {{ cancelLabel() }}
          </button>
          <button
            type="button"
            class="confirm-dialog__btn"
            [class.confirm-dialog__btn--danger]="danger()"
            [class.confirm-dialog__btn--primary]="!danger()"
            (click)="confirm()"
          >
            {{ confirmLabel() }}
          </button>
        </div>
      </div>
    </dialog>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.confirm-dialog{padding:0;border:0;background:var(--ndt-bg-primary);color:var(--ndt-text-primary);border-radius:var(--ndt-border-radius-medium);box-shadow:var(--ndt-shadow-window);max-width:380px;width:calc(100vw - 2rem);font-family:inherit;contain:layout style}.confirm-dialog::backdrop{background:#00000059;backdrop-filter:blur(2px);-webkit-backdrop-filter:blur(2px)}.confirm-dialog__content{display:flex;flex-direction:column;gap:var(--ndt-spacing-md);padding:var(--ndt-spacing-lg)}.confirm-dialog__title{margin:0;font-size:var(--ndt-font-size-md);font-weight:600;color:var(--ndt-text-primary);line-height:1.3}.confirm-dialog__message{margin:0;font-size:var(--ndt-font-size-sm);color:var(--ndt-text-secondary);line-height:1.5}.confirm-dialog__actions{display:flex;justify-content:flex-end;gap:var(--ndt-spacing-sm);margin-top:var(--ndt-spacing-xs)}.confirm-dialog__btn{appearance:none;border:1px solid transparent;padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);border-radius:var(--ndt-border-radius-small);font-size:var(--ndt-font-size-sm);font-weight:500;font-family:inherit;cursor:pointer;transition:background-color .15s ease,border-color .15s ease,color .15s ease}.confirm-dialog__btn:focus-visible{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:2px}.confirm-dialog__btn--secondary{background:transparent;border-color:var(--ndt-border-primary);color:var(--ndt-text-primary)}.confirm-dialog__btn--secondary:hover{background:var(--ndt-hover-bg)}.confirm-dialog__btn--primary{background:var(--ndt-primary);color:var(--ndt-text-on-primary)}.confirm-dialog__btn--primary:hover{filter:brightness(.95)}.confirm-dialog__btn--danger{background:var(--ndt-danger);color:#fff}.confirm-dialog__btn--danger:hover{filter:brightness(.95)}\n"] }]
        }] });

class ToolbarLinkButtonComponent {
    constructor() {
        this.url = input.required();
        this.icon = input();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarLinkButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarLinkButtonComponent, isStandalone: true, selector: "ndt-link-button", inputs: { url: { classPropertyName: "url", publicName: "url", isSignal: true, isRequired: true, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <a
      [href]="url()"
      target="_blank"
      rel="noopener noreferrer"
      class="link-button"
    >
      @if (icon(); as iconName) {
        <div class="link-button__icon">
          <ndt-icon [name]="iconName" />
        </div>
      }
      <span class="link-button__text">
        <ng-content></ng-content>
      </span>
    </a>
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.link-button{display:flex;flex-direction:column;align-items:center;gap:var(--ndt-spacing-xs);text-decoration:none;color:var(--ndt-text-muted);transition:color .15s ease}.link-button:hover{color:var(--ndt-text-primary)}.link-button:focus-visible{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:2px;border-radius:var(--ndt-border-radius-small)}.link-button__icon{display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:var(--ndt-border-radius-medium);background:var(--ndt-hover-bg);transition:background-color .15s ease}.link-button__text{font-size:var(--ndt-font-size-xs);text-align:center;white-space:nowrap}\n"], dependencies: [{ kind: "component", type: ToolbarIconComponent, selector: "ndt-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarLinkButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-link-button', standalone: true, imports: [ToolbarIconComponent], template: `
    <a
      [href]="url()"
      target="_blank"
      rel="noopener noreferrer"
      class="link-button"
    >
      @if (icon(); as iconName) {
        <div class="link-button__icon">
          <ndt-icon [name]="iconName" />
        </div>
      }
      <span class="link-button__text">
        <ng-content></ng-content>
      </span>
    </a>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.link-button{display:flex;flex-direction:column;align-items:center;gap:var(--ndt-spacing-xs);text-decoration:none;color:var(--ndt-text-muted);transition:color .15s ease}.link-button:hover{color:var(--ndt-text-primary)}.link-button:focus-visible{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:2px;border-radius:var(--ndt-border-radius-small)}.link-button__icon{display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:var(--ndt-border-radius-medium);background:var(--ndt-hover-bg);transition:background-color .15s ease}.link-button__text{font-size:var(--ndt-font-size-xs);text-align:center;white-space:nowrap}\n"] }]
        }] });

class SettingsService {
    constructor() {
        this.STORAGE_KEY = 'settings';
        this.storageService = inject(ToolbarStorageService);
    }
    getSettings() {
        return (this.storageService.get(this.STORAGE_KEY) || {
            isDarkMode: false,
            position: 'bottom',
            isCompletelyHidden: false,
        });
    }
    setSettings(settings) {
        this.storageService.set(this.STORAGE_KEY, settings);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: SettingsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: SettingsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: SettingsService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class ToolbarHomeToolComponent {
    constructor() {
        this.state = inject(ToolbarStateService);
        this.settingsService = inject(SettingsService);
        this.storageService = inject(ToolbarStorageService);
        this.badge = input();
        this.title = `Angular Toolbar`;
        this.options = {
            title: this.title,
            isClosable: true,
            id: 'ndt-home',
            size: 'medium',
            description: '',
        };
        this.positionOptions = [
            { value: 'top', label: 'Top' },
            { value: 'bottom', label: 'Bottom' },
            { value: 'left', label: 'Left' },
            { value: 'right', label: 'Right' },
            { value: 'sidebar-left', label: 'Sidebar Left' },
            { value: 'sidebar-right', label: 'Sidebar Right' },
        ];
        this.links = [
            {
                url: 'https://alfredoperez.github.io/ngx-dev-toolbar/',
                label: 'Docs',
            },
            {
                url: 'https://github.com/alfredoperez/ngx-dev-toolbar/issues/new/choose',
                label: 'Feedback',
            },
        ];
        this.resetDialog = viewChild('resetDialog');
    }
    onPositionChange(position) {
        this.state.setPosition(position);
    }
    onExportSettings() {
        const settings = this.storageService.getAllSettings();
        const blob = new Blob([JSON.stringify(settings, null, 2)], {
            type: 'application/json',
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        const timestamp = new Date().toISOString().split('T')[0];
        link.href = url;
        link.download = `ngx-dev-toolbar-settings-${timestamp}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }
    onImportSettings() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'application/json';
        input.onchange = (event) => {
            const file = event.target.files?.[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const settings = JSON.parse(e.target?.result);
                        this.storageService.setAllSettings(settings);
                        window.location.reload();
                    }
                    catch (error) {
                        console.error('Error importing settings:', error);
                    }
                };
                reader.readAsText(file);
            }
        };
        input.click();
    }
    onResetSettings() {
        this.resetDialog()?.show();
    }
    confirmReset() {
        this.storageService.clearAllSettings();
        window.location.reload();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarHomeToolComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarHomeToolComponent, isStandalone: true, selector: "ndt-home-tool", inputs: { badge: { classPropertyName: "badge", publicName: "badge", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "resetDialog", first: true, predicate: ["resetDialog"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <ndt-toolbar-tool [options]="options" toolTitle="Home" icon="angular">
      <section class="settings">
        <div class="settings-container">
          <div class="instruction">
            <div class="instruction__label">
              <span class="instruction__label-text">Toolbar Position</span>
              <span class="instruction__label-description">
                Choose where the toolbar appears on screen
              </span>
            </div>
            <div class="instruction__control">
              <ndt-select
                [value]="state.position()"
                [options]="positionOptions"
                ariaLabel="Toolbar position"
                size="medium"
                (valueChange)="onPositionChange($any($event))"
              />
            </div>
          </div>

          <div class="instruction">
            <div class="instruction__label">
              <span class="instruction__label-text">Export Settings</span>
              <span class="instruction__label-description">
                Download the current setup to share or reproduce in tests
              </span>
            </div>
            <div class="instruction__control">
              <ndt-button
                variant="icon"
                icon="export"
                ariaLabel="Export settings"
                (click)="onExportSettings()"
              />
            </div>
          </div>

          <div class="instruction">
            <div class="instruction__label">
              <span class="instruction__label-text">Import Settings</span>
              <span class="instruction__label-description">
                Load a settings file to reproduce a scenario
              </span>
            </div>
            <div class="instruction__control">
              <ndt-button
                variant="icon"
                icon="import"
                ariaLabel="Import settings"
                (click)="onImportSettings()"
              />
            </div>
          </div>

          <div class="instruction instruction--danger-zone">
            <div class="instruction__label">
              <span class="instruction__label-text">Reset Settings</span>
              <span class="instruction__label-description">
                Clear all forced values, presets, and stored preferences
              </span>
            </div>
            <div class="instruction__control">
              <ndt-button
                variant="icon"
                icon="trash"
                ariaLabel="Reset all settings"
                (click)="onResetSettings()"
              />
            </div>
          </div>
        </div>

        <div class="footer-links">
          @for (link of links; track link.url) {
          <ndt-link-button [url]="link.url">
            {{ link.label }}
          </ndt-link-button>
          }
        </div>
      </section>
    </ndt-toolbar-tool>

    <ndt-confirm-dialog
      #resetDialog
      title="Reset all settings?"
      message="This will clear all forced values, presets, and stored preferences for this session. The page will reload. This cannot be undone."
      confirmLabel="Reset settings"
      cancelLabel="Cancel"
      [danger]="true"
      (confirmed)="confirmReset()"
    />
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.settings{display:flex;flex-direction:column;height:100%}.instruction{display:flex;justify-content:space-between;align-items:flex-start;gap:var(--ndt-spacing-sm)}.instruction__label{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:var(--ndt-spacing-xs)}.instruction__label-text{color:var(--ndt-text-primary);font-size:var(--ndt-font-size-sm);font-weight:500}.instruction__label-description{color:var(--ndt-text-muted);font-size:var(--ndt-font-size-xs)}.instruction__control{flex:0 0 auto}.instruction__control-button{display:flex;gap:var(--ndt-spacing-xs);justify-content:flex-end}.instruction__control ::ng-deep .button{border-color:transparent;background:transparent;width:32px;height:32px;min-height:32px;padding:0;display:inline-flex;align-items:center;justify-content:center}.instruction__control ::ng-deep .button:hover{background:var(--ndt-hover-bg);border-color:transparent}.instruction--danger-zone{margin-top:var(--ndt-spacing-sm);padding-top:var(--ndt-spacing-md);border-top:1px solid var(--ndt-border-subtle)}.instruction--danger-zone .instruction__control ::ng-deep .button:hover{background:rgba(var(--ndt-danger-rgb),.1);color:var(--ndt-danger)}.settings-container{display:flex;flex-direction:column;gap:var(--ndt-spacing-md)}.footer-links{margin-top:auto;padding-top:var(--ndt-spacing-md);border-top:1px solid var(--ndt-border-subtle);display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:var(--ndt-spacing-md);flex-wrap:wrap}.footer-links ::ng-deep .link-button{flex-direction:row;align-items:center;gap:var(--ndt-spacing-xs);color:var(--ndt-text-muted);transition:color .15s ease}.footer-links ::ng-deep .link-button:hover{color:var(--ndt-text-primary)}.footer-links ::ng-deep .link-button__icon{width:auto;height:auto;background:transparent;padding:0}.footer-links ::ng-deep .link-button__icon svg{width:12px;height:12px}.footer-links ::ng-deep .link-button__text{font-size:var(--ndt-font-size-xs)}\n"], dependencies: [{ kind: "component", type: ToolbarToolComponent, selector: "ndt-toolbar-tool", inputs: ["options", "icon", "toolTitle", "badge"] }, { kind: "ngmodule", type: FormsModule }, { kind: "component", type: ToolbarButtonComponent, selector: "ndt-button", inputs: ["type", "variant", "icon", "label", "ariaLabel", "isActive", "disabled"] }, { kind: "component", type: ToolbarConfirmDialogComponent, selector: "ndt-confirm-dialog", inputs: ["title", "message", "confirmLabel", "cancelLabel", "danger"], outputs: ["confirmed", "cancelled"] }, { kind: "component", type: ToolbarLinkButtonComponent, selector: "ndt-link-button", inputs: ["url", "icon"] }, { kind: "component", type: ToolbarSelectComponent, selector: "ndt-select", inputs: ["value", "options", "ariaLabel", "label", "size", "placeholder"], outputs: ["valueChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarHomeToolComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-home-tool', standalone: true, imports: [
                        ToolbarToolComponent,
                        FormsModule,
                        ToolbarButtonComponent,
                        ToolbarConfirmDialogComponent,
                        ToolbarLinkButtonComponent,
                        ToolbarSelectComponent,
                    ], template: `
    <ndt-toolbar-tool [options]="options" toolTitle="Home" icon="angular">
      <section class="settings">
        <div class="settings-container">
          <div class="instruction">
            <div class="instruction__label">
              <span class="instruction__label-text">Toolbar Position</span>
              <span class="instruction__label-description">
                Choose where the toolbar appears on screen
              </span>
            </div>
            <div class="instruction__control">
              <ndt-select
                [value]="state.position()"
                [options]="positionOptions"
                ariaLabel="Toolbar position"
                size="medium"
                (valueChange)="onPositionChange($any($event))"
              />
            </div>
          </div>

          <div class="instruction">
            <div class="instruction__label">
              <span class="instruction__label-text">Export Settings</span>
              <span class="instruction__label-description">
                Download the current setup to share or reproduce in tests
              </span>
            </div>
            <div class="instruction__control">
              <ndt-button
                variant="icon"
                icon="export"
                ariaLabel="Export settings"
                (click)="onExportSettings()"
              />
            </div>
          </div>

          <div class="instruction">
            <div class="instruction__label">
              <span class="instruction__label-text">Import Settings</span>
              <span class="instruction__label-description">
                Load a settings file to reproduce a scenario
              </span>
            </div>
            <div class="instruction__control">
              <ndt-button
                variant="icon"
                icon="import"
                ariaLabel="Import settings"
                (click)="onImportSettings()"
              />
            </div>
          </div>

          <div class="instruction instruction--danger-zone">
            <div class="instruction__label">
              <span class="instruction__label-text">Reset Settings</span>
              <span class="instruction__label-description">
                Clear all forced values, presets, and stored preferences
              </span>
            </div>
            <div class="instruction__control">
              <ndt-button
                variant="icon"
                icon="trash"
                ariaLabel="Reset all settings"
                (click)="onResetSettings()"
              />
            </div>
          </div>
        </div>

        <div class="footer-links">
          @for (link of links; track link.url) {
          <ndt-link-button [url]="link.url">
            {{ link.label }}
          </ndt-link-button>
          }
        </div>
      </section>
    </ndt-toolbar-tool>

    <ndt-confirm-dialog
      #resetDialog
      title="Reset all settings?"
      message="This will clear all forced values, presets, and stored preferences for this session. The page will reload. This cannot be undone."
      confirmLabel="Reset settings"
      cancelLabel="Cancel"
      [danger]="true"
      (confirmed)="confirmReset()"
    />
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.settings{display:flex;flex-direction:column;height:100%}.instruction{display:flex;justify-content:space-between;align-items:flex-start;gap:var(--ndt-spacing-sm)}.instruction__label{flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:var(--ndt-spacing-xs)}.instruction__label-text{color:var(--ndt-text-primary);font-size:var(--ndt-font-size-sm);font-weight:500}.instruction__label-description{color:var(--ndt-text-muted);font-size:var(--ndt-font-size-xs)}.instruction__control{flex:0 0 auto}.instruction__control-button{display:flex;gap:var(--ndt-spacing-xs);justify-content:flex-end}.instruction__control ::ng-deep .button{border-color:transparent;background:transparent;width:32px;height:32px;min-height:32px;padding:0;display:inline-flex;align-items:center;justify-content:center}.instruction__control ::ng-deep .button:hover{background:var(--ndt-hover-bg);border-color:transparent}.instruction--danger-zone{margin-top:var(--ndt-spacing-sm);padding-top:var(--ndt-spacing-md);border-top:1px solid var(--ndt-border-subtle)}.instruction--danger-zone .instruction__control ::ng-deep .button:hover{background:rgba(var(--ndt-danger-rgb),.1);color:var(--ndt-danger)}.settings-container{display:flex;flex-direction:column;gap:var(--ndt-spacing-md)}.footer-links{margin-top:auto;padding-top:var(--ndt-spacing-md);border-top:1px solid var(--ndt-border-subtle);display:flex;flex-direction:row;justify-content:flex-start;align-items:center;gap:var(--ndt-spacing-md);flex-wrap:wrap}.footer-links ::ng-deep .link-button{flex-direction:row;align-items:center;gap:var(--ndt-spacing-xs);color:var(--ndt-text-muted);transition:color .15s ease}.footer-links ::ng-deep .link-button:hover{color:var(--ndt-text-primary)}.footer-links ::ng-deep .link-button__icon{width:auto;height:auto;background:transparent;padding:0}.footer-links ::ng-deep .link-button__icon svg{width:12px;height:12px}.footer-links ::ng-deep .link-button__text{font-size:var(--ndt-font-size-xs)}\n"] }]
        }] });

const DEFAULT_TIMEZONES = [
    { id: 'UTC', name: 'UTC', offset: '+00:00' },
    { id: 'America/New_York', name: 'Eastern Time (US)', offset: '-05:00' },
    { id: 'America/Chicago', name: 'Central Time (US)', offset: '-06:00' },
    { id: 'America/Denver', name: 'Mountain Time (US)', offset: '-07:00' },
    { id: 'America/Los_Angeles', name: 'Pacific Time (US)', offset: '-08:00' },
    { id: 'Europe/London', name: 'London (GMT)', offset: '+00:00' },
    { id: 'Europe/Paris', name: 'Paris (CET)', offset: '+01:00' },
    { id: 'Europe/Berlin', name: 'Berlin (CET)', offset: '+01:00' },
    { id: 'Asia/Tokyo', name: 'Tokyo (JST)', offset: '+09:00' },
    { id: 'Asia/Shanghai', name: 'Shanghai (CST)', offset: '+08:00' },
    { id: 'Asia/Kolkata', name: 'India (IST)', offset: '+05:30' },
    { id: 'Asia/Dubai', name: 'Dubai (GST)', offset: '+04:00' },
    { id: 'Australia/Sydney', name: 'Sydney (AEST)', offset: '+10:00' },
    { id: 'Pacific/Auckland', name: 'Auckland (NZST)', offset: '+12:00' },
    { id: 'America/Sao_Paulo', name: 'Sao Paulo (BRT)', offset: '-03:00' },
];
const DEFAULT_CURRENCIES = [
    { code: 'USD', name: 'US Dollar', symbol: '$' },
    { code: 'EUR', name: 'Euro', symbol: '\u20AC' },
    { code: 'GBP', name: 'British Pound', symbol: '\u00A3' },
    { code: 'JPY', name: 'Japanese Yen', symbol: '\u00A5' },
    { code: 'CNY', name: 'Chinese Yuan', symbol: '\u00A5' },
    { code: 'INR', name: 'Indian Rupee', symbol: '\u20B9' },
    { code: 'BRL', name: 'Brazilian Real', symbol: 'R$' },
    { code: 'CAD', name: 'Canadian Dollar', symbol: 'CA$' },
    { code: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
    { code: 'CHF', name: 'Swiss Franc', symbol: 'CHF' },
    { code: 'KRW', name: 'South Korean Won', symbol: '\u20A9' },
    { code: 'MXN', name: 'Mexican Peso', symbol: 'MX$' },
    { code: 'AED', name: 'UAE Dirham', symbol: 'AED' },
    { code: 'SAR', name: 'Saudi Riyal', symbol: 'SAR' },
];
const CURRENCY_SYMBOLS = Object.fromEntries(DEFAULT_CURRENCIES.map(({ code, symbol }) => [code, symbol]));

class ToolbarInternalI18nService {
    constructor() {
        this.STORAGE_LOCALE = 'i18n.locale';
        this.STORAGE_TIMEZONE = 'i18n.timezone';
        this.STORAGE_CURRENCY = 'i18n.currency';
        this.STORAGE_UNIT_SYSTEM = 'i18n.unitSystem';
        this.STORAGE_DATE_FORMAT = 'i18n.dateFormat';
        this.STORAGE_FIRST_DAY = 'i18n.firstDay';
        this.STORAGE_NUMBER_FORMAT = 'i18n.numberFormat';
        this.STORAGE_PSEUDO_LOC = 'i18n.pseudoLoc';
        this.STORAGE_RTL = 'i18n.rtl';
        this.OLD_LANGUAGE_KEY = 'language';
        this.storageService = inject(ToolbarStorageService);
        this.stateService = inject(ToolbarStateService);
        this.document = inject(DOCUMENT);
        this.locales$ = new BehaviorSubject([]);
        this.timezones$ = new BehaviorSubject(DEFAULT_TIMEZONES);
        this.currencies$ = new BehaviorSubject(DEFAULT_CURRENCIES);
        this.forcedLocale$ = new BehaviorSubject(null);
        this.forcedTimezone$ = new BehaviorSubject(null);
        this.forcedCurrency$ = new BehaviorSubject(null);
        this.forcedUnitSystem$ = new BehaviorSubject(null);
        this.forcedDateFormat$ = new BehaviorSubject(null);
        this.forcedFirstDayOfWeek$ = new BehaviorSubject(null);
        this.forcedNumberFormat$ = new BehaviorSubject(null);
        this.toolConfig$ = new BehaviorSubject({});
        this.pseudoLocEnabled$ = new BehaviorSubject(false);
        this.rtlEnabled$ = new BehaviorSubject(false);
        this.locales = toSignal(this.locales$, { initialValue: [] });
        this.timezones = toSignal(this.timezones$, { initialValue: DEFAULT_TIMEZONES });
        this.availableCurrencies = toSignal(this.currencies$, { initialValue: DEFAULT_CURRENCIES });
        this.forcedLocale = toSignal(this.forcedLocale$, { initialValue: null });
        this.forcedTimezone = toSignal(this.forcedTimezone$, { initialValue: null });
        this.forcedCurrency = toSignal(this.forcedCurrency$, { initialValue: null });
        this.forcedUnitSystem = toSignal(this.forcedUnitSystem$, { initialValue: null });
        this.forcedDateFormat = toSignal(this.forcedDateFormat$, { initialValue: null });
        this.forcedFirstDayOfWeek = toSignal(this.forcedFirstDayOfWeek$, { initialValue: null });
        this.forcedNumberFormat = toSignal(this.forcedNumberFormat$, { initialValue: null });
        this.toolConfig = toSignal(this.toolConfig$, { initialValue: {} });
        this.pseudoLocEnabled = toSignal(this.pseudoLocEnabled$, { initialValue: false });
        this.rtlEnabled = toSignal(this.rtlEnabled$, { initialValue: false });
        this.migrateOldLanguageKey();
        this.loadFromStorage();
    }
    // --- Locale ---
    setAvailableLocales(locales) {
        this.locales$.next(locales);
    }
    getAvailableLocales() {
        return this.locales$.asObservable();
    }
    setForcedLocale(locale) {
        this.forcedLocale$.next(locale);
        this.storageService.set(this.STORAGE_LOCALE, locale);
    }
    getForcedLocale() {
        return this.forcedLocale$.pipe(map((locale) => {
            if (!this.stateService.isEnabled()) {
                return [];
            }
            return locale ? [locale] : [];
        }));
    }
    removeForcedLocale() {
        this.forcedLocale$.next(null);
        this.storageService.remove(this.STORAGE_LOCALE);
    }
    // --- Timezone ---
    setAvailableTimezones(timezones) {
        this.timezones$.next(timezones);
    }
    getAvailableTimezones() {
        return this.timezones$.asObservable();
    }
    setForcedTimezone(timezone) {
        this.forcedTimezone$.next(timezone);
        this.storageService.set(this.STORAGE_TIMEZONE, timezone);
    }
    getForcedTimezone() {
        return this.forcedTimezone$.pipe(map((tz) => (this.stateService.isEnabled() ? tz : null)));
    }
    removeForcedTimezone() {
        this.forcedTimezone$.next(null);
        this.storageService.remove(this.STORAGE_TIMEZONE);
    }
    // --- Currency ---
    setAvailableCurrencies(currencies) {
        this.currencies$.next(currencies);
    }
    getAvailableCurrencies() {
        return this.currencies$.asObservable();
    }
    setForcedCurrency(currency) {
        this.forcedCurrency$.next(currency);
        this.storageService.set(this.STORAGE_CURRENCY, currency);
    }
    getForcedCurrency() {
        return this.forcedCurrency$.pipe(map((c) => (this.stateService.isEnabled() ? c : null)));
    }
    removeForcedCurrency() {
        this.forcedCurrency$.next(null);
        this.storageService.remove(this.STORAGE_CURRENCY);
    }
    // --- Unit System ---
    setForcedUnitSystem(unitSystem) {
        this.forcedUnitSystem$.next(unitSystem);
        this.storageService.set(this.STORAGE_UNIT_SYSTEM, unitSystem);
    }
    getForcedUnitSystem() {
        return this.forcedUnitSystem$.pipe(map((u) => (this.stateService.isEnabled() ? u : null)));
    }
    removeForcedUnitSystem() {
        this.forcedUnitSystem$.next(null);
        this.storageService.remove(this.STORAGE_UNIT_SYSTEM);
    }
    // --- Date Format ---
    setForcedDateFormat(dateFormat) {
        this.forcedDateFormat$.next(dateFormat);
        this.storageService.set(this.STORAGE_DATE_FORMAT, dateFormat);
    }
    getForcedDateFormat() {
        return this.forcedDateFormat$.pipe(map((df) => (this.stateService.isEnabled() ? df : null)));
    }
    removeForcedDateFormat() {
        this.forcedDateFormat$.next(null);
        this.storageService.remove(this.STORAGE_DATE_FORMAT);
    }
    // --- First Day of Week ---
    setForcedFirstDayOfWeek(firstDay) {
        this.forcedFirstDayOfWeek$.next(firstDay);
        this.storageService.set(this.STORAGE_FIRST_DAY, firstDay);
    }
    getForcedFirstDayOfWeek() {
        return this.forcedFirstDayOfWeek$.pipe(map((fd) => (this.stateService.isEnabled() ? fd : null)));
    }
    removeForcedFirstDayOfWeek() {
        this.forcedFirstDayOfWeek$.next(null);
        this.storageService.remove(this.STORAGE_FIRST_DAY);
    }
    // --- Number Format ---
    setForcedNumberFormat(numberFormat) {
        this.forcedNumberFormat$.next(numberFormat);
        this.storageService.set(this.STORAGE_NUMBER_FORMAT, numberFormat);
    }
    getForcedNumberFormat() {
        return this.forcedNumberFormat$.pipe(map((nf) => (this.stateService.isEnabled() ? nf : null)));
    }
    removeForcedNumberFormat() {
        this.forcedNumberFormat$.next(null);
        this.storageService.remove(this.STORAGE_NUMBER_FORMAT);
    }
    // --- Tool Config ---
    setToolConfig(config) {
        this.toolConfig$.next(config);
    }
    // --- Pseudo-Localization ---
    setPseudoLocEnabled(enabled) {
        this.pseudoLocEnabled$.next(enabled);
        this.storageService.set(this.STORAGE_PSEUDO_LOC, enabled);
    }
    getPseudoLocEnabled() {
        return this.pseudoLocEnabled$.pipe(map((enabled) => (this.stateService.isEnabled() ? enabled : false)));
    }
    // --- RTL ---
    setRtlEnabled(enabled) {
        this.rtlEnabled$.next(enabled);
        this.storageService.set(this.STORAGE_RTL, enabled);
        this.applyRtl(enabled);
    }
    getRtlEnabled() {
        return this.rtlEnabled$.pipe(map((enabled) => (this.stateService.isEnabled() ? enabled : false)));
    }
    // --- Preset Hooks ---
    async applyPresetLocale(localeId) {
        if (localeId === null) {
            this.removeForcedLocale();
            return;
        }
        const locales = await firstValueFrom(this.locales$);
        const locale = locales.find((l) => l.id === localeId);
        if (locale) {
            this.setForcedLocale(locale);
        }
        else {
            console.warn(`Locale ${localeId} not found in available locales. Skipping.`);
        }
    }
    applyPresetI18n(config) {
        if (!config)
            return;
        if (config.locale !== undefined) {
            if (config.locale === null) {
                this.removeForcedLocale();
            }
            else {
                const locale = this.locales$.value.find((l) => l.id === config.locale);
                if (locale) {
                    this.setForcedLocale(locale);
                }
            }
        }
        if (config.timezone !== undefined) {
            if (config.timezone === null) {
                this.removeForcedTimezone();
            }
            else {
                const timezone = this.timezones$.value.find((t) => t.id === config.timezone);
                if (timezone) {
                    this.setForcedTimezone(timezone);
                }
            }
        }
        if (config.currency !== undefined) {
            if (config.currency === null) {
                this.removeForcedCurrency();
            }
            else {
                const currency = this.currencies$.value.find((c) => c.code === config.currency);
                if (currency) {
                    this.setForcedCurrency(currency);
                }
            }
        }
        if (config.unitSystem !== undefined) {
            if (config.unitSystem === null) {
                this.removeForcedUnitSystem();
            }
            else {
                this.setForcedUnitSystem(config.unitSystem);
            }
        }
        if (config.dateFormat !== undefined) {
            if (config.dateFormat === null) {
                this.removeForcedDateFormat();
            }
            else {
                this.setForcedDateFormat(config.dateFormat);
            }
        }
        if (config.firstDayOfWeek !== undefined) {
            if (config.firstDayOfWeek === null) {
                this.removeForcedFirstDayOfWeek();
            }
            else {
                this.setForcedFirstDayOfWeek(config.firstDayOfWeek);
            }
        }
        if (config.numberFormat !== undefined) {
            if (config.numberFormat === null) {
                this.removeForcedNumberFormat();
            }
            else {
                this.setForcedNumberFormat(config.numberFormat);
            }
        }
        if (config.pseudoLocEnabled !== undefined) {
            this.setPseudoLocEnabled(config.pseudoLocEnabled);
        }
        if (config.rtlEnabled !== undefined) {
            this.setRtlEnabled(config.rtlEnabled);
        }
    }
    getCurrentI18nState() {
        return {
            locale: this.forcedLocale$.value,
            timezone: this.forcedTimezone$.value,
            currency: this.forcedCurrency$.value,
            unitSystem: this.forcedUnitSystem$.value,
            dateFormat: this.forcedDateFormat$.value,
            firstDayOfWeek: this.forcedFirstDayOfWeek$.value,
            numberFormat: this.forcedNumberFormat$.value,
            pseudoLocEnabled: this.pseudoLocEnabled$.value,
            rtlEnabled: this.rtlEnabled$.value,
        };
    }
    getCurrentForcedLocaleId() {
        return this.forcedLocale$.value?.id ?? null;
    }
    // --- Private ---
    loadFromStorage() {
        const savedLocale = this.storageService.get(this.STORAGE_LOCALE);
        if (savedLocale) {
            this.forcedLocale$.next(savedLocale);
        }
        const savedTimezone = this.storageService.get(this.STORAGE_TIMEZONE);
        if (savedTimezone) {
            this.forcedTimezone$.next(savedTimezone);
        }
        const savedCurrency = this.storageService.get(this.STORAGE_CURRENCY);
        if (savedCurrency) {
            this.forcedCurrency$.next(savedCurrency);
        }
        const savedUnitSystem = this.storageService.get(this.STORAGE_UNIT_SYSTEM);
        if (savedUnitSystem) {
            this.forcedUnitSystem$.next(savedUnitSystem);
        }
        const savedDateFormat = this.storageService.get(this.STORAGE_DATE_FORMAT);
        if (savedDateFormat) {
            this.forcedDateFormat$.next(savedDateFormat);
        }
        const savedFirstDay = this.storageService.get(this.STORAGE_FIRST_DAY);
        if (savedFirstDay) {
            this.forcedFirstDayOfWeek$.next(savedFirstDay);
        }
        const savedNumberFormat = this.storageService.get(this.STORAGE_NUMBER_FORMAT);
        if (savedNumberFormat) {
            this.forcedNumberFormat$.next(savedNumberFormat);
        }
        const savedPseudoLoc = this.storageService.get(this.STORAGE_PSEUDO_LOC);
        if (savedPseudoLoc !== null) {
            this.pseudoLocEnabled$.next(savedPseudoLoc);
        }
        const savedRtl = this.storageService.get(this.STORAGE_RTL);
        if (savedRtl !== null) {
            this.rtlEnabled$.next(savedRtl);
            if (savedRtl) {
                this.applyRtl(true);
            }
        }
    }
    migrateOldLanguageKey() {
        const oldLanguage = this.storageService.get(this.OLD_LANGUAGE_KEY);
        if (oldLanguage && !this.storageService.get(this.STORAGE_LOCALE)) {
            const migrated = {
                id: oldLanguage.id,
                name: oldLanguage.name,
                code: oldLanguage.id,
            };
            this.storageService.set(this.STORAGE_LOCALE, migrated);
            this.storageService.remove(this.OLD_LANGUAGE_KEY);
        }
    }
    applyRtl(enabled) {
        if (this.document?.documentElement) {
            this.document.documentElement.dir = enabled ? 'rtl' : 'ltr';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalI18nService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalI18nService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalI18nService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

const PSEUDO_CHAR_MAP = {
    a: '\u00e4', b: '\u0183', c: '\u00e7', d: '\u0111', e: '\u00e9',
    f: '\u0192', g: '\u011f', h: '\u0127', i: '\u00ef', j: '\u0135',
    k: '\u0137', l: '\u013c', m: '\u1e41', n: '\u00f1', o: '\u00f6',
    p: '\u00fe', q: '\u01eb', r: '\u0159', s: '\u0161', t: '\u0163',
    u: '\u00fc', v: '\u1e7d', w: '\u0175', x: '\u1e8b', y: '\u00fd',
    z: '\u017e',
    A: '\u00c4', B: '\u0182', C: '\u00c7', D: '\u0110', E: '\u00c9',
    F: '\u0191', G: '\u011e', H: '\u0126', I: '\u00cf', J: '\u0134',
    K: '\u0136', L: '\u013b', M: '\u1e40', N: '\u00d1', O: '\u00d6',
    P: '\u00de', Q: '\u01ea', R: '\u0158', S: '\u0160', T: '\u0162',
    U: '\u00dc', V: '\u1e7c', W: '\u0174', X: '\u1e8a', Y: '\u00dd',
    Z: '\u017d',
};
const VOWELS = new Set(['a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U']);
function formatNumber(locale, value) {
    try {
        return new Intl.NumberFormat(locale).format(value);
    }
    catch {
        return String(value);
    }
}
function formatDate(locale, timezone, date) {
    try {
        return new Intl.DateTimeFormat(locale, {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            timeZone: timezone,
        }).format(date);
    }
    catch {
        return date.toLocaleDateString();
    }
}
function formatTime(locale, timezone, date) {
    try {
        return new Intl.DateTimeFormat(locale, {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            timeZoneName: 'short',
            timeZone: timezone,
        }).format(date);
    }
    catch {
        return date.toLocaleTimeString();
    }
}
function formatCurrency(locale, currency, value) {
    try {
        return new Intl.NumberFormat(locale, {
            style: 'currency',
            currency,
        }).format(value);
    }
    catch {
        return `${currency} ${value}`;
    }
}
function pseudoLocalize(text) {
    let result = '';
    for (const char of text) {
        result += PSEUDO_CHAR_MAP[char] ?? char;
    }
    return `[\u200B${result}\u200B]`;
}
function formatCustomDate(date, format, locale, timezone) {
    const d = date.getDate().toString().padStart(2, '0');
    const m = (date.getMonth() + 1).toString().padStart(2, '0');
    const y = date.getFullYear().toString();
    switch (format) {
        case 'MM/DD/YYYY': return `${m}/${d}/${y}`;
        case 'DD/MM/YYYY': return `${d}/${m}/${y}`;
        case 'YYYY-MM-DD': return `${y}-${m}-${d}`;
        default: return formatDate(locale, timezone, date);
    }
}
function formatCustomNumber(value, format, locale) {
    const [intPart, decPart] = value.toFixed(2).split('.');
    const digits = intPart.replace('-', '');
    const groups = [];
    for (let i = digits.length; i > 0; i -= 3) {
        groups.unshift(digits.slice(Math.max(0, i - 3), i));
    }
    const sign = value < 0 ? '-' : '';
    switch (format) {
        case 'period-comma': return `${sign}${groups.join(',')}.${decPart}`;
        case 'comma-period': return `${sign}${groups.join('.')},${decPart}`;
        case 'space-comma': return `${sign}${groups.join('\u00A0')},${decPart}`;
        default: return formatNumber(locale, value);
    }
}
function expandText(text, factor = 0.35) {
    const targetLength = Math.ceil(text.length * (1 + factor));
    let result = '';
    for (const char of text) {
        result += char;
        if (VOWELS.has(char) && result.length < targetLength) {
            result += char.toLowerCase();
        }
    }
    // Pad remaining if vowel duplication wasn't enough
    while (result.length < targetLength) {
        result += '~';
    }
    return result;
}

const NOT_FORCED = 'not-forced';
const UNIT_SYSTEM_VALUES = ['metric', 'imperial'];
const DATE_FORMAT_VALUES = ['locale-default', 'MM/DD/YYYY', 'DD/MM/YYYY', 'YYYY-MM-DD'];
const FIRST_DAY_VALUES = ['locale-default', 'sunday', 'monday', 'saturday'];
const NUMBER_FORMAT_VALUES = ['locale-default', 'period-comma', 'comma-period', 'space-comma'];
class ToolbarI18nToolComponent {
    // --- Constructor: restore persisted values ---
    constructor() {
        // --- Injects ---
        this.i18nService = inject(ToolbarInternalI18nService);
        // --- Readonly properties ---
        this.options = {
            title: 'i18n',
            description: 'Simulate regional & linguistic environments',
            size: 'tall',
            id: 'ndt-i18n',
            isClosable: true,
        };
        this.unitSystemOptions = [
            { value: NOT_FORCED, label: 'Not Forced' },
            { value: 'metric', label: 'Metric' },
            { value: 'imperial', label: 'Imperial' },
        ];
        this.dateFormatOptions = [
            { value: NOT_FORCED, label: 'Not Forced' },
            { value: 'locale-default', label: 'Locale Default' },
            { value: 'MM/DD/YYYY', label: 'MM/DD/YYYY' },
            { value: 'DD/MM/YYYY', label: 'DD/MM/YYYY' },
            { value: 'YYYY-MM-DD', label: 'YYYY-MM-DD (ISO)' },
        ];
        this.firstDayOptions = [
            { value: NOT_FORCED, label: 'Not Forced' },
            { value: 'locale-default', label: 'Locale Default' },
            { value: 'sunday', label: 'Sunday' },
            { value: 'monday', label: 'Monday' },
            { value: 'saturday', label: 'Saturday' },
        ];
        this.numberFormatOptions = [
            { value: NOT_FORCED, label: 'Not Forced' },
            { value: 'locale-default', label: 'Locale Default' },
            { value: 'period-comma', label: '1,234.56' },
            { value: 'comma-period', label: '1.234,56' },
            { value: 'space-comma', label: '1 234,56' },
        ];
        // --- Signals ---
        this.activeLocale = signal(NOT_FORCED);
        this.activeTimezone = signal(NOT_FORCED);
        this.activeCurrency = signal(NOT_FORCED);
        this.activeUnitSystem = signal(NOT_FORCED);
        this.activeDateFormat = signal(NOT_FORCED);
        this.activeFirstDayOfWeek = signal(NOT_FORCED);
        this.activeNumberFormat = signal(NOT_FORCED);
        this.pseudoLocEnabled = this.i18nService.pseudoLocEnabled;
        this.rtlEnabled = this.i18nService.rtlEnabled;
        // --- Computed ---
        this.toolConfig = computed(() => this.i18nService.toolConfig());
        this.hasAdvancedFormatSettings = computed(() => {
            const cfg = this.toolConfig();
            return (cfg.showUnits !== false ||
                cfg.showDateFormat !== false ||
                cfg.showNumberFormat !== false ||
                cfg.showFirstDayOfWeek !== false);
        });
        this.localeOptions = toSignal(this.i18nService.getAvailableLocales().pipe(map((locales) => [
            { value: NOT_FORCED, label: 'Not Forced' },
            ...locales.map(({ id: value, name: label }) => ({ value, label })),
        ])), { initialValue: [{ value: NOT_FORCED, label: 'Not Forced' }] });
        this.timezoneOptions = toSignal(this.i18nService.getAvailableTimezones().pipe(map((timezones) => [
            { value: NOT_FORCED, label: 'Not Forced' },
            ...timezones.map(({ id: value, name, offset }) => ({
                value,
                label: `${name} (${offset})`,
            })),
        ])), { initialValue: [{ value: NOT_FORCED, label: 'Not Forced' }] });
        this.currencyOptions = toSignal(this.i18nService.getAvailableCurrencies().pipe(map((currencies) => [
            { value: NOT_FORCED, label: 'Not Forced' },
            ...currencies.map(({ code: value, name, symbol }) => ({
                value,
                label: `${name} (${symbol})`,
            })),
        ])), { initialValue: [{ value: NOT_FORCED, label: 'Not Forced' }] });
        this.currentLocaleCode = computed(() => {
            const id = this.activeLocale();
            return id === NOT_FORCED ? 'en-US' : id;
        });
        this.currentTimezone = computed(() => {
            const id = this.activeTimezone();
            return id === NOT_FORCED ? 'UTC' : id;
        });
        this.currentCurrencyCode = computed(() => {
            const id = this.activeCurrency();
            return id === NOT_FORCED ? 'USD' : id;
        });
        this.previewDate_ = new Date();
        this.previewNumber = computed(() => {
            const nf = this.activeNumberFormat();
            if (nf !== NOT_FORCED && nf !== 'locale-default') {
                return formatCustomNumber(1234.56, nf, this.currentLocaleCode());
            }
            return formatNumber(this.currentLocaleCode(), 1234.56);
        });
        this.previewDate = computed(() => {
            const df = this.activeDateFormat();
            if (df !== NOT_FORCED && df !== 'locale-default') {
                return formatCustomDate(this.previewDate_, df, this.currentLocaleCode(), this.currentTimezone());
            }
            return formatDate(this.currentLocaleCode(), this.currentTimezone(), this.previewDate_);
        });
        this.previewTime = computed(() => formatTime(this.currentLocaleCode(), this.currentTimezone(), this.previewDate_));
        this.previewCurrencyValue = computed(() => {
            const nf = this.activeNumberFormat();
            if (nf !== NOT_FORCED && nf !== 'locale-default') {
                const code = this.currentCurrencyCode();
                const symbol = CURRENCY_SYMBOLS[code] ?? code;
                return `${symbol}${formatCustomNumber(1234.56, nf, this.currentLocaleCode())}`;
            }
            return formatCurrency(this.currentLocaleCode(), this.currentCurrencyCode(), 1234.56);
        });
        this.pseudoPreview = computed(() => {
            const sample = 'Hello World! This is a sample text for testing.';
            const pseudo = pseudoLocalize(sample);
            return expandText(pseudo);
        });
        const state = this.i18nService.getCurrentI18nState();
        if (state.locale)
            this.activeLocale.set(state.locale.id);
        if (state.timezone)
            this.activeTimezone.set(state.timezone.id);
        if (state.currency)
            this.activeCurrency.set(state.currency.code);
        if (state.unitSystem)
            this.activeUnitSystem.set(state.unitSystem);
        if (state.dateFormat)
            this.activeDateFormat.set(state.dateFormat);
        if (state.firstDayOfWeek)
            this.activeFirstDayOfWeek.set(state.firstDayOfWeek);
        if (state.numberFormat)
            this.activeNumberFormat.set(state.numberFormat);
    }
    // --- Event handlers ---
    onLocaleChange(localeId) {
        this.activeLocale.set(localeId);
        if (localeId === NOT_FORCED || !localeId) {
            this.i18nService.removeForcedLocale();
            return;
        }
        const selected = this.i18nService.locales().find(({ id }) => id === localeId);
        if (selected) {
            this.i18nService.setForcedLocale(selected);
        }
    }
    onTimezoneChange(timezoneId) {
        this.activeTimezone.set(timezoneId);
        if (timezoneId === NOT_FORCED || !timezoneId) {
            this.i18nService.removeForcedTimezone();
            return;
        }
        const selected = this.i18nService.timezones().find(({ id }) => id === timezoneId);
        if (selected) {
            this.i18nService.setForcedTimezone(selected);
        }
    }
    onCurrencyChange(currencyCode) {
        this.activeCurrency.set(currencyCode);
        if (currencyCode === NOT_FORCED || !currencyCode) {
            this.i18nService.removeForcedCurrency();
            return;
        }
        const selected = this.i18nService.availableCurrencies().find(({ code }) => code === currencyCode);
        if (selected) {
            this.i18nService.setForcedCurrency(selected);
        }
    }
    onUnitSystemChange(unitSystem) {
        this.activeUnitSystem.set(unitSystem);
        if (unitSystem === NOT_FORCED || !unitSystem) {
            this.i18nService.removeForcedUnitSystem();
            return;
        }
        if (UNIT_SYSTEM_VALUES.includes(unitSystem)) {
            this.i18nService.setForcedUnitSystem(unitSystem);
        }
    }
    onPseudoLocToggle(event) {
        const checked = event.target.checked;
        this.i18nService.setPseudoLocEnabled(checked);
    }
    onRtlToggle(event) {
        const checked = event.target.checked;
        this.i18nService.setRtlEnabled(checked);
    }
    onDateFormatChange(value) {
        this.activeDateFormat.set(value);
        if (value === NOT_FORCED || !value) {
            this.i18nService.removeForcedDateFormat();
            return;
        }
        if (DATE_FORMAT_VALUES.includes(value)) {
            this.i18nService.setForcedDateFormat(value);
        }
    }
    onFirstDayOfWeekChange(value) {
        this.activeFirstDayOfWeek.set(value);
        if (value === NOT_FORCED || !value) {
            this.i18nService.removeForcedFirstDayOfWeek();
            return;
        }
        if (FIRST_DAY_VALUES.includes(value)) {
            this.i18nService.setForcedFirstDayOfWeek(value);
        }
    }
    onNumberFormatChange(value) {
        this.activeNumberFormat.set(value);
        if (value === NOT_FORCED || !value) {
            this.i18nService.removeForcedNumberFormat();
            return;
        }
        if (NUMBER_FORMAT_VALUES.includes(value)) {
            this.i18nService.setForcedNumberFormat(value);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarI18nToolComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarI18nToolComponent, isStandalone: true, selector: "ndt-i18n-tool", ngImport: i0, template: `
    <ndt-toolbar-tool toolTitle="i18n" icon="globe" [options]="options">
      <div class="i18n-section">
        <!-- Formatting Preview (immediate feedback, always visible) -->
        @if (toolConfig().showFormattingPreview !== false) {
          <div class="i18n-preview" aria-label="Formatting preview">
            <div class="i18n-preview-row">
              <span class="preview-label">Number</span>
              <span class="preview-value">{{ previewNumber() }}</span>
            </div>
            <div class="i18n-preview-row">
              <span class="preview-label">Date</span>
              <span class="preview-value">{{ previewDate() }}</span>
            </div>
            <div class="i18n-preview-row">
              <span class="preview-label">Time</span>
              <span class="preview-value">{{ previewTime() }}</span>
            </div>
            <div class="i18n-preview-row">
              <span class="preview-label">Currency</span>
              <span class="preview-value">{{ previewCurrencyValue() }}</span>
            </div>
          </div>
        }

        <!-- Core settings: locale, timezone, currency -->
        <div class="i18n-select-grid">
          @if (toolConfig().showLocale !== false) {
            <div class="i18n-select-group">
              <label for="i18n-locale">Locale</label>
              <ndt-select
                id="i18n-locale"
                [value]="activeLocale()"
                [options]="localeOptions()"
                [size]="'medium'"
                (valueChange)="onLocaleChange($event ?? '')"
              />
            </div>
          }
          @if (toolConfig().showTimezone !== false) {
            <div class="i18n-select-group">
              <label for="i18n-timezone">Timezone</label>
              <ndt-select
                id="i18n-timezone"
                [value]="activeTimezone()"
                [options]="timezoneOptions()"
                [size]="'medium'"
                (valueChange)="onTimezoneChange($event ?? '')"
              />
            </div>
          }
          @if (toolConfig().showCurrency !== false) {
            <div class="i18n-select-group">
              <label for="i18n-currency">Currency</label>
              <ndt-select
                id="i18n-currency"
                [value]="activeCurrency()"
                [options]="currencyOptions()"
                [size]="'medium'"
                (valueChange)="onCurrencyChange($event ?? '')"
              />
            </div>
          }
        </div>

        <!-- Advanced format options (progressive disclosure) -->
        @if (hasAdvancedFormatSettings()) {
          <details class="i18n-disclosure">
            <summary>Advanced format options</summary>
            <div class="i18n-select-grid">
              @if (toolConfig().showUnits !== false) {
                <div class="i18n-select-group">
                  <label for="i18n-units">Units</label>
                  <ndt-select
                    id="i18n-units"
                    [value]="activeUnitSystem()"
                    [options]="unitSystemOptions"
                    [size]="'medium'"
                    (valueChange)="onUnitSystemChange($event ?? '')"
                  />
                </div>
              }
              @if (toolConfig().showDateFormat !== false) {
                <div class="i18n-select-group">
                  <label for="i18n-date-format">Date Format</label>
                  <ndt-select
                    id="i18n-date-format"
                    [value]="activeDateFormat()"
                    [options]="dateFormatOptions"
                    [size]="'medium'"
                    (valueChange)="onDateFormatChange($event ?? '')"
                  />
                </div>
              }
              @if (toolConfig().showNumberFormat !== false) {
                <div class="i18n-select-group">
                  <label for="i18n-number-format">Number Format</label>
                  <ndt-select
                    id="i18n-number-format"
                    [value]="activeNumberFormat()"
                    [options]="numberFormatOptions"
                    [size]="'medium'"
                    (valueChange)="onNumberFormatChange($event ?? '')"
                  />
                </div>
              }
              @if (toolConfig().showFirstDayOfWeek !== false) {
                <div class="i18n-select-group">
                  <label for="i18n-first-day">First Day of Week</label>
                  <ndt-select
                    id="i18n-first-day"
                    [value]="activeFirstDayOfWeek()"
                    [options]="firstDayOptions"
                    [size]="'medium'"
                    (valueChange)="onFirstDayOfWeekChange($event ?? '')"
                  />
                </div>
              }
            </div>
          </details>
        }

        <!-- Stress Testing (separate collapsible section) -->
        @if (toolConfig().showStressTesting !== false) {
          <details class="i18n-disclosure">
            <summary>Stress testing</summary>
            <div class="i18n-toggle-section">
              <div class="i18n-toggle-row">
                <div class="toggle-info">
                  <span class="toggle-label">Pseudo-Localization</span>
                  <span class="toggle-hint">Detect hardcoded strings</span>
                </div>
                <label class="toggle-switch">
                  <input
                    type="checkbox"
                    [checked]="pseudoLocEnabled()"
                    (change)="onPseudoLocToggle($event)"
                  />
                  <span class="toggle-track"></span>
                </label>
              </div>
              @if (pseudoLocEnabled()) {
                <div class="i18n-pseudo-preview">
                  {{ pseudoPreview() }}
                </div>
              }
              <div class="i18n-toggle-row">
                <div class="toggle-info">
                  <span class="toggle-label">RTL Mirroring</span>
                  <span class="toggle-hint">Set document direction to RTL</span>
                </div>
                <label class="toggle-switch">
                  <input
                    type="checkbox"
                    [checked]="rtlEnabled()"
                    (change)="onRtlToggle($event)"
                  />
                  <span class="toggle-track"></span>
                </label>
              </div>
            </div>
          </details>
        }
      </div>
    </ndt-toolbar-tool>
  `, isInline: true, styles: [":host{display:block}.i18n-section{display:flex;flex-direction:column;gap:var(--ndt-spacing-sm);padding-top:0}.i18n-select-grid{display:grid;grid-template-columns:1fr 1fr;gap:var(--ndt-spacing-sm)}.i18n-disclosure{margin:0}.i18n-disclosure summary{font-size:var(--ndt-font-size-xs);font-weight:500;color:var(--ndt-text-secondary);padding:var(--ndt-spacing-xs) 0;cursor:pointer;list-style:none;display:flex;align-items:center;gap:var(--ndt-spacing-xs);-webkit-user-select:none;user-select:none;border-radius:var(--ndt-border-radius-small)}.i18n-disclosure summary::-webkit-details-marker{display:none}.i18n-disclosure summary:before{content:\"\";display:inline-block;width:0;height:0;border-left:4px solid var(--ndt-text-muted);border-top:3px solid transparent;border-bottom:3px solid transparent;transition:transform .15s ease}.i18n-disclosure summary:hover{color:var(--ndt-text-primary)}.i18n-disclosure summary:focus-visible{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:2px}.i18n-disclosure[open] summary:before{transform:rotate(90deg)}.i18n-disclosure>:not(summary){margin-top:var(--ndt-spacing-sm)}.i18n-select-group{display:flex;flex-direction:column;gap:2px}.i18n-select-group label{font-size:var(--ndt-font-size-xs);color:var(--ndt-text-secondary);font-weight:600}.i18n-preview{background:var(--ndt-hover-bg);border-radius:var(--ndt-border-radius-medium);padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);display:flex;flex-direction:column;gap:1px}.i18n-preview-row{display:flex;justify-content:space-between;align-items:center;font-size:var(--ndt-font-size-xxs);gap:var(--ndt-spacing-xs);padding:2px 0}.i18n-preview-row .preview-label{color:var(--ndt-text-muted);flex-shrink:0}.i18n-preview-row .preview-value{font-family:JetBrains Mono,ui-monospace,monospace;font-size:var(--ndt-font-size-xxs);color:var(--ndt-text-primary);text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.i18n-toggle-section{display:flex;flex-direction:column;gap:0}.i18n-toggle-row{display:flex;align-items:center;justify-content:space-between;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);gap:var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-small);transition:background .15s ease}.i18n-toggle-row:hover{background:var(--ndt-hover-bg)}.i18n-toggle-row .toggle-info{display:flex;flex-direction:column;gap:1px;min-width:0}.i18n-toggle-row .toggle-label{font-size:var(--ndt-font-size-xs);color:var(--ndt-text-secondary);font-weight:500}.i18n-toggle-row .toggle-hint{font-size:var(--ndt-font-size-xxs);color:var(--ndt-text-muted);line-height:1.3}.toggle-switch{position:relative;display:inline-flex;align-items:center;width:34px;height:18px;flex-shrink:0;cursor:pointer}.toggle-switch input{opacity:0;width:0;height:0;position:absolute}.toggle-switch input:focus-visible+.toggle-track{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:2px}.toggle-switch .toggle-track{position:absolute;inset:0;background:var(--ndt-border-primary);border-radius:9px;transition:background .2s ease}.toggle-switch .toggle-track:after{content:\"\";position:absolute;top:2px;left:2px;width:14px;height:14px;background:#fff;border-radius:50%;transition:transform .2s cubic-bezier(.4,0,.2,1);box-shadow:0 1px 2px #0000001f}.toggle-switch input:checked+.toggle-track{background:var(--ndt-primary)}.toggle-switch input:checked+.toggle-track:after{transform:translate(16px)}.i18n-pseudo-preview{background:var(--ndt-hover-bg);border-radius:var(--ndt-border-radius-small);padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);margin:0 var(--ndt-spacing-sm);font-size:var(--ndt-font-size-xs);color:var(--ndt-text-muted);font-family:JetBrains Mono,ui-monospace,monospace;word-break:break-word;line-height:1.5}\n"], dependencies: [{ kind: "component", type: ToolbarToolComponent, selector: "ndt-toolbar-tool", inputs: ["options", "icon", "toolTitle", "badge"] }, { kind: "component", type: ToolbarSelectComponent, selector: "ndt-select", inputs: ["value", "options", "ariaLabel", "label", "size", "placeholder"], outputs: ["valueChange"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarI18nToolComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-i18n-tool', standalone: true, imports: [ToolbarToolComponent, ToolbarSelectComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: `
    <ndt-toolbar-tool toolTitle="i18n" icon="globe" [options]="options">
      <div class="i18n-section">
        <!-- Formatting Preview (immediate feedback, always visible) -->
        @if (toolConfig().showFormattingPreview !== false) {
          <div class="i18n-preview" aria-label="Formatting preview">
            <div class="i18n-preview-row">
              <span class="preview-label">Number</span>
              <span class="preview-value">{{ previewNumber() }}</span>
            </div>
            <div class="i18n-preview-row">
              <span class="preview-label">Date</span>
              <span class="preview-value">{{ previewDate() }}</span>
            </div>
            <div class="i18n-preview-row">
              <span class="preview-label">Time</span>
              <span class="preview-value">{{ previewTime() }}</span>
            </div>
            <div class="i18n-preview-row">
              <span class="preview-label">Currency</span>
              <span class="preview-value">{{ previewCurrencyValue() }}</span>
            </div>
          </div>
        }

        <!-- Core settings: locale, timezone, currency -->
        <div class="i18n-select-grid">
          @if (toolConfig().showLocale !== false) {
            <div class="i18n-select-group">
              <label for="i18n-locale">Locale</label>
              <ndt-select
                id="i18n-locale"
                [value]="activeLocale()"
                [options]="localeOptions()"
                [size]="'medium'"
                (valueChange)="onLocaleChange($event ?? '')"
              />
            </div>
          }
          @if (toolConfig().showTimezone !== false) {
            <div class="i18n-select-group">
              <label for="i18n-timezone">Timezone</label>
              <ndt-select
                id="i18n-timezone"
                [value]="activeTimezone()"
                [options]="timezoneOptions()"
                [size]="'medium'"
                (valueChange)="onTimezoneChange($event ?? '')"
              />
            </div>
          }
          @if (toolConfig().showCurrency !== false) {
            <div class="i18n-select-group">
              <label for="i18n-currency">Currency</label>
              <ndt-select
                id="i18n-currency"
                [value]="activeCurrency()"
                [options]="currencyOptions()"
                [size]="'medium'"
                (valueChange)="onCurrencyChange($event ?? '')"
              />
            </div>
          }
        </div>

        <!-- Advanced format options (progressive disclosure) -->
        @if (hasAdvancedFormatSettings()) {
          <details class="i18n-disclosure">
            <summary>Advanced format options</summary>
            <div class="i18n-select-grid">
              @if (toolConfig().showUnits !== false) {
                <div class="i18n-select-group">
                  <label for="i18n-units">Units</label>
                  <ndt-select
                    id="i18n-units"
                    [value]="activeUnitSystem()"
                    [options]="unitSystemOptions"
                    [size]="'medium'"
                    (valueChange)="onUnitSystemChange($event ?? '')"
                  />
                </div>
              }
              @if (toolConfig().showDateFormat !== false) {
                <div class="i18n-select-group">
                  <label for="i18n-date-format">Date Format</label>
                  <ndt-select
                    id="i18n-date-format"
                    [value]="activeDateFormat()"
                    [options]="dateFormatOptions"
                    [size]="'medium'"
                    (valueChange)="onDateFormatChange($event ?? '')"
                  />
                </div>
              }
              @if (toolConfig().showNumberFormat !== false) {
                <div class="i18n-select-group">
                  <label for="i18n-number-format">Number Format</label>
                  <ndt-select
                    id="i18n-number-format"
                    [value]="activeNumberFormat()"
                    [options]="numberFormatOptions"
                    [size]="'medium'"
                    (valueChange)="onNumberFormatChange($event ?? '')"
                  />
                </div>
              }
              @if (toolConfig().showFirstDayOfWeek !== false) {
                <div class="i18n-select-group">
                  <label for="i18n-first-day">First Day of Week</label>
                  <ndt-select
                    id="i18n-first-day"
                    [value]="activeFirstDayOfWeek()"
                    [options]="firstDayOptions"
                    [size]="'medium'"
                    (valueChange)="onFirstDayOfWeekChange($event ?? '')"
                  />
                </div>
              }
            </div>
          </details>
        }

        <!-- Stress Testing (separate collapsible section) -->
        @if (toolConfig().showStressTesting !== false) {
          <details class="i18n-disclosure">
            <summary>Stress testing</summary>
            <div class="i18n-toggle-section">
              <div class="i18n-toggle-row">
                <div class="toggle-info">
                  <span class="toggle-label">Pseudo-Localization</span>
                  <span class="toggle-hint">Detect hardcoded strings</span>
                </div>
                <label class="toggle-switch">
                  <input
                    type="checkbox"
                    [checked]="pseudoLocEnabled()"
                    (change)="onPseudoLocToggle($event)"
                  />
                  <span class="toggle-track"></span>
                </label>
              </div>
              @if (pseudoLocEnabled()) {
                <div class="i18n-pseudo-preview">
                  {{ pseudoPreview() }}
                </div>
              }
              <div class="i18n-toggle-row">
                <div class="toggle-info">
                  <span class="toggle-label">RTL Mirroring</span>
                  <span class="toggle-hint">Set document direction to RTL</span>
                </div>
                <label class="toggle-switch">
                  <input
                    type="checkbox"
                    [checked]="rtlEnabled()"
                    (change)="onRtlToggle($event)"
                  />
                  <span class="toggle-track"></span>
                </label>
              </div>
            </div>
          </details>
        }
      </div>
    </ndt-toolbar-tool>
  `, styles: [":host{display:block}.i18n-section{display:flex;flex-direction:column;gap:var(--ndt-spacing-sm);padding-top:0}.i18n-select-grid{display:grid;grid-template-columns:1fr 1fr;gap:var(--ndt-spacing-sm)}.i18n-disclosure{margin:0}.i18n-disclosure summary{font-size:var(--ndt-font-size-xs);font-weight:500;color:var(--ndt-text-secondary);padding:var(--ndt-spacing-xs) 0;cursor:pointer;list-style:none;display:flex;align-items:center;gap:var(--ndt-spacing-xs);-webkit-user-select:none;user-select:none;border-radius:var(--ndt-border-radius-small)}.i18n-disclosure summary::-webkit-details-marker{display:none}.i18n-disclosure summary:before{content:\"\";display:inline-block;width:0;height:0;border-left:4px solid var(--ndt-text-muted);border-top:3px solid transparent;border-bottom:3px solid transparent;transition:transform .15s ease}.i18n-disclosure summary:hover{color:var(--ndt-text-primary)}.i18n-disclosure summary:focus-visible{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:2px}.i18n-disclosure[open] summary:before{transform:rotate(90deg)}.i18n-disclosure>:not(summary){margin-top:var(--ndt-spacing-sm)}.i18n-select-group{display:flex;flex-direction:column;gap:2px}.i18n-select-group label{font-size:var(--ndt-font-size-xs);color:var(--ndt-text-secondary);font-weight:600}.i18n-preview{background:var(--ndt-hover-bg);border-radius:var(--ndt-border-radius-medium);padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);display:flex;flex-direction:column;gap:1px}.i18n-preview-row{display:flex;justify-content:space-between;align-items:center;font-size:var(--ndt-font-size-xxs);gap:var(--ndt-spacing-xs);padding:2px 0}.i18n-preview-row .preview-label{color:var(--ndt-text-muted);flex-shrink:0}.i18n-preview-row .preview-value{font-family:JetBrains Mono,ui-monospace,monospace;font-size:var(--ndt-font-size-xxs);color:var(--ndt-text-primary);text-align:right;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.i18n-toggle-section{display:flex;flex-direction:column;gap:0}.i18n-toggle-row{display:flex;align-items:center;justify-content:space-between;padding:var(--ndt-spacing-xs) var(--ndt-spacing-sm);gap:var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-small);transition:background .15s ease}.i18n-toggle-row:hover{background:var(--ndt-hover-bg)}.i18n-toggle-row .toggle-info{display:flex;flex-direction:column;gap:1px;min-width:0}.i18n-toggle-row .toggle-label{font-size:var(--ndt-font-size-xs);color:var(--ndt-text-secondary);font-weight:500}.i18n-toggle-row .toggle-hint{font-size:var(--ndt-font-size-xxs);color:var(--ndt-text-muted);line-height:1.3}.toggle-switch{position:relative;display:inline-flex;align-items:center;width:34px;height:18px;flex-shrink:0;cursor:pointer}.toggle-switch input{opacity:0;width:0;height:0;position:absolute}.toggle-switch input:focus-visible+.toggle-track{outline:2px solid rgba(var(--ndt-primary-rgb),.5);outline-offset:2px}.toggle-switch .toggle-track{position:absolute;inset:0;background:var(--ndt-border-primary);border-radius:9px;transition:background .2s ease}.toggle-switch .toggle-track:after{content:\"\";position:absolute;top:2px;left:2px;width:14px;height:14px;background:#fff;border-radius:50%;transition:transform .2s cubic-bezier(.4,0,.2,1);box-shadow:0 1px 2px #0000001f}.toggle-switch input:checked+.toggle-track{background:var(--ndt-primary)}.toggle-switch input:checked+.toggle-track:after{transform:translate(16px)}.i18n-pseudo-preview{background:var(--ndt-hover-bg);border-radius:var(--ndt-border-radius-small);padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);margin:0 var(--ndt-spacing-sm);font-size:var(--ndt-font-size-xs);color:var(--ndt-text-muted);font-family:JetBrains Mono,ui-monospace,monospace;word-break:break-word;line-height:1.5}\n"] }]
        }], ctorParameters: () => [] });

class ToolbarInternalPermissionsService {
    constructor() {
        this.STORAGE_KEY = 'permissions';
        this.storageService = inject(ToolbarStorageService);
        this.stateService = inject(ToolbarStateService);
        this.appPermissions$ = new BehaviorSubject([]);
        this.forcedStateSubject = new BehaviorSubject({
            granted: [],
            denied: [],
        });
        this.forcedState$ = this.forcedStateSubject.asObservable();
        this.permissions$ = combineLatest([
            this.appPermissions$,
            this.forcedState$,
        ]).pipe(map(([appPermissions, { granted, denied }]) => {
            // If toolbar is disabled, return app permissions without overrides
            if (!this.stateService.isEnabled()) {
                return appPermissions;
            }
            return appPermissions.map((permission) => {
                const isForced = granted.includes(permission.id) || denied.includes(permission.id);
                return {
                    ...permission,
                    isForced,
                    isGranted: granted.includes(permission.id)
                        ? true
                        : denied.includes(permission.id)
                            ? false
                            : permission.isGranted,
                    originalValue: isForced ? permission.isGranted : undefined,
                };
            });
        }));
        this.permissions = toSignal(this.permissions$, { initialValue: [] });
        // Apply to source
        this.applyCallback = signal(null);
        this.applyStates = signal({});
        this.hasApplyCallback = computed(() => this.applyCallback() !== null);
        this.loadForcedState();
    }
    setAppPermissions(permissions) {
        this.appPermissions$.next(permissions);
        this.validateAndCleanForcedState(permissions);
    }
    setPermission(id, granted) {
        const { granted: grantedIds, denied: deniedIds } = this.forcedStateSubject.value;
        const newGranted = grantedIds.filter((permId) => permId !== id);
        const newDenied = deniedIds.filter((permId) => permId !== id);
        if (granted) {
            newGranted.push(id);
        }
        else {
            newDenied.push(id);
        }
        const newState = { granted: newGranted, denied: newDenied };
        this.forcedStateSubject.next(newState);
        this.storageService.set(this.STORAGE_KEY, newState);
    }
    removePermissionOverride(id) {
        const { granted, denied } = this.forcedStateSubject.value;
        const newState = {
            granted: granted.filter((permId) => permId !== id),
            denied: denied.filter((permId) => permId !== id),
        };
        this.forcedStateSubject.next(newState);
        this.storageService.set(this.STORAGE_KEY, newState);
    }
    getForcedPermissions() {
        return this.permissions$.pipe(map((permissions) => {
            // If toolbar is disabled, return empty array (no forced values)
            if (!this.stateService.isEnabled()) {
                return [];
            }
            return permissions.filter((permission) => permission.isForced);
        }));
    }
    /**
     * Apply a preset permissions state, replacing the current forced state.
     * Useful for automated testing or restoring saved configurations.
     * @param state The preset forced permissions state to apply
     */
    applyPresetPermissions(state) {
        this.forcedStateSubject.next(state);
        this.storageService.set(this.STORAGE_KEY, state);
    }
    /**
     * Get the current forced permissions state.
     * Returns a deep copy to prevent external mutations.
     * @returns Current forced permissions state
     */
    getCurrentForcedState() {
        const currentState = this.forcedStateSubject.value;
        return {
            granted: [...currentState.granted],
            denied: [...currentState.denied],
        };
    }
    loadForcedState() {
        try {
            const savedState = this.storageService.get(this.STORAGE_KEY);
            if (savedState && this.isValidForcedState(savedState)) {
                this.forcedStateSubject.next(savedState);
            }
        }
        catch (error) {
            console.warn('Error loading forced permissions state from localStorage:', error);
        }
    }
    isValidForcedState(state) {
        if (!state || typeof state !== 'object') {
            return false;
        }
        const candidate = state;
        return (Array.isArray(candidate['granted']) &&
            Array.isArray(candidate['denied']));
    }
    setApplyToSource(callback) {
        this.applyCallback.set(callback);
    }
    async applyToSource(id, value) {
        const callback = this.applyCallback();
        if (!callback)
            return;
        this.applyStates.update((s) => ({ ...s, [id]: 'loading' }));
        try {
            await callback(id, value);
            this.applyStates.update((s) => ({ ...s, [id]: 'success' }));
            setTimeout(() => this.applyStates.update((s) => ({ ...s, [id]: 'idle' })), 1500);
        }
        catch {
            this.applyStates.update((s) => ({ ...s, [id]: 'error' }));
            setTimeout(() => this.applyStates.update((s) => ({ ...s, [id]: 'idle' })), 1500);
        }
    }
    validateAndCleanForcedState(permissions) {
        const currentState = this.forcedStateSubject.value;
        const validIds = new Set(permissions.map((p) => p.id));
        const cleanedGranted = currentState.granted.filter((id) => validIds.has(id));
        const cleanedDenied = currentState.denied.filter((id) => validIds.has(id));
        const hasInvalidIds = cleanedGranted.length !== currentState.granted.length ||
            cleanedDenied.length !== currentState.denied.length;
        if (hasInvalidIds) {
            const cleanedState = {
                granted: cleanedGranted,
                denied: cleanedDenied,
            };
            this.forcedStateSubject.next(cleanedState);
            this.storageService.set(this.STORAGE_KEY, cleanedState);
            const invalidIds = [
                ...currentState.granted.filter((id) => !validIds.has(id)),
                ...currentState.denied.filter((id) => !validIds.has(id)),
            ];
            if (invalidIds.length > 0) {
                console.warn('Removed invalid permission IDs from forced state:', invalidIds);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalPermissionsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalPermissionsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalPermissionsService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

class ToolbarPermissionsToolComponent {
    constructor() {
        // Injects
        this.permissionsService = inject(ToolbarInternalPermissionsService);
        this.storageService = inject(ToolbarStorageService);
        // Constants
        this.VIEW_STATE_KEY = 'permissions-view';
        // Signals
        this.activeFilter = signal('all');
        this.searchQuery = signal('');
        this.pinnedIds = signal(new Set());
        this.collapsedGroups = signal(new Set());
        this.permissions = this.permissionsService.permissions;
        // Computed badge count for forced values
        this.badgeCount = computed(() => {
            const count = this.permissions().filter((p) => p.isForced).length;
            if (count === 0)
                return '';
            if (count > 99)
                return '99+';
            return count.toString();
        });
        this.hasNoPermissions = computed(() => this.permissions().length === 0);
        this.filteredPermissions = computed(() => {
            return this.permissions().filter((permission) => {
                const searchTerm = this.searchQuery().toLowerCase();
                const permissionName = permission.name.toLowerCase();
                const permissionDescription = permission.description?.toLowerCase() ?? '';
                const matchesSearch = !this.searchQuery() ||
                    permissionName.includes(searchTerm) ||
                    permissionDescription.includes(searchTerm);
                const matchesFilter = this.activeFilter() === 'all' ||
                    (this.activeFilter() === 'forced' && permission.isForced) ||
                    (this.activeFilter() === 'granted' && permission.isGranted) ||
                    (this.activeFilter() === 'denied' && !permission.isGranted);
                return matchesSearch && matchesFilter;
            });
        });
        this.groupedPermissions = computed(() => groupItems(this.filteredPermissions(), this.pinnedIds()));
        this.flatPermissions = computed(() => {
            const { pinned, ungrouped } = this.groupedPermissions();
            return [...pinned, ...ungrouped];
        });
        this.hasAnyGroups = computed(() => this.groupedPermissions().groups.length > 0);
        this.hasNoFilteredPermissions = computed(() => this.filteredPermissions().length === 0);
        // Other properties
        this.options = {
            title: 'Permissions',
            description: 'Manage permission overrides for your current session',
            isClosable: true,
            size: 'tall',
            id: 'ndt-permissions',
        };
        this.filterOptions = [
            { value: 'all', label: 'All' },
            { value: 'forced', label: 'Forced' },
            { value: 'granted', label: 'Granted' },
            { value: 'denied', label: 'Denied' },
        ];
        this.permissionValueOptions = [
            { value: 'not-forced', label: 'Not Forced' },
            { value: 'denied', label: 'Forced Denied' },
            { value: 'granted', label: 'Forced Granted' },
        ];
        // Apply to source (delegated to internal service)
        this.hasApplyCallback = this.permissionsService.hasApplyCallback;
        this.loadViewState();
        // Save view state on changes
        effect(() => {
            const state = {
                searchQuery: this.searchQuery(),
                filter: this.activeFilter(),
                sortOrder: 'asc',
                pinnedIds: [...this.pinnedIds()],
                collapsedGroups: [...this.collapsedGroups()],
            };
            this.storageService.set(this.VIEW_STATE_KEY, state);
        });
    }
    loadViewState() {
        try {
            const saved = this.storageService.get(this.VIEW_STATE_KEY);
            if (saved) {
                this.searchQuery.set(saved.searchQuery ?? '');
                const filter = saved.filter;
                if (['all', 'forced', 'granted', 'denied'].includes(filter)) {
                    this.activeFilter.set(filter);
                }
                if (saved.pinnedIds?.length) {
                    this.pinnedIds.set(new Set(saved.pinnedIds));
                }
                if (saved.collapsedGroups?.length) {
                    this.collapsedGroups.set(new Set(saved.collapsedGroups));
                }
            }
        }
        catch {
            // Use defaults on error
        }
    }
    getApplyState(permissionId) {
        return this.permissionsService.applyStates()[permissionId] ?? 'idle';
    }
    onApplyToSource(permissionId, value) {
        this.permissionsService.applyToSource(permissionId, value);
    }
    // Public methods
    onFilterChange(value) {
        const filter = this.filterOptions.find((f) => f.value === value);
        if (filter) {
            this.activeFilter.set(filter.value);
        }
    }
    onPermissionChange(id, value) {
        switch (value) {
            case 'not-forced':
                this.permissionsService.removePermissionOverride(id);
                break;
            case 'granted':
                this.permissionsService.setPermission(id, true);
                break;
            case 'denied':
                this.permissionsService.setPermission(id, false);
                break;
        }
    }
    onSearchChange(query) {
        this.searchQuery.set(query);
    }
    togglePin(permissionId) {
        this.pinnedIds.update((ids) => {
            const next = new Set(ids);
            if (next.has(permissionId)) {
                next.delete(permissionId);
            }
            else {
                next.add(permissionId);
            }
            return next;
        });
    }
    isCollapsed(name) {
        return this.collapsedGroups().has(name);
    }
    setCollapsed(name, collapsed) {
        this.collapsedGroups.update((set) => {
            const next = new Set(set);
            if (collapsed) {
                next.add(name);
            }
            else {
                next.delete(name);
            }
            return next;
        });
    }
    // Protected methods
    getPermissionValue(permission) {
        if (!permission.isForced)
            return '';
        return permission.isGranted ? 'granted' : 'denied';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarPermissionsToolComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarPermissionsToolComponent, isStandalone: true, selector: "ndt-permissions-tool", ngImport: i0, template: `
    <ndt-toolbar-tool
      [options]="options"
      toolTitle="Permissions"
      icon="lock"
      [badge]="badgeCount()"
    >
      <div class="container">
        <ndt-tool-header
          [(searchQuery)]="searchQuery"
          [activeFilter]="activeFilter()"
          (activeFilterChange)="onFilterChange($event)"
          searchPlaceholder="Search permissions by name or description"
          searchAriaLabel="Search permissions"
          filterAriaLabel="Filter permissions by state"
          [filterOptions]="filterOptions"
        />

        <ndt-list
          [hasItems]="!hasNoPermissions()"
          [hasResults]="!hasNoFilteredPermissions()"
          emptyMessage="No permissions found"
          [emptyHint]="'Call setAvailableOptions() to configure permissions'"
          noResultsMessage="No permissions match your filter"
        >
          @if (hasAnyGroups()) {
            @if (groupedPermissions().pinned.length) {
              <ndt-list-group
                name="Pinned"
                [count]="groupedPermissions().pinned.length"
                [collapsed]="isCollapsed('Pinned')"
                (collapsedChange)="setCollapsed('Pinned', $event)"
              >
                @for (
                  permission of groupedPermissions().pinned;
                  track permission.id
                ) {
                  <ng-container
                    *ngTemplateOutlet="
                      permissionItem;
                      context: { $implicit: permission }
                    "
                  />
                }
              </ndt-list-group>
            }
            @for (group of groupedPermissions().groups; track group.name) {
              <ndt-list-group
                [name]="group.name"
                [count]="group.items.length"
                [collapsed]="isCollapsed(group.name)"
                (collapsedChange)="setCollapsed(group.name, $event)"
              >
                @for (permission of group.items; track permission.id) {
                  <ng-container
                    *ngTemplateOutlet="
                      permissionItem;
                      context: { $implicit: permission }
                    "
                  />
                }
              </ndt-list-group>
            }
            @if (groupedPermissions().ungrouped.length) {
              <ndt-list-group
                name="Other"
                [count]="groupedPermissions().ungrouped.length"
                [collapsed]="isCollapsed('Other')"
                (collapsedChange)="setCollapsed('Other', $event)"
              >
                @for (
                  permission of groupedPermissions().ungrouped;
                  track permission.id
                ) {
                  <ng-container
                    *ngTemplateOutlet="
                      permissionItem;
                      context: { $implicit: permission }
                    "
                  />
                }
              </ndt-list-group>
            }
          } @else {
            @for (permission of flatPermissions(); track permission.id) {
              <ng-container
                *ngTemplateOutlet="
                  permissionItem;
                  context: { $implicit: permission }
                "
              />
            }
          }
        </ndt-list>

        <ng-template #permissionItem let-permission>
          <ndt-list-item
            [title]="permission.name"
            [description]="permission.description"
            [isForced]="permission.isForced"
            [currentValue]="permission.isGranted"
            [originalValue]="permission.originalValue"
            [isPinned]="pinnedIds().has(permission.id)"
            [copyableId]="permission.id"
            (pinToggle)="togglePin(permission.id)"
            [showApply]="hasApplyCallback()"
            [applyState]="getApplyState(permission.id)"
            (applyToSource)="
              onApplyToSource(permission.id, permission.isGranted)
            "
          >
            <ndt-select
              [value]="getPermissionValue(permission)"
              [options]="permissionValueOptions"
              [ariaLabel]="'Override state for ' + permission.name"
              (valueChange)="onPermissionChange(permission.id, $event ?? '')"
              size="small"
            />
          </ndt-list-item>
        </ng-template>
      </div>
    </ndt-toolbar-tool>
  `, isInline: true, styles: [".container{position:relative;display:flex;flex-direction:column;height:100%;padding:0}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: FormsModule }, { kind: "component", type: ToolbarToolComponent, selector: "ndt-toolbar-tool", inputs: ["options", "icon", "toolTitle", "badge"] }, { kind: "component", type: ToolbarToolHeaderComponent, selector: "ndt-tool-header", inputs: ["searchQuery", "activeFilter", "searchPlaceholder", "searchAriaLabel", "filterOptions", "filterAriaLabel"], outputs: ["searchQueryChange", "activeFilterChange"] }, { kind: "component", type: ToolbarSelectComponent, selector: "ndt-select", inputs: ["value", "options", "ariaLabel", "label", "size", "placeholder"], outputs: ["valueChange"] }, { kind: "component", type: ToolbarListComponent, selector: "ndt-list", inputs: ["hasItems", "hasResults", "emptyMessage", "emptyHint", "noResultsMessage"] }, { kind: "component", type: ToolbarListGroupComponent, selector: "ndt-list-group", inputs: ["name", "count", "collapsed"], outputs: ["collapsedChange"] }, { kind: "component", type: ToolbarListItemComponent, selector: "ndt-list-item", inputs: ["title", "description", "isForced", "currentValue", "originalValue", "showApply", "applyState", "isPinned", "copyableId"], outputs: ["pinToggle", "applyToSource"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarPermissionsToolComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-permissions-tool', standalone: true, imports: [
                        NgTemplateOutlet,
                        FormsModule,
                        ToolbarToolComponent,
                        ToolbarToolHeaderComponent,
                        ToolbarSelectComponent,
                        ToolbarListComponent,
                        ToolbarListGroupComponent,
                        ToolbarListItemComponent,
                    ], template: `
    <ndt-toolbar-tool
      [options]="options"
      toolTitle="Permissions"
      icon="lock"
      [badge]="badgeCount()"
    >
      <div class="container">
        <ndt-tool-header
          [(searchQuery)]="searchQuery"
          [activeFilter]="activeFilter()"
          (activeFilterChange)="onFilterChange($event)"
          searchPlaceholder="Search permissions by name or description"
          searchAriaLabel="Search permissions"
          filterAriaLabel="Filter permissions by state"
          [filterOptions]="filterOptions"
        />

        <ndt-list
          [hasItems]="!hasNoPermissions()"
          [hasResults]="!hasNoFilteredPermissions()"
          emptyMessage="No permissions found"
          [emptyHint]="'Call setAvailableOptions() to configure permissions'"
          noResultsMessage="No permissions match your filter"
        >
          @if (hasAnyGroups()) {
            @if (groupedPermissions().pinned.length) {
              <ndt-list-group
                name="Pinned"
                [count]="groupedPermissions().pinned.length"
                [collapsed]="isCollapsed('Pinned')"
                (collapsedChange)="setCollapsed('Pinned', $event)"
              >
                @for (
                  permission of groupedPermissions().pinned;
                  track permission.id
                ) {
                  <ng-container
                    *ngTemplateOutlet="
                      permissionItem;
                      context: { $implicit: permission }
                    "
                  />
                }
              </ndt-list-group>
            }
            @for (group of groupedPermissions().groups; track group.name) {
              <ndt-list-group
                [name]="group.name"
                [count]="group.items.length"
                [collapsed]="isCollapsed(group.name)"
                (collapsedChange)="setCollapsed(group.name, $event)"
              >
                @for (permission of group.items; track permission.id) {
                  <ng-container
                    *ngTemplateOutlet="
                      permissionItem;
                      context: { $implicit: permission }
                    "
                  />
                }
              </ndt-list-group>
            }
            @if (groupedPermissions().ungrouped.length) {
              <ndt-list-group
                name="Other"
                [count]="groupedPermissions().ungrouped.length"
                [collapsed]="isCollapsed('Other')"
                (collapsedChange)="setCollapsed('Other', $event)"
              >
                @for (
                  permission of groupedPermissions().ungrouped;
                  track permission.id
                ) {
                  <ng-container
                    *ngTemplateOutlet="
                      permissionItem;
                      context: { $implicit: permission }
                    "
                  />
                }
              </ndt-list-group>
            }
          } @else {
            @for (permission of flatPermissions(); track permission.id) {
              <ng-container
                *ngTemplateOutlet="
                  permissionItem;
                  context: { $implicit: permission }
                "
              />
            }
          }
        </ndt-list>

        <ng-template #permissionItem let-permission>
          <ndt-list-item
            [title]="permission.name"
            [description]="permission.description"
            [isForced]="permission.isForced"
            [currentValue]="permission.isGranted"
            [originalValue]="permission.originalValue"
            [isPinned]="pinnedIds().has(permission.id)"
            [copyableId]="permission.id"
            (pinToggle)="togglePin(permission.id)"
            [showApply]="hasApplyCallback()"
            [applyState]="getApplyState(permission.id)"
            (applyToSource)="
              onApplyToSource(permission.id, permission.isGranted)
            "
          >
            <ndt-select
              [value]="getPermissionValue(permission)"
              [options]="permissionValueOptions"
              [ariaLabel]="'Override state for ' + permission.name"
              (valueChange)="onPermissionChange(permission.id, $event ?? '')"
              size="small"
            />
          </ndt-list-item>
        </ng-template>
      </div>
    </ndt-toolbar-tool>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".container{position:relative;display:flex;flex-direction:column;height:100%;padding:0}\n"] }]
        }], ctorParameters: () => [] });

/**
 * Internal service for managing presets state.
 * Handles CRUD operations, captures current toolbar config, and applies presets.
 */
class ToolbarInternalPresetsService {
    constructor() {
        this.STORAGE_KEY = 'presets';
        this.storageService = inject(ToolbarStorageService);
        // Inject all other tool internal services (for reading/writing state)
        this.featureFlagsService = inject(ToolbarInternalFeatureFlagService);
        this.permissionsService = inject(ToolbarInternalPermissionsService);
        this.appFeaturesService = inject(ToolbarInternalAppFeaturesService);
        this.i18nService = inject(ToolbarInternalI18nService);
        this.presetsSubject = new BehaviorSubject([]);
        this.presets$ = this.presetsSubject.asObservable();
        this.presets = toSignal(this.presets$, { initialValue: [] });
        this.loadPresets();
    }
    /**
     * Capture current toolbar state as a new preset
     */
    saveCurrentAsPreset(name, description, categoryOptions) {
        const preset = {
            id: this.generateId(),
            name,
            description,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            config: this.captureCurrentConfig(categoryOptions),
        };
        const presets = [...this.presetsSubject.value, preset];
        this.presetsSubject.next(presets);
        this.storageService.set(this.STORAGE_KEY, presets);
        return preset;
    }
    /**
     * Apply a preset to all tools (THIS IS THE KEY METHOD)
     */
    async applyPreset(presetId) {
        const preset = this.presetsSubject.value.find((p) => p.id === presetId);
        if (!preset)
            return;
        // Apply to each tool's internal service
        this.featureFlagsService.applyPresetFlags(preset.config.featureFlags);
        this.permissionsService.applyPresetPermissions(preset.config.permissions);
        this.appFeaturesService.applyForcedState(preset.config.appFeatures);
        if (preset.config.i18n) {
            this.i18nService.applyPresetI18n(preset.config.i18n);
        }
    }
    /**
     * Update an existing preset with current toolbar state
     */
    updatePreset(presetId) {
        const presets = this.presetsSubject.value.map((preset) => {
            if (preset.id === presetId) {
                return {
                    ...preset,
                    updatedAt: new Date().toISOString(),
                    config: this.captureCurrentConfig(),
                };
            }
            return preset;
        });
        this.presetsSubject.next(presets);
        this.storageService.set(this.STORAGE_KEY, presets);
    }
    /**
     * Delete a preset
     */
    deletePreset(presetId) {
        const presets = this.presetsSubject.value.filter((p) => p.id !== presetId);
        this.presetsSubject.next(presets);
        this.storageService.set(this.STORAGE_KEY, presets);
    }
    /**
     * Add a preset (used for import)
     */
    addPreset(preset) {
        // Generate new ID to avoid conflicts
        const newPreset = {
            ...preset,
            id: this.generateId(),
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
        };
        const presets = [...this.presetsSubject.value, newPreset];
        this.presetsSubject.next(presets);
        this.storageService.set(this.STORAGE_KEY, presets);
        return newPreset;
    }
    /**
     * Get a preset by ID
     */
    getPresetById(presetId) {
        return this.presetsSubject.value.find((p) => p.id === presetId);
    }
    /**
     * Toggle favorite status for a preset
     */
    toggleFavorite(presetId) {
        const presets = this.presetsSubject.value.map((p) => p.id === presetId ? { ...p, isFavorite: !p.isFavorite } : p);
        this.presetsSubject.next(presets);
        this.storageService.set(this.STORAGE_KEY, presets);
    }
    /**
     * Apply a preset with partial options (only selected categories)
     */
    async partialApplyPreset(presetId, options) {
        const preset = this.presetsSubject.value.find((p) => p.id === presetId);
        if (!preset)
            return;
        if (options.applyFeatureFlags) {
            this.featureFlagsService.applyPresetFlags(preset.config.featureFlags);
        }
        if (options.applyPermissions) {
            this.permissionsService.applyPresetPermissions(preset.config.permissions);
        }
        if (options.applyAppFeatures) {
            this.appFeaturesService.applyForcedState(preset.config.appFeatures);
        }
        if (options.applyI18n && preset.config.i18n) {
            this.i18nService.applyPresetI18n(preset.config.i18n);
        }
    }
    /**
     * Update only the metadata (name, description) of a preset without changing config
     */
    updatePresetMetadata(presetId, name, description) {
        const presets = this.presetsSubject.value.map((preset) => {
            if (preset.id === presetId) {
                return {
                    ...preset,
                    name,
                    description,
                    updatedAt: new Date().toISOString(),
                };
            }
            return preset;
        });
        this.presetsSubject.next(presets);
        this.storageService.set(this.STORAGE_KEY, presets);
    }
    /**
     * Capture current configuration from all tools
     */
    captureCurrentConfig(categoryOptions) {
        // Default to including all categories if not specified
        const options = {
            includeFeatureFlags: categoryOptions?.includeFeatureFlags ?? true,
            includePermissions: categoryOptions?.includePermissions ?? true,
            includeAppFeatures: categoryOptions?.includeAppFeatures ?? true,
            includeI18n: categoryOptions?.includeI18n ?? true,
        };
        // Get current forced states
        const currentFlags = this.featureFlagsService.getCurrentForcedState();
        const currentPerms = this.permissionsService.getCurrentForcedState();
        const currentFeatures = this.appFeaturesService.getCurrentForcedState();
        // Filter by selected IDs if provided
        const filterById = (ids, selected) => selected && selected.length > 0 ? ids.filter((id) => selected.includes(id)) : ids;
        return {
            featureFlags: options.includeFeatureFlags
                ? {
                    enabled: filterById(currentFlags.enabled, categoryOptions?.selectedFlagIds),
                    disabled: filterById(currentFlags.disabled, categoryOptions?.selectedFlagIds),
                }
                : { enabled: [], disabled: [] },
            permissions: options.includePermissions
                ? {
                    granted: filterById(currentPerms.granted, categoryOptions?.selectedPermissionIds),
                    denied: filterById(currentPerms.denied, categoryOptions?.selectedPermissionIds),
                }
                : { granted: [], denied: [] },
            appFeatures: options.includeAppFeatures
                ? {
                    enabled: filterById(currentFeatures.enabled, categoryOptions?.selectedFeatureIds),
                    disabled: filterById(currentFeatures.disabled, categoryOptions?.selectedFeatureIds),
                }
                : { enabled: [], disabled: [] },
            i18n: options.includeI18n
                ? (() => {
                    const i18nState = this.i18nService.getCurrentI18nState();
                    return {
                        locale: i18nState.locale?.id ?? null,
                        timezone: i18nState.timezone?.id ?? null,
                        currency: i18nState.currency?.code ?? null,
                        unitSystem: i18nState.unitSystem ?? null,
                        pseudoLocEnabled: i18nState.pseudoLocEnabled,
                        rtlEnabled: i18nState.rtlEnabled,
                    };
                })()
                : undefined,
        };
    }
    /**
     * Load presets from localStorage
     */
    loadPresets() {
        try {
            const saved = this.storageService.get(this.STORAGE_KEY);
            if (saved && Array.isArray(saved)) {
                this.presetsSubject.next(saved);
            }
        }
        catch (error) {
            console.error('Failed to load presets from localStorage:', error);
        }
    }
    /**
     * Generate unique preset ID
     */
    generateId() {
        return `preset-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalPresetsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalPresetsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarInternalPresetsService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

class ToolbarPresetsToolComponent {
    onDocumentClick() {
        this.openMenuId.set(null);
    }
    constructor() {
        // Injects
        this.presetsService = inject(ToolbarInternalPresetsService);
        this.featureFlagsService = inject(ToolbarInternalFeatureFlagService);
        this.permissionsService = inject(ToolbarInternalPermissionsService);
        this.appFeaturesService = inject(ToolbarInternalAppFeaturesService);
        this.state = inject(ToolbarStateService);
        // View state signals
        this.viewMode = signal('list');
        this.searchQuery = signal('');
        this.expandedPresetId = signal(null);
        this.openMenuId = signal(null);
        // Create form signals
        this.presetName = signal('');
        this.presetDescription = signal('');
        this.includeFeatureFlags = signal(true);
        this.includePermissions = signal(true);
        this.includeAppFeatures = signal(true);
        this.selectedFlagIds = signal(new Set());
        this.selectedPermissionIds = signal(new Set());
        this.selectedFeatureIds = signal(new Set());
        // Edit mode signals
        this.editingPresetId = signal(null);
        this.editName = signal('');
        this.editDescription = signal('');
        // Import mode signals
        this.importJson = signal('');
        this.importError = signal(null);
        this.isDragOver = signal(false);
        // Apply mode signals
        this.applyingPresetId = signal(null);
        this.applyFeatureFlags = signal(true);
        this.applyPermissions = signal(true);
        this.applyAppFeatures = signal(true);
        // Delete confirmation signals
        this.deletePresetId = signal(null);
        // Toast signals
        this.toastMessage = signal(null);
        this.toastType = signal('success');
        // Validation signals
        this.nameError = signal(null);
        // Auto-dismiss toast effect
        this.toastTimeout = null;
        // Computed values
        this.presets = this.presetsService.presets;
        this.filteredPresets = computed(() => {
            const query = this.searchQuery().toLowerCase();
            return this.presets().filter((preset) => preset.name.toLowerCase().includes(query) ||
                preset.description?.toLowerCase().includes(query));
        });
        this.sortedPresets = computed(() => {
            const presets = this.filteredPresets();
            return [...presets].sort((a, b) => {
                if (a.isFavorite && !b.isFavorite)
                    return -1;
                if (!a.isFavorite && b.isFavorite)
                    return 1;
                return 0;
            });
        });
        this.hasNoPresets = computed(() => this.presets().length === 0);
        this.hasNoFilteredPresets = computed(() => this.filteredPresets().length === 0);
        this.editingPreset = computed(() => {
            const id = this.editingPresetId();
            if (!id)
                return null;
            return this.presets().find((p) => p.id === id) || null;
        });
        this.applyingPreset = computed(() => {
            const id = this.applyingPresetId();
            if (!id)
                return null;
            return this.presets().find((p) => p.id === id) || null;
        });
        this.deletePresetName = computed(() => {
            const id = this.deletePresetId();
            if (!id)
                return '';
            const preset = this.presets().find((p) => p.id === id);
            return preset?.name || '';
        });
        // Tool availability (based on config)
        this.isFeatureFlagsEnabled = computed(() => this.state.config().showFeatureFlagsTool ?? true);
        this.isPermissionsEnabled = computed(() => this.state.config().showPermissionsTool ?? true);
        this.isAppFeaturesEnabled = computed(() => this.state.config().showAppFeaturesTool ?? true);
        // Forced items details
        this.forcedFlags = computed(() => {
            return this.featureFlagsService.flags().filter((flag) => flag.isForced);
        });
        this.forcedPermissions = computed(() => {
            return this.permissionsService.permissions().filter((perm) => perm.isForced);
        });
        this.forcedAppFeatures = computed(() => {
            return this.appFeaturesService.features().filter((feat) => feat.isForced);
        });
        // Other properties
        this.options = {
            title: 'Presets',
            description: 'Save and load toolbar configurations',
            isClosable: true,
            size: 'tall',
            id: 'ndt-presets',
        };
        effect(() => {
            const message = this.toastMessage();
            if (message) {
                if (this.toastTimeout) {
                    clearTimeout(this.toastTimeout);
                }
                this.toastTimeout = setTimeout(() => {
                    this.toastMessage.set(null);
                }, 3000);
            }
        });
    }
    // Toast helper
    showToast(message, type = 'success') {
        this.toastMessage.set(message);
        this.toastType.set(type);
    }
    // View mode switching
    onSearchChange(query) {
        this.searchQuery.set(query);
    }
    onToggleExpand(presetId) {
        this.expandedPresetId.update((current) => current === presetId ? null : presetId);
    }
    onToggleMenu(presetId) {
        this.openMenuId.update((current) => current === presetId ? null : presetId);
    }
    onSwitchToListMode() {
        this.viewMode.set('list');
        this.nameError.set(null);
        this.importError.set(null);
        this.deletePresetId.set(null);
    }
    onSwitchToCreateMode() {
        this.viewMode.set('create');
        this.presetName.set('');
        this.presetDescription.set('');
        this.nameError.set(null);
        // Reset checkboxes - only enable categories that have forced items
        this.includeFeatureFlags.set(this.getCurrentFlagsCount() > 0);
        this.includePermissions.set(this.getCurrentPermissionsCount() > 0);
        this.includeAppFeatures.set(this.getCurrentAppFeaturesCount() > 0);
        // Initialize selected items - select all by default
        this.selectedFlagIds.set(new Set(this.forcedFlags().map((f) => f.id)));
        this.selectedPermissionIds.set(new Set(this.forcedPermissions().map((p) => p.id)));
        this.selectedFeatureIds.set(new Set(this.forcedAppFeatures().map((f) => f.id)));
    }
    onSwitchToImportMode() {
        this.viewMode.set('import');
        this.importJson.set('');
        this.importError.set(null);
        this.isDragOver.set(false);
    }
    // Create preset
    onPresetNameChange(value) {
        this.presetName.set(value);
        if (value.trim()) {
            this.nameError.set(null);
        }
    }
    onSavePreset(event) {
        event.preventDefault();
        const name = this.presetName().trim();
        if (!name) {
            this.nameError.set('Name is required');
            return;
        }
        // Check for duplicate names
        const existingPreset = this.presets().find((p) => p.name.toLowerCase() === name.toLowerCase());
        if (existingPreset) {
            this.nameError.set('A preset with this name already exists');
            return;
        }
        this.presetsService.saveCurrentAsPreset(name, this.presetDescription(), {
            includeFeatureFlags: this.includeFeatureFlags(),
            includePermissions: this.includePermissions(),
            includeAppFeatures: this.includeAppFeatures(),
            selectedFlagIds: Array.from(this.selectedFlagIds()),
            selectedPermissionIds: Array.from(this.selectedPermissionIds()),
            selectedFeatureIds: Array.from(this.selectedFeatureIds()),
        });
        this.showToast('Preset created successfully');
        this.onSwitchToListMode();
    }
    // Edit preset
    onStartEdit(presetId) {
        const preset = this.presets().find((p) => p.id === presetId);
        if (!preset)
            return;
        this.editingPresetId.set(presetId);
        this.editName.set(preset.name);
        this.editDescription.set(preset.description || '');
        this.nameError.set(null);
        this.viewMode.set('edit');
    }
    onEditNameChange(value) {
        this.editName.set(value);
        if (value.trim()) {
            this.nameError.set(null);
        }
    }
    onSaveEdit(event) {
        event.preventDefault();
        const name = this.editName().trim();
        const presetId = this.editingPresetId();
        if (!name) {
            this.nameError.set('Name is required');
            return;
        }
        if (!presetId)
            return;
        // Check for duplicate names (excluding current preset)
        const existingPreset = this.presets().find((p) => p.id !== presetId && p.name.toLowerCase() === name.toLowerCase());
        if (existingPreset) {
            this.nameError.set('A preset with this name already exists');
            return;
        }
        this.presetsService.updatePresetMetadata(presetId, name, this.editDescription());
        this.showToast('Preset updated successfully');
        this.onSwitchToListMode();
    }
    onReplaceConfig() {
        const presetId = this.editingPresetId();
        if (!presetId)
            return;
        this.presetsService.updatePreset(presetId);
        this.showToast('Configuration replaced with current state');
    }
    // Import preset
    onDragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragOver.set(true);
    }
    onDragLeave(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragOver.set(false);
    }
    onFileDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragOver.set(false);
        const files = event.dataTransfer?.files;
        if (files && files.length > 0) {
            this.processFile(files[0]);
        }
    }
    onFileSelect(event) {
        const input = event.target;
        if (input.files && input.files.length > 0) {
            this.processFile(input.files[0]);
        }
    }
    processFile(file) {
        if (!file.name.endsWith('.json')) {
            this.importError.set('Please select a .json file');
            return;
        }
        const reader = new FileReader();
        reader.onload = (e) => {
            const content = e.target?.result;
            this.importJson.set(content);
            this.importError.set(null);
        };
        reader.onerror = () => {
            this.importError.set('Failed to read file');
        };
        reader.readAsText(file);
    }
    onImportJsonChange(event) {
        const textarea = event.target;
        this.importJson.set(textarea.value);
        this.importError.set(null);
    }
    onImportPreset() {
        const json = this.importJson().trim();
        if (!json) {
            this.importError.set('Please provide JSON content');
            return;
        }
        try {
            const parsed = JSON.parse(json);
            // Validate required fields
            if (!parsed.name) {
                this.importError.set('Preset must have a name');
                return;
            }
            if (!parsed.config) {
                this.importError.set('Preset must have a config object');
                return;
            }
            this.presetsService.addPreset(parsed);
            this.showToast('Preset imported successfully');
            this.onSwitchToListMode();
        }
        catch {
            this.importError.set('Invalid JSON format');
        }
    }
    // Apply preset (partial)
    onStartApply(presetId) {
        this.applyingPresetId.set(presetId);
        this.applyFeatureFlags.set(true);
        this.applyPermissions.set(true);
        this.applyAppFeatures.set(true);
        this.viewMode.set('apply');
    }
    onConfirmPartialApply() {
        const presetId = this.applyingPresetId();
        if (!presetId)
            return;
        this.presetsService.partialApplyPreset(presetId, {
            applyFeatureFlags: this.applyFeatureFlags(),
            applyPermissions: this.applyPermissions(),
            applyAppFeatures: this.applyAppFeatures(),
        });
        this.showToast('Preset applied successfully');
        this.onSwitchToListMode();
    }
    // Update preset (with current state)
    onUpdatePreset(presetId) {
        this.presetsService.updatePreset(presetId);
        this.showToast('Preset updated with current state');
    }
    // Export preset
    onExportPreset(presetId) {
        const preset = this.presets().find((p) => p.id === presetId);
        if (!preset)
            return;
        const json = JSON.stringify(preset, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `preset-${preset.name.toLowerCase().replace(/\s+/g, '-')}.json`;
        link.click();
        URL.revokeObjectURL(url);
        this.showToast('Preset exported');
    }
    // Delete preset
    onDeletePreset(presetId) {
        this.deletePresetId.set(presetId);
        this.viewMode.set('delete');
    }
    onConfirmDelete() {
        const presetId = this.deletePresetId();
        if (presetId) {
            this.presetsService.deletePreset(presetId);
            this.showToast('Preset deleted');
        }
        this.deletePresetId.set(null);
        this.viewMode.set('list');
    }
    // Favorites
    onToggleFavorite(presetId) {
        this.presetsService.toggleFavorite(presetId);
    }
    // Protected methods
    getCurrentFlagsCount() {
        const state = this.featureFlagsService.getCurrentForcedState();
        return state.enabled.length + state.disabled.length;
    }
    getCurrentPermissionsCount() {
        const state = this.permissionsService.getCurrentForcedState();
        return state.granted.length + state.denied.length;
    }
    getCurrentAppFeaturesCount() {
        const state = this.appFeaturesService.getCurrentForcedState();
        return state.enabled.length + state.disabled.length;
    }
    formatDate(isoString) {
        return new Date(isoString).toLocaleDateString();
    }
    getPresetTooltip(preset) {
        const lines = [];
        // Feature Flags
        const flagsEnabled = preset.config.featureFlags.enabled;
        const flagsDisabled = preset.config.featureFlags.disabled;
        if (flagsEnabled.length > 0 || flagsDisabled.length > 0) {
            lines.push('Feature Flags:');
            flagsEnabled.forEach(id => lines.push(`  ✓ ${id}: ON`));
            flagsDisabled.forEach(id => lines.push(`  ✗ ${id}: OFF`));
        }
        // Permissions
        const permsGranted = preset.config.permissions.granted;
        const permsDenied = preset.config.permissions.denied;
        if (permsGranted.length > 0 || permsDenied.length > 0) {
            if (lines.length > 0)
                lines.push('');
            lines.push('Permissions:');
            permsGranted.forEach(id => lines.push(`  ✓ ${id}: GRANTED`));
            permsDenied.forEach(id => lines.push(`  ✗ ${id}: DENIED`));
        }
        // App Features
        const featuresEnabled = preset.config.appFeatures.enabled;
        const featuresDisabled = preset.config.appFeatures.disabled;
        if (featuresEnabled.length > 0 || featuresDisabled.length > 0) {
            if (lines.length > 0)
                lines.push('');
            lines.push('App Features:');
            featuresEnabled.forEach(id => lines.push(`  ✓ ${id}: ON`));
            featuresDisabled.forEach(id => lines.push(`  ✗ ${id}: OFF`));
        }
        return lines.length > 0 ? lines.join('\n') : 'No configuration';
    }
    toggleItemSelection(signal, itemId) {
        const current = new Set(signal());
        if (current.has(itemId)) {
            current.delete(itemId);
        }
        else {
            current.add(itemId);
        }
        signal.set(current);
    }
    isItemSelected(selectedSet, itemId) {
        return selectedSet.has(itemId);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarPresetsToolComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarPresetsToolComponent, isStandalone: true, selector: "ndt-presets-tool", host: { listeners: { "document:click": "onDocumentClick()" } }, ngImport: i0, template: `
    <ndt-toolbar-tool [options]="options" toolTitle="Presets" icon="layout">
      <div class="container">
        <!-- Toast Notification -->
        @if (toastMessage()) {
        <div class="toast" [class.toast--success]="toastType() === 'success'" [class.toast--error]="toastType() === 'error'">
          <span class="toast__icon">{{ toastType() === 'success' ? '✓' : '✕' }}</span>
          <span class="toast__message">{{ toastMessage() }}</span>
        </div>
        }


        <!-- Mode Toggle -->
        @if (!hasNoPresets() || viewMode() !== 'list') {
        <div class="tool-header">
          @if (viewMode() === 'list') {
          <ndt-input
            [value]="searchQuery()"
            (valueChange)="onSearchChange($event)"
            placeholder="Search presets..."
            [ariaLabel]="'Search presets'"
          />
          <ndt-button
            (click)="onSwitchToImportMode()"
            [ariaLabel]="'Import preset'"
          >
            Import
          </ndt-button>
          <ndt-button
            (click)="onSwitchToCreateMode()"
            [ariaLabel]="'Create new preset'"
          >
            New
          </ndt-button>
          } @else {
          <ndt-button
            (click)="onSwitchToListMode()"
            [ariaLabel]="'Back to list'"
          >
            ← Back
          </ndt-button>
          }
        </div>
        }

        <!-- Create Form -->
        @if (viewMode() === 'create') {
        <form (submit)="onSavePreset($event)" class="preset-form">
          <h3 class="form-title">Create Preset</h3>
          <p class="form-hint">This will save the current forced values from other tools. Only items you've explicitly set will be included.</p>
          <div class="form-field">
            <ndt-input
              label="Preset Name *"
              [value]="presetName()"
              (valueChange)="onPresetNameChange($event)"
              placeholder="e.g., Admin User - Full Access"
              [ariaLabel]="'Preset name'"
            />
            @if (nameError()) {
            <span class="field-error">{{ nameError() }}</span>
            }
          </div>
          <ndt-input
            label="Description (optional)"
            [value]="presetDescription()"
            (valueChange)="presetDescription.set($event)"
            placeholder="Brief description of this preset"
            [ariaLabel]="'Preset description'"
          />

          <!-- Category selection checkboxes -->
          <div class="preset-summary">
            <h4>Select what to include:</h4>

            @if (isFeatureFlagsEnabled()) {
            <div class="category-section">
              <label class="checkbox-option">
                <input
                  type="checkbox"
                  [checked]="includeFeatureFlags()"
                  (change)="includeFeatureFlags.set(!includeFeatureFlags())"
                  [disabled]="getCurrentFlagsCount() === 0"
                />
                <span>Feature Flags ({{ getCurrentFlagsCount() }} forced)</span>
              </label>
              @if (forcedFlags().length > 0) {
              <ul class="forced-items-list">
                @for (flag of forcedFlags(); track flag.id) {
                <li>
                  <label class="item-checkbox">
                    <input
                      type="checkbox"
                      [checked]="isItemSelected(selectedFlagIds(), flag.id)"
                      (change)="toggleItemSelection(selectedFlagIds, flag.id)"
                    />
                    <span class="item-name">{{ flag.name }}</span>
                    <span class="item-status" [class.enabled]="flag.isEnabled" [class.disabled]="!flag.isEnabled">
                      {{ flag.isEnabled ? 'ON' : 'OFF' }}
                    </span>
                  </label>
                </li>
                }
              </ul>
              }
            </div>
            }

            @if (isPermissionsEnabled()) {
            <div class="category-section">
              <label class="checkbox-option">
                <input
                  type="checkbox"
                  [checked]="includePermissions()"
                  (change)="includePermissions.set(!includePermissions())"
                  [disabled]="getCurrentPermissionsCount() === 0"
                />
                <span>Permissions ({{ getCurrentPermissionsCount() }} forced)</span>
              </label>
              @if (forcedPermissions().length > 0) {
              <ul class="forced-items-list">
                @for (perm of forcedPermissions(); track perm.id) {
                <li>
                  <label class="item-checkbox">
                    <input
                      type="checkbox"
                      [checked]="isItemSelected(selectedPermissionIds(), perm.id)"
                      (change)="toggleItemSelection(selectedPermissionIds, perm.id)"
                    />
                    <span class="item-name">{{ perm.name }}</span>
                    <span class="item-status" [class.enabled]="perm.isGranted" [class.disabled]="!perm.isGranted">
                      {{ perm.isGranted ? 'GRANTED' : 'DENIED' }}
                    </span>
                  </label>
                </li>
                }
              </ul>
              }
            </div>
            }

            @if (isAppFeaturesEnabled()) {
            <div class="category-section">
              <label class="checkbox-option">
                <input
                  type="checkbox"
                  [checked]="includeAppFeatures()"
                  (change)="includeAppFeatures.set(!includeAppFeatures())"
                  [disabled]="getCurrentAppFeaturesCount() === 0"
                />
                <span>App Features ({{ getCurrentAppFeaturesCount() }} forced)</span>
              </label>
              @if (forcedAppFeatures().length > 0) {
              <ul class="forced-items-list">
                @for (feat of forcedAppFeatures(); track feat.id) {
                <li>
                  <label class="item-checkbox">
                    <input
                      type="checkbox"
                      [checked]="isItemSelected(selectedFeatureIds(), feat.id)"
                      (change)="toggleItemSelection(selectedFeatureIds, feat.id)"
                    />
                    <span class="item-name">{{ feat.name }}</span>
                    <span class="item-status" [class.enabled]="feat.isEnabled" [class.disabled]="!feat.isEnabled">
                      {{ feat.isEnabled ? 'ON' : 'OFF' }}
                    </span>
                  </label>
                </li>
                }
              </ul>
              }
            </div>
            }

          </div>

          <div class="form-actions">
            <ndt-button type="button" (click)="onSwitchToListMode()">Cancel</ndt-button>
            <ndt-button type="submit">Save Preset</ndt-button>
          </div>
        </form>
        }

        <!-- Edit Form -->
        @if (viewMode() === 'edit') {
        <form (submit)="onSaveEdit($event)" class="preset-form">
          <h3 class="form-title">Edit Preset</h3>
          <div class="form-field">
            <ndt-input
              label="Preset Name *"
              [value]="editName()"
              (valueChange)="onEditNameChange($event)"
              placeholder="e.g., Admin User - Full Access"
              [ariaLabel]="'Preset name'"
            />
            @if (nameError()) {
            <span class="field-error">{{ nameError() }}</span>
            }
          </div>
          <ndt-input
            label="Description (optional)"
            [value]="editDescription()"
            (valueChange)="editDescription.set($event)"
            placeholder="Brief description of this preset"
            [ariaLabel]="'Preset description'"
          />

          <!-- Show saved configuration read-only -->
          @if (editingPreset()) {
          <div class="config-preview">
            <h4>Saved Configuration</h4>
            @if (editingPreset()!.config.featureFlags.enabled.length > 0 || editingPreset()!.config.featureFlags.disabled.length > 0) {
            <div class="config-category">
              <span class="config-category__title">Feature Flags ({{ editingPreset()!.config.featureFlags.enabled.length + editingPreset()!.config.featureFlags.disabled.length }})</span>
              <div class="config-items">
                @for (id of editingPreset()!.config.featureFlags.enabled; track id) {
                <span class="config-item config-item--on">{{ id }}: ON</span>
                }
                @for (id of editingPreset()!.config.featureFlags.disabled; track id) {
                <span class="config-item config-item--off">{{ id }}: OFF</span>
                }
              </div>
            </div>
            }
            @if (editingPreset()!.config.permissions.granted.length > 0 || editingPreset()!.config.permissions.denied.length > 0) {
            <div class="config-category">
              <span class="config-category__title">Permissions ({{ editingPreset()!.config.permissions.granted.length + editingPreset()!.config.permissions.denied.length }})</span>
              <div class="config-items">
                @for (id of editingPreset()!.config.permissions.granted; track id) {
                <span class="config-item config-item--on">{{ id }}: GRANTED</span>
                }
                @for (id of editingPreset()!.config.permissions.denied; track id) {
                <span class="config-item config-item--off">{{ id }}: DENIED</span>
                }
              </div>
            </div>
            }
            @if (editingPreset()!.config.appFeatures.enabled.length > 0 || editingPreset()!.config.appFeatures.disabled.length > 0) {
            <div class="config-category">
              <span class="config-category__title">App Features ({{ editingPreset()!.config.appFeatures.enabled.length + editingPreset()!.config.appFeatures.disabled.length }})</span>
              <div class="config-items">
                @for (id of editingPreset()!.config.appFeatures.enabled; track id) {
                <span class="config-item config-item--on">{{ id }}: ON</span>
                }
                @for (id of editingPreset()!.config.appFeatures.disabled; track id) {
                <span class="config-item config-item--off">{{ id }}: OFF</span>
                }
              </div>
            </div>
            }
            <button type="button" class="replace-config-button" (click)="onReplaceConfig()">
              ↻ Replace with current toolbar state
            </button>
          </div>
          }

          <div class="form-actions">
            <ndt-button type="button" (click)="onSwitchToListMode()">Cancel</ndt-button>
            <ndt-button type="submit">Save Changes</ndt-button>
          </div>
        </form>
        }

        <!-- Import View -->
        @if (viewMode() === 'import') {
        <div class="import-view">
          <h3 class="form-title">Import Preset</h3>

          <!-- File Drop Zone -->
          <div
            class="drop-zone"
            [class.drop-zone--active]="isDragOver()"
            (dragover)="onDragOver($event)"
            (dragleave)="onDragLeave($event)"
            (drop)="onFileDrop($event)"
            (click)="fileInput.click()"
            (keydown.enter)="fileInput.click()"
            (keydown.space)="fileInput.click()"
            tabindex="0"
            role="button"
          >
            <input
              #fileInput
              type="file"
              accept=".json"
              (change)="onFileSelect($event)"
              hidden
            />
            <span class="drop-zone__icon">📁</span>
            <span class="drop-zone__text">Drop a .json file here</span>
            <span class="drop-zone__hint">or click to browse</span>
          </div>

          <div class="divider">
            <span>or paste JSON</span>
          </div>

          <!-- JSON Textarea -->
          <textarea
            class="json-textarea"
            [value]="importJson()"
            (input)="onImportJsonChange($event)"
            placeholder='{"name": "...", "config": { ... }}'
          ></textarea>

          @if (importError()) {
          <span class="field-error">{{ importError() }}</span>
          }

          <div class="form-actions">
            <ndt-button type="button" (click)="onSwitchToListMode()">Cancel</ndt-button>
            <ndt-button (click)="onImportPreset()">Import Preset</ndt-button>
          </div>
        </div>
        }

        <!-- Partial Apply View -->
        @if (viewMode() === 'apply') {
        <div class="apply-view">
          <h3 class="form-title">Apply: {{ applyingPreset()?.name }}</h3>
          <p class="apply-description">Select which parts to apply</p>

          @if (applyingPreset()) {
          <div class="apply-categories">
            <!-- Feature Flags -->
            @if (applyingPreset()!.config.featureFlags.enabled.length > 0 || applyingPreset()!.config.featureFlags.disabled.length > 0) {
            <div class="apply-category" [class.apply-category--disabled]="!applyFeatureFlags()">
              <label class="apply-category__header">
                <input
                  type="checkbox"
                  [checked]="applyFeatureFlags()"
                  (change)="applyFeatureFlags.set(!applyFeatureFlags())"
                />
                <span>Feature Flags ({{ applyingPreset()!.config.featureFlags.enabled.length + applyingPreset()!.config.featureFlags.disabled.length }})</span>
              </label>
              @if (applyFeatureFlags()) {
              <div class="apply-diff">
                @for (id of applyingPreset()!.config.featureFlags.enabled; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--on">ON</span>
                </div>
                }
                @for (id of applyingPreset()!.config.featureFlags.disabled; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--off">OFF</span>
                </div>
                }
              </div>
              }
            </div>
            }

            <!-- Permissions -->
            @if (applyingPreset()!.config.permissions.granted.length > 0 || applyingPreset()!.config.permissions.denied.length > 0) {
            <div class="apply-category" [class.apply-category--disabled]="!applyPermissions()">
              <label class="apply-category__header">
                <input
                  type="checkbox"
                  [checked]="applyPermissions()"
                  (change)="applyPermissions.set(!applyPermissions())"
                />
                <span>Permissions ({{ applyingPreset()!.config.permissions.granted.length + applyingPreset()!.config.permissions.denied.length }})</span>
              </label>
              @if (applyPermissions()) {
              <div class="apply-diff">
                @for (id of applyingPreset()!.config.permissions.granted; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--on">GRANTED</span>
                </div>
                }
                @for (id of applyingPreset()!.config.permissions.denied; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--off">DENIED</span>
                </div>
                }
              </div>
              }
            </div>
            }

            <!-- App Features -->
            @if (applyingPreset()!.config.appFeatures.enabled.length > 0 || applyingPreset()!.config.appFeatures.disabled.length > 0) {
            <div class="apply-category" [class.apply-category--disabled]="!applyAppFeatures()">
              <label class="apply-category__header">
                <input
                  type="checkbox"
                  [checked]="applyAppFeatures()"
                  (change)="applyAppFeatures.set(!applyAppFeatures())"
                />
                <span>App Features ({{ applyingPreset()!.config.appFeatures.enabled.length + applyingPreset()!.config.appFeatures.disabled.length }})</span>
              </label>
              @if (applyAppFeatures()) {
              <div class="apply-diff">
                @for (id of applyingPreset()!.config.appFeatures.enabled; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--on">ON</span>
                </div>
                }
                @for (id of applyingPreset()!.config.appFeatures.disabled; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--off">OFF</span>
                </div>
                }
              </div>
              }
            </div>
            }

          </div>
          }

          <div class="form-actions">
            <ndt-button type="button" (click)="onSwitchToListMode()">Cancel</ndt-button>
            <ndt-button (click)="onConfirmPartialApply()">Apply Selected</ndt-button>
          </div>
        </div>
        }

        <!-- Delete Confirmation View -->
        @if (viewMode() === 'delete') {
        <div class="delete-view">
          <div class="delete-view__content">
            <div class="delete-view__icon">🗑️</div>
            <h3 class="delete-view__title">Delete "{{ deletePresetName() }}"?</h3>
            <p class="delete-view__description">
              This preset will be permanently removed.
              This action cannot be undone.
            </p>
          </div>
          <div class="form-actions">
            <ndt-button type="button" (click)="onSwitchToListMode()">← Back</ndt-button>
            <button class="delete-button" (click)="onConfirmDelete()">Delete Preset</button>
          </div>
        </div>
        }

        <!-- Empty State -->
        @if (viewMode() === 'list' && hasNoPresets()) {
        <div class="empty">
          <p>No presets saved yet</p>
          <p class="hint">
            Save the current toolbar configuration as a preset for quick access
          </p>
          <ndt-button (click)="onSwitchToCreateMode()">
            Create Your First Preset
          </ndt-button>
        </div>
        } @else if (viewMode() === 'list' && hasNoFilteredPresets()) {
        <div class="empty">
          <p>No presets match your search</p>
        </div>
        } @else if (viewMode() === 'list') {
        <!-- Preset List -->
        <div class="preset-list">
          @for (preset of sortedPresets(); track preset.id) {
          <div class="preset-card">
            <div class="preset-card__header">
              <button
                class="expand-toggle"
                (click)="onToggleExpand(preset.id); $event.stopPropagation()"
                [attr.aria-label]="expandedPresetId() === preset.id ? 'Collapse details' : 'Expand details'"
              >{{ expandedPresetId() === preset.id ? '▾' : '▸' }}</button>
              <button
                class="favorite-button"
                [class.favorite-button--active]="preset.isFavorite"
                (click)="onToggleFavorite(preset.id); $event.stopPropagation()"
                [attr.aria-label]="preset.isFavorite ? 'Remove from favorites' : 'Add to favorites'"
              >{{ preset.isFavorite ? '★' : '☆' }}</button>
              <span class="preset-card__name">{{ preset.name }}</span>
              @if (preset.isSystem) {<span class="system-badge">SYS</span>}
              <span class="preset-card__spacer"></span>
              <div class="preset-card__actions">
                <button
                  class="more-button"
                  (click)="onToggleMenu(preset.id); $event.stopPropagation()"
                  aria-label="Actions"
                >⋯</button>
              </div>
              @if (openMenuId() === preset.id) {
              <div class="action-menu" role="menu" tabindex="-1" (click)="$event.stopPropagation()" (keydown.escape)="openMenuId.set(null)">
                <button class="action-menu__item" (click)="onStartApply(preset.id); openMenuId.set(null)">
                  <ndt-icon name="refresh" />
                  <span>Apply preset</span>
                </button>
                @if (!preset.isSystem) {
                <button class="action-menu__item" (click)="onStartEdit(preset.id); openMenuId.set(null)">
                  <ndt-icon name="edit" />
                  <span>Edit</span>
                </button>
                <button class="action-menu__item" (click)="onUpdatePreset(preset.id); openMenuId.set(null)">
                  <ndt-icon name="gear" />
                  <span>Update with current values</span>
                </button>
                }
                <button class="action-menu__item" (click)="onExportPreset(preset.id); openMenuId.set(null)">
                  <ndt-icon name="export" />
                  <span>Export as JSON</span>
                </button>
                @if (!preset.isSystem) {
                <button class="action-menu__item action-menu__item--danger" (click)="onDeletePreset(preset.id); openMenuId.set(null)">
                  <ndt-icon name="trash" />
                  <span>Delete</span>
                </button>
                }
              </div>
              }
            </div>
            @if (preset.description) {
            <div class="preset-card__row preset-card__row--meta">
              <span class="preset-card__description">{{ preset.description }}</span>
            </div>
            }
            <div class="preset-card__row preset-card__row--badges">
              @if (preset.config.featureFlags.enabled.length > 0 || preset.config.featureFlags.disabled.length > 0) {
              <span class="badge">{{ preset.config.featureFlags.enabled.length + preset.config.featureFlags.disabled.length }} flags</span>
              }
              @if (preset.config.permissions.granted.length > 0 || preset.config.permissions.denied.length > 0) {
              <span class="badge">{{ preset.config.permissions.granted.length + preset.config.permissions.denied.length }} perms</span>
              }
              @if (preset.config.appFeatures.enabled.length > 0 || preset.config.appFeatures.disabled.length > 0) {
              <span class="badge">{{ preset.config.appFeatures.enabled.length + preset.config.appFeatures.disabled.length }} features</span>
              }
              <span class="preset-card__date">{{ formatDate(preset.updatedAt) }}</span>
            </div>
            @if (expandedPresetId() === preset.id) {
            <div class="preset-card__details">
              @if (preset.config.featureFlags.enabled.length > 0 || preset.config.featureFlags.disabled.length > 0) {
              <div class="details-section">
                <span class="details-section__title">Feature Flags</span>
                <div class="details-section__items">
                  @for (id of preset.config.featureFlags.enabled; track id) {
                  <span class="detail-badge detail-badge--on">{{ id }}: ON</span>
                  }
                  @for (id of preset.config.featureFlags.disabled; track id) {
                  <span class="detail-badge detail-badge--off">{{ id }}: OFF</span>
                  }
                </div>
              </div>
              }
              @if (preset.config.permissions.granted.length > 0 || preset.config.permissions.denied.length > 0) {
              <div class="details-section">
                <span class="details-section__title">Permissions</span>
                <div class="details-section__items">
                  @for (id of preset.config.permissions.granted; track id) {
                  <span class="detail-badge detail-badge--on">{{ id }}: GRANTED</span>
                  }
                  @for (id of preset.config.permissions.denied; track id) {
                  <span class="detail-badge detail-badge--off">{{ id }}: DENIED</span>
                  }
                </div>
              </div>
              }
              @if (preset.config.appFeatures.enabled.length > 0 || preset.config.appFeatures.disabled.length > 0) {
              <div class="details-section">
                <span class="details-section__title">App Features</span>
                <div class="details-section__items">
                  @for (id of preset.config.appFeatures.enabled; track id) {
                  <span class="detail-badge detail-badge--on">{{ id }}: ON</span>
                  }
                  @for (id of preset.config.appFeatures.disabled; track id) {
                  <span class="detail-badge detail-badge--off">{{ id }}: OFF</span>
                  }
                </div>
              </div>
              }
            </div>
            }
          </div>
          }
        </div>
        }
      </div>
    </ndt-toolbar-tool>
  `, isInline: true, styles: [".container{position:relative;display:flex;flex-direction:column;height:100%;padding:0}.toast{position:absolute;bottom:var(--ndt-spacing-md);left:var(--ndt-spacing-md);right:var(--ndt-spacing-md);z-index:10;display:flex;align-items:center;gap:var(--ndt-spacing-sm);padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);border-radius:var(--ndt-border-radius-small);font-size:var(--ndt-font-size-sm);animation:slideUp .15s ease-out}.toast--success{background:var(--ndt-success);color:#fff}.toast--error{background:var(--ndt-danger);color:#fff}.toast__icon{font-weight:700}@keyframes slideUp{0%{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}.delete-view{flex:1;display:flex;flex-direction:column;justify-content:center;padding:var(--ndt-spacing-md)}.delete-view__content{text-align:center;padding:var(--ndt-spacing-lg) var(--ndt-spacing-md)}.delete-view__icon{font-size:48px;margin-bottom:var(--ndt-spacing-md)}.delete-view__title{margin:0 0 var(--ndt-spacing-sm);font-size:var(--ndt-font-size-md);color:var(--ndt-text-primary)}.delete-view__description{margin:0;font-size:var(--ndt-font-size-sm);color:var(--ndt-text-secondary);line-height:1.5}.delete-button{background:var(--ndt-danger);color:#fff;border:none;padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);border-radius:var(--ndt-border-radius-small);cursor:pointer;font-size:var(--ndt-font-size-sm);font-weight:500;transition:background .2s ease-out;&:hover{background:#dc2626}}.tool-header{position:relative;flex-shrink:0;display:flex;gap:var(--ndt-spacing-sm);margin-bottom:var(--ndt-spacing-md);ndt-input{flex:1}ndt-button{flex-shrink:0}}.empty{display:flex;flex-direction:column;gap:var(--ndt-spacing-md);flex:1;min-height:0;justify-content:center;align-items:center;border:1px solid var(--ndt-border-subtle);border-radius:var(--ndt-border-radius-medium);padding:var(--ndt-spacing-md);background:transparent;color:var(--ndt-text-muted);text-align:center;p{margin:0}.hint{font-size:var(--ndt-font-size-xs)}}.preset-list{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);flex:1;min-height:0;overflow-y:auto;padding-right:var(--ndt-spacing-xs);&::-webkit-scrollbar{width:8px}&::-webkit-scrollbar-track{background:var(--ndt-background-secondary);border-radius:4px}&::-webkit-scrollbar-thumb{background:var(--ndt-border-primary);border-radius:4px;&:hover{background:var(--ndt-hover-bg)}}scrollbar-width:thin;scrollbar-color:var(--ndt-border-primary) var(--ndt-background-secondary)}.preset-card{background:var(--ndt-background-secondary);padding:6px var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-medium);display:flex;flex-direction:column;gap:2px;position:relative}.preset-card__header{display:flex;align-items:center;gap:6px;flex-wrap:nowrap}.preset-card__row{display:flex;align-items:center;gap:6px;min-height:18px}.preset-card__row--meta{padding-left:36px}.preset-card__row--badges{padding-left:36px;gap:4px}.preset-card__name{font-size:var(--ndt-font-size-sm);font-weight:600;color:var(--ndt-text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.preset-card__spacer{flex:1;min-width:8px}.system-badge{font-size:8px;font-weight:600;text-transform:uppercase;letter-spacing:.3px;padding:1px 4px;border-radius:3px;background:var(--ndt-border-primary);color:var(--ndt-text-muted);flex-shrink:0}.favorite-button{background:transparent;border:none;cursor:pointer;font-size:12px;color:var(--ndt-text-muted);padding:0;line-height:1;transition:color .15s ease-out;flex-shrink:0}.favorite-button:hover,.favorite-button--active{color:#f59e0b}.preset-card__actions{display:flex;gap:2px;flex-shrink:0}.more-button{appearance:none;background:none;border:none;cursor:pointer;margin:0;padding:4px;border-radius:var(--ndt-border-radius-small);color:var(--ndt-text-muted);display:flex;align-items:center;justify-content:center;width:22px;height:22px;opacity:.5;transition:opacity .15s ease-out,color .15s ease-out,background .15s ease-out;line-height:1;font-size:14px;font-weight:700;position:relative;&:hover{background:var(--ndt-hover-bg);color:var(--ndt-text-primary);opacity:1}}.action-menu{position:absolute;top:28px;right:var(--ndt-spacing-sm);background:var(--ndt-bg-primary);border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-medium);box-shadow:var(--ndt-shadow-tooltip);z-index:20;min-width:180px;padding:4px;display:flex;flex-direction:column;gap:2px}.action-menu__item{appearance:none;background:none;border:none;cursor:pointer;display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:var(--ndt-border-radius-small);color:var(--ndt-text-primary);font-size:var(--ndt-font-size-xs);transition:background .15s ease-out;white-space:nowrap;&:hover{background:var(--ndt-hover-bg)}ndt-icon{display:block;width:14px;height:14px;flex-shrink:0;color:var(--ndt-text-muted)}}.action-menu__item--danger{color:var(--ndt-danger);ndt-icon{color:var(--ndt-danger)}&:hover{background:rgba(var(--ndt-danger-rgb),.1)}}.expand-toggle{appearance:none;background:none;border:none;cursor:pointer;padding:0 4px;margin-right:2px;font-size:10px;color:var(--ndt-text-muted);line-height:1;opacity:.6;transition:opacity .15s ease-out;flex-shrink:0;&:hover{opacity:1}}.preset-card__details{padding:var(--ndt-spacing-sm) var(--ndt-spacing-sm) var(--ndt-spacing-xs);margin-top:2px;border-top:1px solid var(--ndt-border-primary);display:flex;flex-direction:column;gap:var(--ndt-spacing-xs)}.details-section__title{font-size:10px;font-weight:600;color:var(--ndt-text-muted);text-transform:uppercase;letter-spacing:.5px}.details-section__items{display:flex;flex-wrap:wrap;gap:4px;margin-top:2px}.detail-badge{font-size:10px;padding:1px 6px;border-radius:var(--ndt-border-radius-small);white-space:nowrap}.detail-badge--on{background:rgba(var(--ndt-success-rgb),.1);color:var(--ndt-success)}.detail-badge--off{background:rgba(var(--ndt-danger-rgb),.1);color:var(--ndt-danger)}.preset-card__description{font-size:11px;color:var(--ndt-text-secondary);flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.preset-card__date{font-size:10px;color:var(--ndt-text-muted);margin-left:auto;flex-shrink:0}.badge{background:#6366f126;color:#6366f1;padding:1px 6px;border-radius:8px;font-size:10px;font-weight:500;white-space:nowrap}.badge--lang{background:rgba(var(--ndt-success-rgb),.15);color:var(--ndt-success)}.preset-form,.import-view,.apply-view{flex:1;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:var(--ndt-spacing-sm);padding:var(--ndt-spacing-sm);ndt-input{width:100%}}.form-title{margin:0;font-size:var(--ndt-font-size-sm);font-weight:600;color:var(--ndt-text-primary)}.form-hint{margin:0;font-size:11px;color:var(--ndt-text-muted);line-height:1.3}.form-field{display:flex;flex-direction:column;gap:2px}.field-error{color:var(--ndt-danger);font-size:11px}.preset-summary{background:var(--ndt-background-secondary);padding:var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-medium);display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);h4{margin:0;font-size:11px;font-weight:500;color:var(--ndt-text-secondary)}}.category-section{display:flex;flex-direction:column;gap:2px}.checkbox-option{display:flex;align-items:center;gap:var(--ndt-spacing-xs);cursor:pointer;color:var(--ndt-text-primary);font-size:var(--ndt-font-size-sm);padding:2px 0;input[type=checkbox]{cursor:pointer;width:14px;height:14px;accent-color:rgb(99,102,241);border-radius:3px;&:disabled{cursor:not-allowed;opacity:.4}}&:has(input:disabled){opacity:.5;cursor:not-allowed}}.forced-items-list{list-style:none;padding:0;margin:0 0 0 20px;display:flex;flex-direction:column;gap:2px;font-size:11px;max-height:100px;overflow-y:auto;li{background:rgba(var(--ndt-primary-rgb),.05);border-radius:3px;padding-left:6px}.item-checkbox{display:flex;justify-content:space-between;align-items:center;padding:3px 6px;cursor:pointer;gap:6px;input[type=checkbox]{cursor:pointer;width:12px;height:12px;accent-color:rgb(99,102,241);flex-shrink:0}&:hover{background:#6366f114}}.item-name{color:var(--ndt-text-primary);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.item-status{font-weight:600;padding:1px 4px;border-radius:3px;font-size:9px;text-transform:uppercase;letter-spacing:.3px;flex-shrink:0;&.enabled{background:rgba(var(--ndt-success-rgb),.15);color:var(--ndt-success)}&.disabled{background:rgba(var(--ndt-danger-rgb),.15);color:var(--ndt-danger)}}}.form-actions{display:flex;justify-content:flex-end;gap:var(--ndt-spacing-sm);margin-top:auto;padding-top:var(--ndt-spacing-sm)}.config-preview{background:var(--ndt-background-secondary);padding:var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-medium);display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);h4{margin:0;font-size:11px;font-weight:500;color:var(--ndt-text-secondary)}}.config-category{display:flex;flex-direction:column;gap:2px}.config-category__title{font-size:10px;color:var(--ndt-text-muted);font-weight:500}.config-items{display:flex;flex-wrap:wrap;gap:4px}.config-item{font-size:10px;padding:1px 6px;border-radius:3px;background:var(--ndt-background-primary);color:var(--ndt-text-secondary)}.config-item--on{background:rgba(var(--ndt-success-rgb),.1);color:var(--ndt-success)}.config-item--off{background:rgba(var(--ndt-danger-rgb),.1);color:var(--ndt-danger)}.replace-config-button{background:transparent;border:1px dashed var(--ndt-border-primary);padding:6px var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-small);color:var(--ndt-text-secondary);cursor:pointer;font-size:11px;transition:all .15s ease-out;&:hover{background:var(--ndt-hover-bg);border-color:#6366f1;color:#6366f1}}.drop-zone{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;padding:var(--ndt-spacing-md);border:2px dashed var(--ndt-border-primary);border-radius:var(--ndt-border-radius-medium);cursor:pointer;transition:all .15s ease-out}.drop-zone:hover,.drop-zone--active{border-color:#6366f1;background:#6366f10d}.drop-zone__icon{font-size:24px}.drop-zone__text{font-size:var(--ndt-font-size-sm);color:var(--ndt-text-primary)}.drop-zone__hint{font-size:11px;color:var(--ndt-text-muted)}.divider{display:flex;align-items:center;gap:var(--ndt-spacing-sm);color:var(--ndt-text-muted);font-size:10px;&:before,&:after{content:\"\";flex:1;height:1px;background:var(--ndt-border-primary)}}.json-textarea{width:100%;min-height:80px;padding:var(--ndt-spacing-xs);border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-small);background:var(--ndt-background-secondary);color:var(--ndt-text-primary);font-family:monospace;font-size:11px;resize:vertical;&:focus{outline:none;border-color:#6366f1}&::placeholder{color:var(--ndt-text-muted)}}.apply-description{margin:0;font-size:11px;color:var(--ndt-text-secondary)}.apply-categories{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs)}.apply-category{background:var(--ndt-background-secondary);border-radius:var(--ndt-border-radius-small);overflow:hidden;transition:opacity .15s ease-out}.apply-category--disabled{opacity:.5}.apply-category__header{display:flex;align-items:center;gap:var(--ndt-spacing-xs);padding:6px var(--ndt-spacing-sm);cursor:pointer;font-size:var(--ndt-font-size-sm);color:var(--ndt-text-primary);font-weight:500;input[type=checkbox]{cursor:pointer;width:14px;height:14px;accent-color:rgb(99,102,241)}}.apply-diff{padding:0 var(--ndt-spacing-sm) 6px;display:flex;flex-direction:column;gap:2px}.diff-item{display:flex;align-items:center;gap:6px;font-size:11px;padding:3px 6px;background:var(--ndt-background-primary);border-radius:3px}.diff-item__name{flex:1;color:var(--ndt-text-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.diff-item__arrow{color:var(--ndt-text-muted);font-size:10px}.diff-item__value{font-weight:600;padding:1px 4px;border-radius:3px;font-size:9px;text-transform:uppercase;letter-spacing:.3px}.diff-item__value--on{background:rgba(var(--ndt-success-rgb),.15);color:var(--ndt-success)}.diff-item__value--off{background:rgba(var(--ndt-danger-rgb),.15);color:var(--ndt-danger)}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$1.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: ToolbarToolComponent, selector: "ndt-toolbar-tool", inputs: ["options", "icon", "toolTitle", "badge"] }, { kind: "component", type: ToolbarInputComponent, selector: "ndt-input", inputs: ["value", "type", "placeholder", "ariaLabel", "inputClass"], outputs: ["valueChange"] }, { kind: "component", type: ToolbarButtonComponent, selector: "ndt-button", inputs: ["type", "variant", "icon", "label", "ariaLabel", "isActive", "disabled"] }, { kind: "component", type: ToolbarIconComponent, selector: "ndt-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarPresetsToolComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-presets-tool', standalone: true, imports: [
                        FormsModule,
                        ToolbarToolComponent,
                        ToolbarInputComponent,
                        ToolbarButtonComponent,
                        ToolbarIconComponent,
                    ], template: `
    <ndt-toolbar-tool [options]="options" toolTitle="Presets" icon="layout">
      <div class="container">
        <!-- Toast Notification -->
        @if (toastMessage()) {
        <div class="toast" [class.toast--success]="toastType() === 'success'" [class.toast--error]="toastType() === 'error'">
          <span class="toast__icon">{{ toastType() === 'success' ? '✓' : '✕' }}</span>
          <span class="toast__message">{{ toastMessage() }}</span>
        </div>
        }


        <!-- Mode Toggle -->
        @if (!hasNoPresets() || viewMode() !== 'list') {
        <div class="tool-header">
          @if (viewMode() === 'list') {
          <ndt-input
            [value]="searchQuery()"
            (valueChange)="onSearchChange($event)"
            placeholder="Search presets..."
            [ariaLabel]="'Search presets'"
          />
          <ndt-button
            (click)="onSwitchToImportMode()"
            [ariaLabel]="'Import preset'"
          >
            Import
          </ndt-button>
          <ndt-button
            (click)="onSwitchToCreateMode()"
            [ariaLabel]="'Create new preset'"
          >
            New
          </ndt-button>
          } @else {
          <ndt-button
            (click)="onSwitchToListMode()"
            [ariaLabel]="'Back to list'"
          >
            ← Back
          </ndt-button>
          }
        </div>
        }

        <!-- Create Form -->
        @if (viewMode() === 'create') {
        <form (submit)="onSavePreset($event)" class="preset-form">
          <h3 class="form-title">Create Preset</h3>
          <p class="form-hint">This will save the current forced values from other tools. Only items you've explicitly set will be included.</p>
          <div class="form-field">
            <ndt-input
              label="Preset Name *"
              [value]="presetName()"
              (valueChange)="onPresetNameChange($event)"
              placeholder="e.g., Admin User - Full Access"
              [ariaLabel]="'Preset name'"
            />
            @if (nameError()) {
            <span class="field-error">{{ nameError() }}</span>
            }
          </div>
          <ndt-input
            label="Description (optional)"
            [value]="presetDescription()"
            (valueChange)="presetDescription.set($event)"
            placeholder="Brief description of this preset"
            [ariaLabel]="'Preset description'"
          />

          <!-- Category selection checkboxes -->
          <div class="preset-summary">
            <h4>Select what to include:</h4>

            @if (isFeatureFlagsEnabled()) {
            <div class="category-section">
              <label class="checkbox-option">
                <input
                  type="checkbox"
                  [checked]="includeFeatureFlags()"
                  (change)="includeFeatureFlags.set(!includeFeatureFlags())"
                  [disabled]="getCurrentFlagsCount() === 0"
                />
                <span>Feature Flags ({{ getCurrentFlagsCount() }} forced)</span>
              </label>
              @if (forcedFlags().length > 0) {
              <ul class="forced-items-list">
                @for (flag of forcedFlags(); track flag.id) {
                <li>
                  <label class="item-checkbox">
                    <input
                      type="checkbox"
                      [checked]="isItemSelected(selectedFlagIds(), flag.id)"
                      (change)="toggleItemSelection(selectedFlagIds, flag.id)"
                    />
                    <span class="item-name">{{ flag.name }}</span>
                    <span class="item-status" [class.enabled]="flag.isEnabled" [class.disabled]="!flag.isEnabled">
                      {{ flag.isEnabled ? 'ON' : 'OFF' }}
                    </span>
                  </label>
                </li>
                }
              </ul>
              }
            </div>
            }

            @if (isPermissionsEnabled()) {
            <div class="category-section">
              <label class="checkbox-option">
                <input
                  type="checkbox"
                  [checked]="includePermissions()"
                  (change)="includePermissions.set(!includePermissions())"
                  [disabled]="getCurrentPermissionsCount() === 0"
                />
                <span>Permissions ({{ getCurrentPermissionsCount() }} forced)</span>
              </label>
              @if (forcedPermissions().length > 0) {
              <ul class="forced-items-list">
                @for (perm of forcedPermissions(); track perm.id) {
                <li>
                  <label class="item-checkbox">
                    <input
                      type="checkbox"
                      [checked]="isItemSelected(selectedPermissionIds(), perm.id)"
                      (change)="toggleItemSelection(selectedPermissionIds, perm.id)"
                    />
                    <span class="item-name">{{ perm.name }}</span>
                    <span class="item-status" [class.enabled]="perm.isGranted" [class.disabled]="!perm.isGranted">
                      {{ perm.isGranted ? 'GRANTED' : 'DENIED' }}
                    </span>
                  </label>
                </li>
                }
              </ul>
              }
            </div>
            }

            @if (isAppFeaturesEnabled()) {
            <div class="category-section">
              <label class="checkbox-option">
                <input
                  type="checkbox"
                  [checked]="includeAppFeatures()"
                  (change)="includeAppFeatures.set(!includeAppFeatures())"
                  [disabled]="getCurrentAppFeaturesCount() === 0"
                />
                <span>App Features ({{ getCurrentAppFeaturesCount() }} forced)</span>
              </label>
              @if (forcedAppFeatures().length > 0) {
              <ul class="forced-items-list">
                @for (feat of forcedAppFeatures(); track feat.id) {
                <li>
                  <label class="item-checkbox">
                    <input
                      type="checkbox"
                      [checked]="isItemSelected(selectedFeatureIds(), feat.id)"
                      (change)="toggleItemSelection(selectedFeatureIds, feat.id)"
                    />
                    <span class="item-name">{{ feat.name }}</span>
                    <span class="item-status" [class.enabled]="feat.isEnabled" [class.disabled]="!feat.isEnabled">
                      {{ feat.isEnabled ? 'ON' : 'OFF' }}
                    </span>
                  </label>
                </li>
                }
              </ul>
              }
            </div>
            }

          </div>

          <div class="form-actions">
            <ndt-button type="button" (click)="onSwitchToListMode()">Cancel</ndt-button>
            <ndt-button type="submit">Save Preset</ndt-button>
          </div>
        </form>
        }

        <!-- Edit Form -->
        @if (viewMode() === 'edit') {
        <form (submit)="onSaveEdit($event)" class="preset-form">
          <h3 class="form-title">Edit Preset</h3>
          <div class="form-field">
            <ndt-input
              label="Preset Name *"
              [value]="editName()"
              (valueChange)="onEditNameChange($event)"
              placeholder="e.g., Admin User - Full Access"
              [ariaLabel]="'Preset name'"
            />
            @if (nameError()) {
            <span class="field-error">{{ nameError() }}</span>
            }
          </div>
          <ndt-input
            label="Description (optional)"
            [value]="editDescription()"
            (valueChange)="editDescription.set($event)"
            placeholder="Brief description of this preset"
            [ariaLabel]="'Preset description'"
          />

          <!-- Show saved configuration read-only -->
          @if (editingPreset()) {
          <div class="config-preview">
            <h4>Saved Configuration</h4>
            @if (editingPreset()!.config.featureFlags.enabled.length > 0 || editingPreset()!.config.featureFlags.disabled.length > 0) {
            <div class="config-category">
              <span class="config-category__title">Feature Flags ({{ editingPreset()!.config.featureFlags.enabled.length + editingPreset()!.config.featureFlags.disabled.length }})</span>
              <div class="config-items">
                @for (id of editingPreset()!.config.featureFlags.enabled; track id) {
                <span class="config-item config-item--on">{{ id }}: ON</span>
                }
                @for (id of editingPreset()!.config.featureFlags.disabled; track id) {
                <span class="config-item config-item--off">{{ id }}: OFF</span>
                }
              </div>
            </div>
            }
            @if (editingPreset()!.config.permissions.granted.length > 0 || editingPreset()!.config.permissions.denied.length > 0) {
            <div class="config-category">
              <span class="config-category__title">Permissions ({{ editingPreset()!.config.permissions.granted.length + editingPreset()!.config.permissions.denied.length }})</span>
              <div class="config-items">
                @for (id of editingPreset()!.config.permissions.granted; track id) {
                <span class="config-item config-item--on">{{ id }}: GRANTED</span>
                }
                @for (id of editingPreset()!.config.permissions.denied; track id) {
                <span class="config-item config-item--off">{{ id }}: DENIED</span>
                }
              </div>
            </div>
            }
            @if (editingPreset()!.config.appFeatures.enabled.length > 0 || editingPreset()!.config.appFeatures.disabled.length > 0) {
            <div class="config-category">
              <span class="config-category__title">App Features ({{ editingPreset()!.config.appFeatures.enabled.length + editingPreset()!.config.appFeatures.disabled.length }})</span>
              <div class="config-items">
                @for (id of editingPreset()!.config.appFeatures.enabled; track id) {
                <span class="config-item config-item--on">{{ id }}: ON</span>
                }
                @for (id of editingPreset()!.config.appFeatures.disabled; track id) {
                <span class="config-item config-item--off">{{ id }}: OFF</span>
                }
              </div>
            </div>
            }
            <button type="button" class="replace-config-button" (click)="onReplaceConfig()">
              ↻ Replace with current toolbar state
            </button>
          </div>
          }

          <div class="form-actions">
            <ndt-button type="button" (click)="onSwitchToListMode()">Cancel</ndt-button>
            <ndt-button type="submit">Save Changes</ndt-button>
          </div>
        </form>
        }

        <!-- Import View -->
        @if (viewMode() === 'import') {
        <div class="import-view">
          <h3 class="form-title">Import Preset</h3>

          <!-- File Drop Zone -->
          <div
            class="drop-zone"
            [class.drop-zone--active]="isDragOver()"
            (dragover)="onDragOver($event)"
            (dragleave)="onDragLeave($event)"
            (drop)="onFileDrop($event)"
            (click)="fileInput.click()"
            (keydown.enter)="fileInput.click()"
            (keydown.space)="fileInput.click()"
            tabindex="0"
            role="button"
          >
            <input
              #fileInput
              type="file"
              accept=".json"
              (change)="onFileSelect($event)"
              hidden
            />
            <span class="drop-zone__icon">📁</span>
            <span class="drop-zone__text">Drop a .json file here</span>
            <span class="drop-zone__hint">or click to browse</span>
          </div>

          <div class="divider">
            <span>or paste JSON</span>
          </div>

          <!-- JSON Textarea -->
          <textarea
            class="json-textarea"
            [value]="importJson()"
            (input)="onImportJsonChange($event)"
            placeholder='{"name": "...", "config": { ... }}'
          ></textarea>

          @if (importError()) {
          <span class="field-error">{{ importError() }}</span>
          }

          <div class="form-actions">
            <ndt-button type="button" (click)="onSwitchToListMode()">Cancel</ndt-button>
            <ndt-button (click)="onImportPreset()">Import Preset</ndt-button>
          </div>
        </div>
        }

        <!-- Partial Apply View -->
        @if (viewMode() === 'apply') {
        <div class="apply-view">
          <h3 class="form-title">Apply: {{ applyingPreset()?.name }}</h3>
          <p class="apply-description">Select which parts to apply</p>

          @if (applyingPreset()) {
          <div class="apply-categories">
            <!-- Feature Flags -->
            @if (applyingPreset()!.config.featureFlags.enabled.length > 0 || applyingPreset()!.config.featureFlags.disabled.length > 0) {
            <div class="apply-category" [class.apply-category--disabled]="!applyFeatureFlags()">
              <label class="apply-category__header">
                <input
                  type="checkbox"
                  [checked]="applyFeatureFlags()"
                  (change)="applyFeatureFlags.set(!applyFeatureFlags())"
                />
                <span>Feature Flags ({{ applyingPreset()!.config.featureFlags.enabled.length + applyingPreset()!.config.featureFlags.disabled.length }})</span>
              </label>
              @if (applyFeatureFlags()) {
              <div class="apply-diff">
                @for (id of applyingPreset()!.config.featureFlags.enabled; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--on">ON</span>
                </div>
                }
                @for (id of applyingPreset()!.config.featureFlags.disabled; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--off">OFF</span>
                </div>
                }
              </div>
              }
            </div>
            }

            <!-- Permissions -->
            @if (applyingPreset()!.config.permissions.granted.length > 0 || applyingPreset()!.config.permissions.denied.length > 0) {
            <div class="apply-category" [class.apply-category--disabled]="!applyPermissions()">
              <label class="apply-category__header">
                <input
                  type="checkbox"
                  [checked]="applyPermissions()"
                  (change)="applyPermissions.set(!applyPermissions())"
                />
                <span>Permissions ({{ applyingPreset()!.config.permissions.granted.length + applyingPreset()!.config.permissions.denied.length }})</span>
              </label>
              @if (applyPermissions()) {
              <div class="apply-diff">
                @for (id of applyingPreset()!.config.permissions.granted; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--on">GRANTED</span>
                </div>
                }
                @for (id of applyingPreset()!.config.permissions.denied; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--off">DENIED</span>
                </div>
                }
              </div>
              }
            </div>
            }

            <!-- App Features -->
            @if (applyingPreset()!.config.appFeatures.enabled.length > 0 || applyingPreset()!.config.appFeatures.disabled.length > 0) {
            <div class="apply-category" [class.apply-category--disabled]="!applyAppFeatures()">
              <label class="apply-category__header">
                <input
                  type="checkbox"
                  [checked]="applyAppFeatures()"
                  (change)="applyAppFeatures.set(!applyAppFeatures())"
                />
                <span>App Features ({{ applyingPreset()!.config.appFeatures.enabled.length + applyingPreset()!.config.appFeatures.disabled.length }})</span>
              </label>
              @if (applyAppFeatures()) {
              <div class="apply-diff">
                @for (id of applyingPreset()!.config.appFeatures.enabled; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--on">ON</span>
                </div>
                }
                @for (id of applyingPreset()!.config.appFeatures.disabled; track id) {
                <div class="diff-item">
                  <span class="diff-item__name">{{ id }}</span>
                  <span class="diff-item__arrow">→</span>
                  <span class="diff-item__value diff-item__value--off">OFF</span>
                </div>
                }
              </div>
              }
            </div>
            }

          </div>
          }

          <div class="form-actions">
            <ndt-button type="button" (click)="onSwitchToListMode()">Cancel</ndt-button>
            <ndt-button (click)="onConfirmPartialApply()">Apply Selected</ndt-button>
          </div>
        </div>
        }

        <!-- Delete Confirmation View -->
        @if (viewMode() === 'delete') {
        <div class="delete-view">
          <div class="delete-view__content">
            <div class="delete-view__icon">🗑️</div>
            <h3 class="delete-view__title">Delete "{{ deletePresetName() }}"?</h3>
            <p class="delete-view__description">
              This preset will be permanently removed.
              This action cannot be undone.
            </p>
          </div>
          <div class="form-actions">
            <ndt-button type="button" (click)="onSwitchToListMode()">← Back</ndt-button>
            <button class="delete-button" (click)="onConfirmDelete()">Delete Preset</button>
          </div>
        </div>
        }

        <!-- Empty State -->
        @if (viewMode() === 'list' && hasNoPresets()) {
        <div class="empty">
          <p>No presets saved yet</p>
          <p class="hint">
            Save the current toolbar configuration as a preset for quick access
          </p>
          <ndt-button (click)="onSwitchToCreateMode()">
            Create Your First Preset
          </ndt-button>
        </div>
        } @else if (viewMode() === 'list' && hasNoFilteredPresets()) {
        <div class="empty">
          <p>No presets match your search</p>
        </div>
        } @else if (viewMode() === 'list') {
        <!-- Preset List -->
        <div class="preset-list">
          @for (preset of sortedPresets(); track preset.id) {
          <div class="preset-card">
            <div class="preset-card__header">
              <button
                class="expand-toggle"
                (click)="onToggleExpand(preset.id); $event.stopPropagation()"
                [attr.aria-label]="expandedPresetId() === preset.id ? 'Collapse details' : 'Expand details'"
              >{{ expandedPresetId() === preset.id ? '▾' : '▸' }}</button>
              <button
                class="favorite-button"
                [class.favorite-button--active]="preset.isFavorite"
                (click)="onToggleFavorite(preset.id); $event.stopPropagation()"
                [attr.aria-label]="preset.isFavorite ? 'Remove from favorites' : 'Add to favorites'"
              >{{ preset.isFavorite ? '★' : '☆' }}</button>
              <span class="preset-card__name">{{ preset.name }}</span>
              @if (preset.isSystem) {<span class="system-badge">SYS</span>}
              <span class="preset-card__spacer"></span>
              <div class="preset-card__actions">
                <button
                  class="more-button"
                  (click)="onToggleMenu(preset.id); $event.stopPropagation()"
                  aria-label="Actions"
                >⋯</button>
              </div>
              @if (openMenuId() === preset.id) {
              <div class="action-menu" role="menu" tabindex="-1" (click)="$event.stopPropagation()" (keydown.escape)="openMenuId.set(null)">
                <button class="action-menu__item" (click)="onStartApply(preset.id); openMenuId.set(null)">
                  <ndt-icon name="refresh" />
                  <span>Apply preset</span>
                </button>
                @if (!preset.isSystem) {
                <button class="action-menu__item" (click)="onStartEdit(preset.id); openMenuId.set(null)">
                  <ndt-icon name="edit" />
                  <span>Edit</span>
                </button>
                <button class="action-menu__item" (click)="onUpdatePreset(preset.id); openMenuId.set(null)">
                  <ndt-icon name="gear" />
                  <span>Update with current values</span>
                </button>
                }
                <button class="action-menu__item" (click)="onExportPreset(preset.id); openMenuId.set(null)">
                  <ndt-icon name="export" />
                  <span>Export as JSON</span>
                </button>
                @if (!preset.isSystem) {
                <button class="action-menu__item action-menu__item--danger" (click)="onDeletePreset(preset.id); openMenuId.set(null)">
                  <ndt-icon name="trash" />
                  <span>Delete</span>
                </button>
                }
              </div>
              }
            </div>
            @if (preset.description) {
            <div class="preset-card__row preset-card__row--meta">
              <span class="preset-card__description">{{ preset.description }}</span>
            </div>
            }
            <div class="preset-card__row preset-card__row--badges">
              @if (preset.config.featureFlags.enabled.length > 0 || preset.config.featureFlags.disabled.length > 0) {
              <span class="badge">{{ preset.config.featureFlags.enabled.length + preset.config.featureFlags.disabled.length }} flags</span>
              }
              @if (preset.config.permissions.granted.length > 0 || preset.config.permissions.denied.length > 0) {
              <span class="badge">{{ preset.config.permissions.granted.length + preset.config.permissions.denied.length }} perms</span>
              }
              @if (preset.config.appFeatures.enabled.length > 0 || preset.config.appFeatures.disabled.length > 0) {
              <span class="badge">{{ preset.config.appFeatures.enabled.length + preset.config.appFeatures.disabled.length }} features</span>
              }
              <span class="preset-card__date">{{ formatDate(preset.updatedAt) }}</span>
            </div>
            @if (expandedPresetId() === preset.id) {
            <div class="preset-card__details">
              @if (preset.config.featureFlags.enabled.length > 0 || preset.config.featureFlags.disabled.length > 0) {
              <div class="details-section">
                <span class="details-section__title">Feature Flags</span>
                <div class="details-section__items">
                  @for (id of preset.config.featureFlags.enabled; track id) {
                  <span class="detail-badge detail-badge--on">{{ id }}: ON</span>
                  }
                  @for (id of preset.config.featureFlags.disabled; track id) {
                  <span class="detail-badge detail-badge--off">{{ id }}: OFF</span>
                  }
                </div>
              </div>
              }
              @if (preset.config.permissions.granted.length > 0 || preset.config.permissions.denied.length > 0) {
              <div class="details-section">
                <span class="details-section__title">Permissions</span>
                <div class="details-section__items">
                  @for (id of preset.config.permissions.granted; track id) {
                  <span class="detail-badge detail-badge--on">{{ id }}: GRANTED</span>
                  }
                  @for (id of preset.config.permissions.denied; track id) {
                  <span class="detail-badge detail-badge--off">{{ id }}: DENIED</span>
                  }
                </div>
              </div>
              }
              @if (preset.config.appFeatures.enabled.length > 0 || preset.config.appFeatures.disabled.length > 0) {
              <div class="details-section">
                <span class="details-section__title">App Features</span>
                <div class="details-section__items">
                  @for (id of preset.config.appFeatures.enabled; track id) {
                  <span class="detail-badge detail-badge--on">{{ id }}: ON</span>
                  }
                  @for (id of preset.config.appFeatures.disabled; track id) {
                  <span class="detail-badge detail-badge--off">{{ id }}: OFF</span>
                  }
                </div>
              </div>
              }
            </div>
            }
          </div>
          }
        </div>
        }
      </div>
    </ndt-toolbar-tool>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".container{position:relative;display:flex;flex-direction:column;height:100%;padding:0}.toast{position:absolute;bottom:var(--ndt-spacing-md);left:var(--ndt-spacing-md);right:var(--ndt-spacing-md);z-index:10;display:flex;align-items:center;gap:var(--ndt-spacing-sm);padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);border-radius:var(--ndt-border-radius-small);font-size:var(--ndt-font-size-sm);animation:slideUp .15s ease-out}.toast--success{background:var(--ndt-success);color:#fff}.toast--error{background:var(--ndt-danger);color:#fff}.toast__icon{font-weight:700}@keyframes slideUp{0%{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}.delete-view{flex:1;display:flex;flex-direction:column;justify-content:center;padding:var(--ndt-spacing-md)}.delete-view__content{text-align:center;padding:var(--ndt-spacing-lg) var(--ndt-spacing-md)}.delete-view__icon{font-size:48px;margin-bottom:var(--ndt-spacing-md)}.delete-view__title{margin:0 0 var(--ndt-spacing-sm);font-size:var(--ndt-font-size-md);color:var(--ndt-text-primary)}.delete-view__description{margin:0;font-size:var(--ndt-font-size-sm);color:var(--ndt-text-secondary);line-height:1.5}.delete-button{background:var(--ndt-danger);color:#fff;border:none;padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);border-radius:var(--ndt-border-radius-small);cursor:pointer;font-size:var(--ndt-font-size-sm);font-weight:500;transition:background .2s ease-out;&:hover{background:#dc2626}}.tool-header{position:relative;flex-shrink:0;display:flex;gap:var(--ndt-spacing-sm);margin-bottom:var(--ndt-spacing-md);ndt-input{flex:1}ndt-button{flex-shrink:0}}.empty{display:flex;flex-direction:column;gap:var(--ndt-spacing-md);flex:1;min-height:0;justify-content:center;align-items:center;border:1px solid var(--ndt-border-subtle);border-radius:var(--ndt-border-radius-medium);padding:var(--ndt-spacing-md);background:transparent;color:var(--ndt-text-muted);text-align:center;p{margin:0}.hint{font-size:var(--ndt-font-size-xs)}}.preset-list{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);flex:1;min-height:0;overflow-y:auto;padding-right:var(--ndt-spacing-xs);&::-webkit-scrollbar{width:8px}&::-webkit-scrollbar-track{background:var(--ndt-background-secondary);border-radius:4px}&::-webkit-scrollbar-thumb{background:var(--ndt-border-primary);border-radius:4px;&:hover{background:var(--ndt-hover-bg)}}scrollbar-width:thin;scrollbar-color:var(--ndt-border-primary) var(--ndt-background-secondary)}.preset-card{background:var(--ndt-background-secondary);padding:6px var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-medium);display:flex;flex-direction:column;gap:2px;position:relative}.preset-card__header{display:flex;align-items:center;gap:6px;flex-wrap:nowrap}.preset-card__row{display:flex;align-items:center;gap:6px;min-height:18px}.preset-card__row--meta{padding-left:36px}.preset-card__row--badges{padding-left:36px;gap:4px}.preset-card__name{font-size:var(--ndt-font-size-sm);font-weight:600;color:var(--ndt-text-primary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.preset-card__spacer{flex:1;min-width:8px}.system-badge{font-size:8px;font-weight:600;text-transform:uppercase;letter-spacing:.3px;padding:1px 4px;border-radius:3px;background:var(--ndt-border-primary);color:var(--ndt-text-muted);flex-shrink:0}.favorite-button{background:transparent;border:none;cursor:pointer;font-size:12px;color:var(--ndt-text-muted);padding:0;line-height:1;transition:color .15s ease-out;flex-shrink:0}.favorite-button:hover,.favorite-button--active{color:#f59e0b}.preset-card__actions{display:flex;gap:2px;flex-shrink:0}.more-button{appearance:none;background:none;border:none;cursor:pointer;margin:0;padding:4px;border-radius:var(--ndt-border-radius-small);color:var(--ndt-text-muted);display:flex;align-items:center;justify-content:center;width:22px;height:22px;opacity:.5;transition:opacity .15s ease-out,color .15s ease-out,background .15s ease-out;line-height:1;font-size:14px;font-weight:700;position:relative;&:hover{background:var(--ndt-hover-bg);color:var(--ndt-text-primary);opacity:1}}.action-menu{position:absolute;top:28px;right:var(--ndt-spacing-sm);background:var(--ndt-bg-primary);border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-medium);box-shadow:var(--ndt-shadow-tooltip);z-index:20;min-width:180px;padding:4px;display:flex;flex-direction:column;gap:2px}.action-menu__item{appearance:none;background:none;border:none;cursor:pointer;display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:var(--ndt-border-radius-small);color:var(--ndt-text-primary);font-size:var(--ndt-font-size-xs);transition:background .15s ease-out;white-space:nowrap;&:hover{background:var(--ndt-hover-bg)}ndt-icon{display:block;width:14px;height:14px;flex-shrink:0;color:var(--ndt-text-muted)}}.action-menu__item--danger{color:var(--ndt-danger);ndt-icon{color:var(--ndt-danger)}&:hover{background:rgba(var(--ndt-danger-rgb),.1)}}.expand-toggle{appearance:none;background:none;border:none;cursor:pointer;padding:0 4px;margin-right:2px;font-size:10px;color:var(--ndt-text-muted);line-height:1;opacity:.6;transition:opacity .15s ease-out;flex-shrink:0;&:hover{opacity:1}}.preset-card__details{padding:var(--ndt-spacing-sm) var(--ndt-spacing-sm) var(--ndt-spacing-xs);margin-top:2px;border-top:1px solid var(--ndt-border-primary);display:flex;flex-direction:column;gap:var(--ndt-spacing-xs)}.details-section__title{font-size:10px;font-weight:600;color:var(--ndt-text-muted);text-transform:uppercase;letter-spacing:.5px}.details-section__items{display:flex;flex-wrap:wrap;gap:4px;margin-top:2px}.detail-badge{font-size:10px;padding:1px 6px;border-radius:var(--ndt-border-radius-small);white-space:nowrap}.detail-badge--on{background:rgba(var(--ndt-success-rgb),.1);color:var(--ndt-success)}.detail-badge--off{background:rgba(var(--ndt-danger-rgb),.1);color:var(--ndt-danger)}.preset-card__description{font-size:11px;color:var(--ndt-text-secondary);flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.preset-card__date{font-size:10px;color:var(--ndt-text-muted);margin-left:auto;flex-shrink:0}.badge{background:#6366f126;color:#6366f1;padding:1px 6px;border-radius:8px;font-size:10px;font-weight:500;white-space:nowrap}.badge--lang{background:rgba(var(--ndt-success-rgb),.15);color:var(--ndt-success)}.preset-form,.import-view,.apply-view{flex:1;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:var(--ndt-spacing-sm);padding:var(--ndt-spacing-sm);ndt-input{width:100%}}.form-title{margin:0;font-size:var(--ndt-font-size-sm);font-weight:600;color:var(--ndt-text-primary)}.form-hint{margin:0;font-size:11px;color:var(--ndt-text-muted);line-height:1.3}.form-field{display:flex;flex-direction:column;gap:2px}.field-error{color:var(--ndt-danger);font-size:11px}.preset-summary{background:var(--ndt-background-secondary);padding:var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-medium);display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);h4{margin:0;font-size:11px;font-weight:500;color:var(--ndt-text-secondary)}}.category-section{display:flex;flex-direction:column;gap:2px}.checkbox-option{display:flex;align-items:center;gap:var(--ndt-spacing-xs);cursor:pointer;color:var(--ndt-text-primary);font-size:var(--ndt-font-size-sm);padding:2px 0;input[type=checkbox]{cursor:pointer;width:14px;height:14px;accent-color:rgb(99,102,241);border-radius:3px;&:disabled{cursor:not-allowed;opacity:.4}}&:has(input:disabled){opacity:.5;cursor:not-allowed}}.forced-items-list{list-style:none;padding:0;margin:0 0 0 20px;display:flex;flex-direction:column;gap:2px;font-size:11px;max-height:100px;overflow-y:auto;li{background:rgba(var(--ndt-primary-rgb),.05);border-radius:3px;padding-left:6px}.item-checkbox{display:flex;justify-content:space-between;align-items:center;padding:3px 6px;cursor:pointer;gap:6px;input[type=checkbox]{cursor:pointer;width:12px;height:12px;accent-color:rgb(99,102,241);flex-shrink:0}&:hover{background:#6366f114}}.item-name{color:var(--ndt-text-primary);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.item-status{font-weight:600;padding:1px 4px;border-radius:3px;font-size:9px;text-transform:uppercase;letter-spacing:.3px;flex-shrink:0;&.enabled{background:rgba(var(--ndt-success-rgb),.15);color:var(--ndt-success)}&.disabled{background:rgba(var(--ndt-danger-rgb),.15);color:var(--ndt-danger)}}}.form-actions{display:flex;justify-content:flex-end;gap:var(--ndt-spacing-sm);margin-top:auto;padding-top:var(--ndt-spacing-sm)}.config-preview{background:var(--ndt-background-secondary);padding:var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-medium);display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);h4{margin:0;font-size:11px;font-weight:500;color:var(--ndt-text-secondary)}}.config-category{display:flex;flex-direction:column;gap:2px}.config-category__title{font-size:10px;color:var(--ndt-text-muted);font-weight:500}.config-items{display:flex;flex-wrap:wrap;gap:4px}.config-item{font-size:10px;padding:1px 6px;border-radius:3px;background:var(--ndt-background-primary);color:var(--ndt-text-secondary)}.config-item--on{background:rgba(var(--ndt-success-rgb),.1);color:var(--ndt-success)}.config-item--off{background:rgba(var(--ndt-danger-rgb),.1);color:var(--ndt-danger)}.replace-config-button{background:transparent;border:1px dashed var(--ndt-border-primary);padding:6px var(--ndt-spacing-sm);border-radius:var(--ndt-border-radius-small);color:var(--ndt-text-secondary);cursor:pointer;font-size:11px;transition:all .15s ease-out;&:hover{background:var(--ndt-hover-bg);border-color:#6366f1;color:#6366f1}}.drop-zone{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;padding:var(--ndt-spacing-md);border:2px dashed var(--ndt-border-primary);border-radius:var(--ndt-border-radius-medium);cursor:pointer;transition:all .15s ease-out}.drop-zone:hover,.drop-zone--active{border-color:#6366f1;background:#6366f10d}.drop-zone__icon{font-size:24px}.drop-zone__text{font-size:var(--ndt-font-size-sm);color:var(--ndt-text-primary)}.drop-zone__hint{font-size:11px;color:var(--ndt-text-muted)}.divider{display:flex;align-items:center;gap:var(--ndt-spacing-sm);color:var(--ndt-text-muted);font-size:10px;&:before,&:after{content:\"\";flex:1;height:1px;background:var(--ndt-border-primary)}}.json-textarea{width:100%;min-height:80px;padding:var(--ndt-spacing-xs);border:1px solid var(--ndt-border-primary);border-radius:var(--ndt-border-radius-small);background:var(--ndt-background-secondary);color:var(--ndt-text-primary);font-family:monospace;font-size:11px;resize:vertical;&:focus{outline:none;border-color:#6366f1}&::placeholder{color:var(--ndt-text-muted)}}.apply-description{margin:0;font-size:11px;color:var(--ndt-text-secondary)}.apply-categories{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs)}.apply-category{background:var(--ndt-background-secondary);border-radius:var(--ndt-border-radius-small);overflow:hidden;transition:opacity .15s ease-out}.apply-category--disabled{opacity:.5}.apply-category__header{display:flex;align-items:center;gap:var(--ndt-spacing-xs);padding:6px var(--ndt-spacing-sm);cursor:pointer;font-size:var(--ndt-font-size-sm);color:var(--ndt-text-primary);font-weight:500;input[type=checkbox]{cursor:pointer;width:14px;height:14px;accent-color:rgb(99,102,241)}}.apply-diff{padding:0 var(--ndt-spacing-sm) 6px;display:flex;flex-direction:column;gap:2px}.diff-item{display:flex;align-items:center;gap:6px;font-size:11px;padding:3px 6px;background:var(--ndt-background-primary);border-radius:3px}.diff-item__name{flex:1;color:var(--ndt-text-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.diff-item__arrow{color:var(--ndt-text-muted);font-size:10px}.diff-item__value{font-weight:600;padding:1px 4px;border-radius:3px;font-size:9px;text-transform:uppercase;letter-spacing:.3px}.diff-item__value--on{background:rgba(var(--ndt-success-rgb),.15);color:var(--ndt-success)}.diff-item__value--off{background:rgba(var(--ndt-danger-rgb),.15);color:var(--ndt-danger)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { onDocumentClick: [{
                type: HostListener,
                args: ['document:click']
            }] } });

class ToolbarComponent {
    constructor() {
        this.document = inject(DOCUMENT);
        this.state = inject(ToolbarStateService);
        this.destroyRef = inject(DestroyRef);
        this.settingsService = inject(SettingsService);
        this.customToolTypes = inject(TOOLBAR_CUSTOM_TOOLS, { optional: true }) ?? [];
        this.customToolsContainer = viewChild('customTools', { read: ViewContainerRef });
        this.config = input({});
        this.keyboardShortcut = fromEvent(window, 'keydown')
            .pipe(filter((event) => event.ctrlKey && event.shiftKey && event.key === 'D'), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.toggleDevTools());
        this.hideShortcut = fromEvent(window, 'keydown')
            .pipe(filter((event) => (event.metaKey || event.ctrlKey) &&
            !event.shiftKey &&
            event.key === '.'), takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            event.preventDefault();
            this.state.toggleCompletelyHidden();
        });
        this.mouseLeave = fromEvent(document, 'mouseleave')
            .pipe(throttleTime(3000), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.onMouseLeave());
        // Update state service when config changes
        effect(() => {
            this.state.setConfig(this.config());
        });
        // Dynamically render registered custom tool components
        effect(() => {
            const container = this.customToolsContainer();
            if (container && container.length === 0 && this.customToolTypes.length > 0) {
                for (const toolType of this.customToolTypes) {
                    container.createComponent(toolType);
                }
            }
        });
    }
    ngOnInit() {
        this.injectGlobalStyles();
        // Always use light theme
        this.state.setTheme('light');
    }
    ngOnDestroy() {
        this.globalStyleElement?.remove();
    }
    onMouseEnter() {
        this.state.setVisibility(true);
    }
    onMouseLeave() {
        setTimeout(() => this.state.setVisibility(false), this.state.delay());
    }
    toggleDevTools() {
        this.state.setVisibility(!this.state.isVisible());
    }
    /**
     * Injects global theme styles into the document head to make CSS variables
     * available to CDK overlays and other elements rendered outside Shadow DOM.
     * Uses light theme only.
     */
    injectGlobalStyles() {
        // Check if styles are already injected (e.g., by another toolbar instance)
        if (this.document.getElementById('ndt-global-theme')) {
            return;
        }
        this.globalStyleElement = this.document.createElement('style');
        this.globalStyleElement.id = 'ndt-global-theme';
        this.globalStyleElement.textContent = `
      /* Global Light Theme for ngx-dev-toolbar overlays */
      :where(ndt-toolbar),
      .ndt-overlay-panel,
      .cdk-overlay-container {
        --ndt-border-radius-small: 4px;
        --ndt-border-radius-medium: 8px;
        --ndt-border-radius-large: 12px;
        --ndt-transition-default: all 0.2s ease-out;
        --ndt-transition-smooth: all 0.2s ease-in-out;
        --ndt-spacing-xs: 4px;
        --ndt-spacing-sm: 6px;
        --ndt-spacing-md: 12px;
        --ndt-spacing-lg: 16px;
        --ndt-window-padding: 16px;
        --ndt-font-size-xxs: 0.65rem;
        --ndt-font-size-xs: 0.75rem;
        --ndt-font-size-sm: 0.875rem;
        --ndt-font-size-md: 1rem;
        --ndt-font-size-lg: 1.25rem;
        --ndt-font-size-xl: 2rem;
        --ndt-primary: #635BFF;
        --ndt-primary-rgb: 99, 91, 255;
        --ndt-text-on-primary: rgb(255, 255, 255);
        --ndt-bg-primary: rgb(255, 255, 255);
        --ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, 0.88) 100%);
        --ndt-text-primary: rgb(17, 24, 39);
        --ndt-text-secondary: rgb(55, 65, 81);
        --ndt-text-muted: rgb(107, 114, 128);
        --ndt-border-primary: #e5e7eb;
        --ndt-border-subtle: rgba(17, 24, 39, 0.1);
        --ndt-hover-bg: rgba(17, 24, 39, 0.05);
        --ndt-hover-danger: rgb(239, 68, 68);
        --ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, 0.2);
        --ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, 0.05), 0 4px 8px rgba(107, 114, 128, 0.15), 0 2px 4px rgba(107, 114, 128, 0.1);
        --ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, 0.1), 0px 1px 2px 0px rgba(156, 163, 175, 0.12), 0px 4px 4px 0px rgba(156, 163, 175, 0.1), 0px 10px 6px 0px rgba(156, 163, 175, 0.08), 0px 17px 7px 0px rgba(156, 163, 175, 0.05), 0px 26px 7px 0px rgba(156, 163, 175, 0.02);
        --ndt-background-secondary: var(--ndt-bg-primary);
        --ndt-background-hover: var(--ndt-hover-bg);
        --ndt-border-color: var(--ndt-border-primary);
        --ndt-tooltip-bg: rgb(17, 24, 39);
        --ndt-tooltip-text: rgb(255, 255, 255);
        --ndt-note-background: rgb(219, 234, 254);
        --ndt-note-border: rgba(37, 99, 235, 0.2);
        --ndt-warning-background: rgb(254, 249, 195);
        --ndt-warning-border: rgba(202, 138, 4, 0.2);
        --ndt-error-background: rgb(254, 226, 226);
        --ndt-error-border: rgba(220, 38, 38, 0.2);
        --ndt-success: rgb(34, 197, 94);
        --ndt-success-rgb: 34, 197, 94;
        --ndt-danger: rgb(239, 68, 68);
        --ndt-danger-rgb: 239, 68, 68;
        --ndt-forced: #f59e0b;
        --ndt-forced-rgb: 245, 158, 11;
      }
      .ndt-overlay-panel {
        font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif;
        box-sizing: border-box;
        isolation: isolate;
        z-index: 999999999;
      }
      .ndt-overlay-panel *, .ndt-overlay-panel *::before, .ndt-overlay-panel *::after {
        box-sizing: border-box;
      }
      .cdk-overlay-backdrop.ndt-overlay-backdrop {
        background: transparent;
      }
    `;
        this.document.head.appendChild(this.globalStyleElement);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarComponent, isStandalone: true, selector: "ndt-toolbar", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "customToolsContainer", first: true, predicate: ["customTools"], descendants: true, read: ViewContainerRef, isSignal: true }], ngImport: i0, template: `
    @if ((config().enabled ?? true) && !state.isCompletelyHidden()) {
      <div
        aria-label="Developer tools"
        role="toolbar"
        class="ndt-toolbar"
        [class.ndt-toolbar--top]="state.position() === 'top'"
        [class.ndt-toolbar--right]="state.position() === 'right'"
        [class.ndt-toolbar--bottom]="state.position() === 'bottom'"
        [class.ndt-toolbar--left]="state.position() === 'left'"
        [class.ndt-toolbar--sidebar-right]="state.position() === 'sidebar-right'"
        [class.ndt-toolbar--sidebar-left]="state.position() === 'sidebar-left'"
        [class.ndt-toolbar--visible]="state.isVisible()"
        [attr.data-theme]="state.theme()"
        (mouseenter)="onMouseEnter()"
      >
        <ndt-home-tool />
        <ng-content />
        <ng-container #customTools />
        @if (config().showI18nTool ?? false) {
          <ndt-i18n-tool />
        }
        @if (config().showPresetsTool ?? false) {
          <ndt-presets-tool />
        }
        @if (config().showAppFeaturesTool ?? false) {
          <ndt-app-features-tool />
        }
        @if (config().showPermissionsTool ?? false) {
          <ndt-permissions-tool />
        }
        @if (config().showFeatureFlagsTool ?? false) {
          <ndt-feature-flags-tool />
        }
      </div>
    }
  `, isInline: true, styles: [":host{display:contents;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\"}.ndt-toolbar{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);position:fixed;z-index:999999;display:flex;pointer-events:auto;background:var(--ndt-bg-primary);border:1px solid var(--ndt-border-primary);border-radius:9999px;box-shadow:var(--ndt-shadow-toolbar);transition:transform .3s cubic-bezier(.4,0,.2,1)}.ndt-toolbar--bottom{bottom:0;left:50%;flex-direction:row;height:30px;padding:0 2px;transform:translate(-50%) translateY(calc(100% - .5rem))}.ndt-toolbar--bottom.ndt-toolbar--visible{transform:translate(-50%) translateY(-10px)}.ndt-toolbar--top{top:0;left:50%;flex-direction:row;height:30px;padding:0 2px;transform:translate(-50%) translateY(calc(-100% + .5rem))}.ndt-toolbar--top.ndt-toolbar--visible{transform:translate(-50%) translateY(10px)}.ndt-toolbar--left{left:0;top:50%;flex-direction:column;width:30px;padding:2px 0;transform:translateY(-50%) translate(calc(-100% + .5rem))}.ndt-toolbar--left.ndt-toolbar--visible{transform:translateY(-50%) translate(10px)}.ndt-toolbar--right{right:0;top:50%;flex-direction:column;width:30px;padding:2px 0;transform:translateY(-50%) translate(calc(100% - .5rem))}.ndt-toolbar--right.ndt-toolbar--visible{transform:translateY(-50%) translate(-10px)}.ndt-toolbar--sidebar-right{right:0;top:16px;flex-direction:column;width:30px;padding:2px 0;transform:translate(calc(100% - .5rem))}.ndt-toolbar--sidebar-right.ndt-toolbar--visible{transform:translate(-10px)}.ndt-toolbar--sidebar-left{left:0;top:16px;flex-direction:column;width:30px;padding:2px 0;transform:translate(calc(-100% + .5rem))}.ndt-toolbar--sidebar-left.ndt-toolbar--visible{transform:translate(10px)}h1,h2,h3,h4,h5{font-weight:600;color:var(--ndt-text-primary);margin:0}h1{font-size:var(--ndt-font-size-xl)}h2{font-size:var(--ndt-font-size-lg)}h3{font-size:var(--ndt-font-size-md)}h4{font-size:var(--ndt-font-size-sm)}h5{font-size:var(--ndt-font-size-xs)}hr{border:1px solid var(--ndt-border-subtle);margin:1em 0}p{line-height:1.5em;margin:0}\n"], dependencies: [{ kind: "component", type: ToolbarHomeToolComponent, selector: "ndt-home-tool", inputs: ["badge"] }, { kind: "component", type: ToolbarI18nToolComponent, selector: "ndt-i18n-tool" }, { kind: "component", type: ToolbarFeatureFlagsToolComponent, selector: "ndt-feature-flags-tool" }, { kind: "component", type: ToolbarAppFeaturesToolComponent, selector: "ndt-app-features-tool" }, { kind: "component", type: ToolbarPermissionsToolComponent, selector: "ndt-permissions-tool" }, { kind: "component", type: ToolbarPresetsToolComponent, selector: "ndt-presets-tool" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.ShadowDom }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'ndt-toolbar', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.ShadowDom, imports: [
                        ToolbarHomeToolComponent,
                        ToolbarI18nToolComponent,
                        ToolbarFeatureFlagsToolComponent,
                        ToolbarAppFeaturesToolComponent,
                        ToolbarPermissionsToolComponent,
                        ToolbarPresetsToolComponent,
                    ], template: `
    @if ((config().enabled ?? true) && !state.isCompletelyHidden()) {
      <div
        aria-label="Developer tools"
        role="toolbar"
        class="ndt-toolbar"
        [class.ndt-toolbar--top]="state.position() === 'top'"
        [class.ndt-toolbar--right]="state.position() === 'right'"
        [class.ndt-toolbar--bottom]="state.position() === 'bottom'"
        [class.ndt-toolbar--left]="state.position() === 'left'"
        [class.ndt-toolbar--sidebar-right]="state.position() === 'sidebar-right'"
        [class.ndt-toolbar--sidebar-left]="state.position() === 'sidebar-left'"
        [class.ndt-toolbar--visible]="state.isVisible()"
        [attr.data-theme]="state.theme()"
        (mouseenter)="onMouseEnter()"
      >
        <ndt-home-tool />
        <ng-content />
        <ng-container #customTools />
        @if (config().showI18nTool ?? false) {
          <ndt-i18n-tool />
        }
        @if (config().showPresetsTool ?? false) {
          <ndt-presets-tool />
        }
        @if (config().showAppFeaturesTool ?? false) {
          <ndt-app-features-tool />
        }
        @if (config().showPermissionsTool ?? false) {
          <ndt-permissions-tool />
        }
        @if (config().showFeatureFlagsTool ?? false) {
          <ndt-feature-flags-tool />
        }
      </div>
    }
  `, styles: [":host{display:contents;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\"}.ndt-toolbar{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);position:fixed;z-index:999999;display:flex;pointer-events:auto;background:var(--ndt-bg-primary);border:1px solid var(--ndt-border-primary);border-radius:9999px;box-shadow:var(--ndt-shadow-toolbar);transition:transform .3s cubic-bezier(.4,0,.2,1)}.ndt-toolbar--bottom{bottom:0;left:50%;flex-direction:row;height:30px;padding:0 2px;transform:translate(-50%) translateY(calc(100% - .5rem))}.ndt-toolbar--bottom.ndt-toolbar--visible{transform:translate(-50%) translateY(-10px)}.ndt-toolbar--top{top:0;left:50%;flex-direction:row;height:30px;padding:0 2px;transform:translate(-50%) translateY(calc(-100% + .5rem))}.ndt-toolbar--top.ndt-toolbar--visible{transform:translate(-50%) translateY(10px)}.ndt-toolbar--left{left:0;top:50%;flex-direction:column;width:30px;padding:2px 0;transform:translateY(-50%) translate(calc(-100% + .5rem))}.ndt-toolbar--left.ndt-toolbar--visible{transform:translateY(-50%) translate(10px)}.ndt-toolbar--right{right:0;top:50%;flex-direction:column;width:30px;padding:2px 0;transform:translateY(-50%) translate(calc(100% - .5rem))}.ndt-toolbar--right.ndt-toolbar--visible{transform:translateY(-50%) translate(-10px)}.ndt-toolbar--sidebar-right{right:0;top:16px;flex-direction:column;width:30px;padding:2px 0;transform:translate(calc(100% - .5rem))}.ndt-toolbar--sidebar-right.ndt-toolbar--visible{transform:translate(-10px)}.ndt-toolbar--sidebar-left{left:0;top:16px;flex-direction:column;width:30px;padding:2px 0;transform:translate(calc(-100% + .5rem))}.ndt-toolbar--sidebar-left.ndt-toolbar--visible{transform:translate(10px)}h1,h2,h3,h4,h5{font-weight:600;color:var(--ndt-text-primary);margin:0}h1{font-size:var(--ndt-font-size-xl)}h2{font-size:var(--ndt-font-size-lg)}h3{font-size:var(--ndt-font-size-md)}h4{font-size:var(--ndt-font-size-sm)}h5{font-size:var(--ndt-font-size-xs)}hr{border:1px solid var(--ndt-border-subtle);margin:1em 0}p{line-height:1.5em;margin:0}\n"] }]
        }], ctorParameters: () => [] });

class ToolbarFeatureFlagService {
    constructor() {
        this.internalService = inject(ToolbarInternalFeatureFlagService);
    }
    /**
     * Sets the available flags that will be displayed in the tool on the dev toolbar
     * @param flags The flags to be displayed
     */
    setAvailableOptions(flags) {
        this.internalService.setAppFlags(flags);
    }
    /**
     * Gets the flags that were forced/modified through the tool on the dev toolbar
     * @returns Observable of forced flags array
     */
    getForcedValues() {
        return this.internalService.getForcedFlags();
    }
    /**
     * Gets ALL flag values with overrides already applied.
     * Returns the complete set of flags where overridden values replace base values.
     * Each flag includes an `isForced` property indicating if it was overridden.
     *
     * This method simplifies integration by eliminating the need to manually merge
     * base flags with overrides using combineLatest.
     *
     * @returns Observable of all flags with overrides applied
     *
     * @example
     * ```typescript
     * // Get a specific flag value with overrides applied
     * this.featureFlagsService.getValues().pipe(
     *   map(flags => flags.find(f => f.id === 'newFeature')),
     *   map(flag => flag?.isEnabled ?? false)
     * ).subscribe(isEnabled => {
     *   if (isEnabled) {
     *     // Enable feature
     *   }
     * });
     * ```
     */
    getValues() {
        return this.internalService.flags$;
    }
    /**
     * Registers a callback to persist a forced flag value back to the actual data source.
     * When set, an "apply to source" button appears on each forced flag in the toolbar UI.
     *
     * @param callback - Async function that receives the flag ID and its forced boolean value
     */
    setApplyToSource(callback) {
        this.internalService.setApplyToSource(callback);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarFeatureFlagService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarFeatureFlagService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarFeatureFlagService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Public service for integrating the Permissions Tool with your application.
 * Use this service to:
 * 1. Register your application's permissions with setAvailableOptions()
 * 2. Listen for toolbar permission overrides with getForcedValues()
 * 3. Apply preset permission states for testing with applyPreset()
 *
 * @example
 * ```typescript
 * constructor(private permissionsService: ToolbarPermissionsService) {
 *   // Register permissions
 *   this.permissionsService.setAvailableOptions([
 *     { id: 'can-edit', name: 'Can Edit', isGranted: false, isForced: false }
 *   ]);
 *
 *   // Listen for overrides
 *   this.permissionsService.getForcedValues().subscribe(forcedPermissions => {
 *     // Update your app's permission state
 *   });
 * }
 * ```
 */
class ToolbarPermissionsService {
    constructor() {
        this.internalService = inject(ToolbarInternalPermissionsService);
    }
    /**
     * Sets the available permissions that will be displayed in the toolbar tool.
     * Call this in your app initialization to register permissions.
     *
     * @param permissions Array of permissions to display in the toolbar
     *
     * @example
     * ```typescript
     * this.permissionsService.setAvailableOptions([
     *   {
     *     id: 'can-edit-posts',
     *     name: 'Edit Posts',
     *     description: 'Can edit blog posts',
     *     isGranted: false,
     *     isForced: false
     *   }
     * ]);
     * ```
     */
    setAvailableOptions(permissions) {
        this.internalService.setAppPermissions(permissions);
    }
    /**
     * Gets an observable of permissions that were forced/overridden through the toolbar.
     * Subscribe to this to update your application's permission state.
     *
     * @returns Observable emitting array of forced permissions whenever changes occur
     *
     * @example
     * ```typescript
     * this.permissionsService.getForcedValues().subscribe(forcedPermissions => {
     *   forcedPermissions.forEach(permission => {
     *     this.updatePermission(permission.id, permission.isGranted);
     *   });
     * });
     * ```
     */
    getForcedValues() {
        return this.internalService.getForcedPermissions();
    }
    /**
     * Gets ALL permission values with overrides already applied.
     * Returns the complete set of permissions where overridden values replace base values.
     * Each permission includes an `isForced` property indicating if it was overridden.
     *
     * This method simplifies integration by eliminating the need to manually merge
     * base permissions with overrides using combineLatest.
     *
     * @returns Observable of all permissions with overrides applied
     *
     * @example
     * ```typescript
     * // Simple permission check with overrides applied
     * this.permissionsService.getValues().pipe(
     *   map(permissions => permissions.find(p => p.id === 'can-edit')),
     *   map(permission => permission?.isGranted ?? false)
     * ).subscribe(canEdit => {
     *   if (canEdit) {
     *     // Enable edit functionality
     *   }
     * });
     * ```
     */
    getValues() {
        return this.internalService.permissions$;
    }
    /**
     * Apply a preset permission state. Useful for automated testing scenarios.
     *
     * @param state The forced permissions state to apply
     *
     * @example
     * ```typescript
     * this.permissionsService.applyPreset({
     *   granted: ['can-edit-posts'],
     *   denied: ['can-delete-posts']
     * });
     * ```
     */
    applyPreset(state) {
        this.internalService.applyPresetPermissions(state);
    }
    /**
     * Get the current forced permission state.
     *
     * @returns Current forced permissions state
     */
    getCurrentState() {
        return this.internalService.getCurrentForcedState();
    }
    /**
     * Registers a callback to persist a forced permission value back to the actual data source.
     * When set, an "apply to source" button appears on each forced permission in the toolbar UI.
     *
     * @param callback - Async function that receives the permission ID and its forced boolean value
     */
    setApplyToSource(callback) {
        this.internalService.setApplyToSource(callback);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarPermissionsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarPermissionsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarPermissionsService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Public service for managing app features in the dev toolbar.
 *
 * This service implements the ToolbarService interface and provides methods for:
 * - Configuring available product features
 * - Retrieving forced feature overrides
 * - Applying preset feature configurations
 * - Exporting current forced state for presets
 *
 * @example
 * ```typescript
 * import { ToolbarAppFeaturesService } from 'ngx-dev-toolbar';
 *
 * @Component({...})
 * export class AppComponent implements OnInit {
 *   private appFeaturesService = inject(ToolbarAppFeaturesService);
 *
 *   ngOnInit() {
 *     // Configure available features based on current tier
 *     const features: ToolbarAppFeature[] = [
 *       { id: 'analytics', name: 'Analytics Dashboard', isEnabled: true, isForced: false },
 *       { id: 'multi-user', name: 'Multi-User Support', isEnabled: false, isForced: false }
 *     ];
 *     this.appFeaturesService.setAvailableOptions(features);
 *
 *     // Subscribe to forced overrides
 *     this.appFeaturesService.getForcedValues().subscribe(forcedFeatures => {
 *       forcedFeatures.forEach(feature => {
 *         // Apply forced feature state to application logic
 *         this.applyFeatureState(feature.id, feature.isEnabled);
 *       });
 *     });
 *   }
 * }
 * ```
 */
class ToolbarAppFeaturesService {
    constructor() {
        this.internalService = inject(ToolbarInternalAppFeaturesService);
    }
    /**
     * Set available app features for the application.
     *
     * Configures the list of product features that can be toggled in the dev toolbar.
     * Features should represent product-level capabilities like license tiers,
     * deployment configurations, or environment flags.
     *
     * @param features - Array of app features to display in the toolbar
     * @throws Error if duplicate feature IDs or empty IDs are detected
     *
     * @example
     * ```typescript
     * const features: ToolbarAppFeature[] = [
     *   {
     *     id: 'advanced-analytics',
     *     name: 'Advanced Analytics Dashboard',
     *     description: 'Access premium reporting and data visualization',
     *     isEnabled: false,  // Not available in current tier
     *     isForced: false
     *   },
     *   {
     *     id: 'multi-user-support',
     *     name: 'Multi-User Collaboration',
     *     description: 'Enable team features and user management',
     *     isEnabled: true,   // Available in current tier
     *     isForced: false
     *   }
     * ];
     * this.appFeaturesService.setAvailableOptions(features);
     * ```
     */
    setAvailableOptions(features) {
        this.internalService.setAppFeatures(features);
    }
    /**
     * Get observable stream of features that have forced overrides.
     *
     * Emits an array of features that have been forced via the dev toolbar.
     * Only features with `isForced = true` are included in the emissions.
     * Use this to react to feature override changes and update application behavior.
     *
     * @returns Observable that emits array of forced features whenever state changes
     *
     * @example
     * ```typescript
     * this.appFeaturesService.getForcedValues()
     *   .pipe(takeUntilDestroyed())
     *   .subscribe(forcedFeatures => {
     *     forcedFeatures.forEach(feature => {
     *       if (feature.isEnabled) {
     *         this.enableFeature(feature.id);
     *       } else {
     *         this.disableFeature(feature.id);
     *       }
     *     });
     *   });
     * ```
     */
    getForcedValues() {
        return this.internalService.getForcedFeatures();
    }
    /**
     * Gets ALL app feature values with overrides already applied.
     * Returns the complete set of features where overridden values replace base values.
     * Each feature includes an `isForced` property indicating if it was overridden.
     *
     * This method simplifies integration by eliminating the need to manually merge
     * base features with overrides using combineLatest.
     *
     * @returns Observable of all features with overrides applied
     *
     * @example
     * ```typescript
     * // Check if a feature is enabled with overrides applied
     * this.appFeaturesService.getValues().pipe(
     *   map(features => features.find(f => f.id === 'premium-analytics')),
     *   map(feature => feature?.isEnabled ?? false)
     * ).subscribe(isEnabled => {
     *   if (isEnabled) {
     *     // Enable premium analytics
     *   }
     * });
     * ```
     */
    getValues() {
        return this.internalService.features$;
    }
    /**
     * Apply a preset feature configuration (for preset tool integration).
     *
     * Accepts a forced features state object and applies it to the current configuration.
     * Invalid feature IDs (not in configured features) are filtered out with a warning.
     *
     * @param state - Forced features state containing enabled/disabled arrays
     *
     * @example
     * ```typescript
     * // Apply "Enterprise Tier" preset
     * const enterprisePreset: ForcedAppFeaturesState = {
     *   enabled: ['analytics', 'multi-user', 'white-label', 'sso'],
     *   disabled: []
     * };
     * this.appFeaturesService.applyPresetFeatures(enterprisePreset);
     *
     * // Apply "Basic Tier" preset
     * const basicPreset: ForcedAppFeaturesState = {
     *   enabled: [],
     *   disabled: ['analytics', 'multi-user', 'white-label', 'sso']
     * };
     * this.appFeaturesService.applyPresetFeatures(basicPreset);
     * ```
     */
    applyPresetFeatures(state) {
        this.internalService.applyForcedState(state);
    }
    /**
     * Get current forced feature state as a snapshot (for preset export).
     *
     * Returns the current forced features state with enabled/disabled arrays.
     * Useful for exporting toolbar state to save as a preset or for debugging.
     * Returns a defensive copy - mutations will not affect internal state.
     *
     * @returns Current forced features state
     *
     * @example
     * ```typescript
     * // Export current toolbar state to save as preset
     * const currentState = this.appFeaturesService.getCurrentForcedState();
     * this.presetsService.savePreset('my-config', {
     *   appFeatures: currentState,
     *   // ... other tool states
     * });
     *
     * console.log(currentState);
     * // { enabled: ['analytics'], disabled: ['white-label'] }
     * ```
     */
    getCurrentForcedState() {
        return this.internalService.getCurrentForcedState();
    }
    /**
     * Registers a callback to persist a forced app feature value back to the actual data source.
     * When set, an "apply to source" button appears on each forced feature in the toolbar UI.
     *
     * @param callback - Async function that receives the feature ID and its forced boolean value
     */
    setApplyToSource(callback) {
        this.internalService.setApplyToSource(callback);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarAppFeaturesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarAppFeaturesService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarAppFeaturesService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Provides all ngx-dev-toolbar services and automatically attaches the toolbar to the DOM.
 *
 * This is the recommended way to set up the toolbar. Add it to your `app.config.ts`
 * alongside other providers like `provideRouter()` and `provideHttpClient()`.
 *
 * ## Basic Usage
 *
 * ```typescript
 * // app.config.ts
 * import { ApplicationConfig, isDevMode } from '@angular/core';
 * import { provideToolbar } from 'ngx-dev-toolbar';
 *
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideRouter(appRoutes),
 *     provideToolbar({
 *       enabled: isDevMode(),
 *       showFeatureFlagsTool: true,
 *       showPermissionsTool: true,
 *     }),
 *   ],
 * };
 * ```
 *
 * ```typescript
 * // main.ts
 * bootstrapApplication(AppComponent, appConfig);
 * ```
 *
 * ## Using Services with Tokens
 *
 * ```typescript
 * import { inject } from '@angular/core';
 * import { TOOLBAR_FEATURE_FLAGS } from 'ngx-dev-toolbar';
 * import type { ToolbarService, ToolbarFlag } from 'ngx-dev-toolbar';
 *
 * @Injectable({ providedIn: 'root' })
 * export class FeatureFlagsService {
 *   // Optional injection - null in production
 *   private devToolbar = inject<ToolbarService<ToolbarFlag>>(
 *     TOOLBAR_FEATURE_FLAGS,
 *     { optional: true }
 *   );
 *
 *   constructor() {
 *     // Safe to call - no-op if devToolbar is null
 *     this.devToolbar?.setAvailableOptions(this.flags);
 *
 *     // Subscribe to forced values only if toolbar exists
 *     this.devToolbar?.getForcedValues().subscribe(forced => {
 *       // Merge forced values
 *     });
 *   }
 * }
 * ```
 *
 * @param config - Optional configuration for toolbar behavior and tool visibility
 * @returns Angular EnvironmentProviders for all toolbar services
 */
function provideToolbar(config) {
    const { customTools, ...configWithoutTools } = config ?? {};
    return makeEnvironmentProviders([
        { provide: TOOLBAR_FEATURE_FLAGS, useClass: ToolbarFeatureFlagService },
        { provide: TOOLBAR_PERMISSIONS, useClass: ToolbarPermissionsService },
        { provide: TOOLBAR_APP_FEATURES, useClass: ToolbarAppFeaturesService },
        { provide: TOOLBAR_CONFIG, useValue: configWithoutTools },
        { provide: TOOLBAR_CUSTOM_TOOLS, useValue: customTools ?? [] },
        {
            provide: ENVIRONMENT_INITIALIZER,
            multi: true,
            useValue: () => {
                const appRef = inject(ApplicationRef);
                const injector = inject(EnvironmentInjector);
                const toolbarConfig = inject(TOOLBAR_CONFIG);
                // Bridge deprecated config callbacks to service-based setApplyToSource
                if (toolbarConfig.onApplyFeatureFlag) {
                    console.warn('[ngx-dev-toolbar] onApplyFeatureFlag in config is deprecated. Use ToolbarFeatureFlagService.setApplyToSource() instead.');
                    inject(ToolbarInternalFeatureFlagService).setApplyToSource(toolbarConfig.onApplyFeatureFlag);
                }
                if (toolbarConfig.onApplyPermission) {
                    console.warn('[ngx-dev-toolbar] onApplyPermission in config is deprecated. Use ToolbarPermissionsService.setApplyToSource() instead.');
                    inject(ToolbarInternalPermissionsService).setApplyToSource(toolbarConfig.onApplyPermission);
                }
                if (toolbarConfig.onApplyAppFeature) {
                    console.warn('[ngx-dev-toolbar] onApplyAppFeature in config is deprecated. Use ToolbarAppFeaturesService.setApplyToSource() instead.');
                    inject(ToolbarInternalAppFeaturesService).setApplyToSource(toolbarConfig.onApplyAppFeature);
                }
                const componentRef = createComponent(ToolbarComponent, {
                    environmentInjector: injector,
                });
                componentRef.setInput('config', toolbarConfig);
                document.body.appendChild(componentRef.location.nativeElement);
                appRef.attachView(componentRef.hostView);
            },
        },
    ]);
}

class ToolbarCardComponent {
    constructor() {
        this.click = signal(undefined);
        this.isHovered = signal(false);
    }
    onClick() {
        this.click.set();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.0.7", type: ToolbarCardComponent, isStandalone: true, selector: "ndt-card", ngImport: i0, template: `
    <div
      class="card"
      role="button"
      tabindex="0"
      (click)="onClick()"
      (keydown.enter)="onClick()"
      (keydown.space)="onClick()"
      [class.card--hover]="isHovered()"
      (mouseenter)="isHovered.set(true)"
      (mouseleave)="isHovered.set(false)"
    >
      <ng-content></ng-content>
    </div>
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.card{background:var(--ndt-bg-primary);border-radius:var(--ndt-border-radius-large);padding:var(--ndt-spacing-md);cursor:pointer;transition:var(--ndt-transition-default);border:1px solid var(--ndt-border-subtle);position:relative;flex:1;height:120px;display:flex}.card:hover{background:var(--ndt-hover-bg);border-color:var(--ndt-primary);box-shadow:0 0 0 1px rgba(var(--ndt-primary-rgb),.3)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-card', standalone: true, template: `
    <div
      class="card"
      role="button"
      tabindex="0"
      (click)="onClick()"
      (keydown.enter)="onClick()"
      (keydown.space)="onClick()"
      [class.card--hover]="isHovered()"
      (mouseenter)="isHovered.set(true)"
      (mouseleave)="isHovered.set(false)"
    >
      <ng-content></ng-content>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.card{background:var(--ndt-bg-primary);border-radius:var(--ndt-border-radius-large);padding:var(--ndt-spacing-md);cursor:pointer;transition:var(--ndt-transition-default);border:1px solid var(--ndt-border-subtle);position:relative;flex:1;height:120px;display:flex}.card:hover{background:var(--ndt-hover-bg);border-color:var(--ndt-primary);box-shadow:0 0 0 1px rgba(var(--ndt-primary-rgb),.3)}\n"] }]
        }] });

class ToolbarClickableCardComponent {
    constructor() {
        this.icon = input.required();
        this.title = input.required();
        this.subtitle = input.required();
        this.click = signal(undefined);
    }
    onClick() {
        this.click.set();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarClickableCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.0.7", type: ToolbarClickableCardComponent, isStandalone: true, selector: "ndt-clickable-card", inputs: { icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: true, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    <ndt-card (clicked)="onClick()">
      <div class="clickable-card">
        <div class="clickable-card__icon">
          <ndt-icon [name]="icon()" />
        </div>
        <div class="clickable-card__content">
          <div class="clickable-card__title">{{ title() }}</div>
          <div class="clickable-card__subtitle">{{ subtitle() }}</div>
        </div>
      </div>
    </ndt-card>
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.clickable-card{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);height:100%}.clickable-card__icon{display:flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:var(--ndt-border-radius-medium);background:var(--ndt-hover-bg);color:var(--ndt-text-primary)}.clickable-card__content{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs)}.clickable-card__title{color:var(--ndt-text-primary);font-size:var(--ndt-font-size-sm);font-weight:500}.clickable-card__subtitle{color:var(--ndt-text-muted);font-size:var(--ndt-font-size-xs);line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}\n"], dependencies: [{ kind: "component", type: ToolbarCardComponent, selector: "ndt-card" }, { kind: "component", type: ToolbarIconComponent, selector: "ndt-icon", inputs: ["name"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarClickableCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-clickable-card', standalone: true, imports: [ToolbarCardComponent, ToolbarIconComponent], template: `
    <ndt-card (clicked)="onClick()">
      <div class="clickable-card">
        <div class="clickable-card__icon">
          <ndt-icon [name]="icon()" />
        </div>
        <div class="clickable-card__content">
          <div class="clickable-card__title">{{ title() }}</div>
          <div class="clickable-card__subtitle">{{ subtitle() }}</div>
        </div>
      </div>
    </ndt-card>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2)}.clickable-card{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs);height:100%}.clickable-card__icon{display:flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:var(--ndt-border-radius-medium);background:var(--ndt-hover-bg);color:var(--ndt-text-primary)}.clickable-card__content{display:flex;flex-direction:column;gap:var(--ndt-spacing-xs)}.clickable-card__title{color:var(--ndt-text-primary);font-size:var(--ndt-font-size-sm);font-weight:500}.clickable-card__subtitle{color:var(--ndt-text-muted);font-size:var(--ndt-font-size-xs);line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}\n"] }]
        }] });

class ToolbarStepDirective {
    constructor() {
        this.ndtStep = input.required();
        this.stepTitle = input('');
        this.templateRef = inject(TemplateRef);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStepDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.0.7", type: ToolbarStepDirective, isStandalone: true, selector: "[ndtStep]", inputs: { ndtStep: { classPropertyName: "ndtStep", publicName: "ndtStep", isSignal: true, isRequired: true, transformFunction: null }, stepTitle: { classPropertyName: "stepTitle", publicName: "stepTitle", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStepDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ndtStep]',
                    standalone: true,
                }]
        }] });

class ToolbarStepViewComponent {
    constructor() {
        this.currentStep = input.required();
        this.defaultStep = input('list');
        this.back = output();
        this.steps = contentChildren(ToolbarStepDirective);
        this.isDefaultStep = computed(() => this.currentStep() === this.defaultStep());
        this.activeStep = computed(() => this.steps().find((s) => s.ndtStep() === this.currentStep()));
        this.activeTitle = computed(() => this.activeStep()?.stepTitle() ?? '');
        this.activeTemplate = computed(() => this.activeStep()?.templateRef ?? null);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStepViewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarStepViewComponent, isStandalone: true, selector: "ndt-step-view", inputs: { currentStep: { classPropertyName: "currentStep", publicName: "currentStep", isSignal: true, isRequired: true, transformFunction: null }, defaultStep: { classPropertyName: "defaultStep", publicName: "defaultStep", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { back: "back" }, queries: [{ propertyName: "steps", predicate: ToolbarStepDirective, isSignal: true }], ngImport: i0, template: `
    @if (!isDefaultStep()) {
      <div class="step-header">
        <ndt-button (click)="back.emit()" ariaLabel="Back">\u2190 Back</ndt-button>
        @if (activeTitle()) {
          <span class="step-title">{{ activeTitle() }}</span>
        }
      </div>
    }

    @if (activeTemplate(); as tmpl) {
      <ng-container [ngTemplateOutlet]="tmpl" />
    }
  `, isInline: true, styles: [":host{display:flex;flex-direction:column}.step-header{display:flex;align-items:center;gap:var(--ndt-spacing-sm);padding-bottom:var(--ndt-spacing-sm);margin-bottom:var(--ndt-spacing-sm);border-bottom:1px solid var(--ndt-border-primary)}.step-title{font-size:var(--ndt-font-size-md);font-weight:600;color:var(--ndt-text-primary)}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: ToolbarButtonComponent, selector: "ndt-button", inputs: ["type", "variant", "icon", "label", "ariaLabel", "isActive", "disabled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStepViewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-step-view', standalone: true, imports: [NgTemplateOutlet, ToolbarButtonComponent], template: `
    @if (!isDefaultStep()) {
      <div class="step-header">
        <ndt-button (click)="back.emit()" ariaLabel="Back">\u2190 Back</ndt-button>
        @if (activeTitle()) {
          <span class="step-title">{{ activeTitle() }}</span>
        }
      </div>
    }

    @if (activeTemplate(); as tmpl) {
      <ng-container [ngTemplateOutlet]="tmpl" />
    }
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:flex;flex-direction:column}.step-header{display:flex;align-items:center;gap:var(--ndt-spacing-sm);padding-bottom:var(--ndt-spacing-sm);margin-bottom:var(--ndt-spacing-sm);border-bottom:1px solid var(--ndt-border-primary)}.step-title{font-size:var(--ndt-font-size-md);font-weight:600;color:var(--ndt-text-primary)}\n"] }]
        }] });

function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}
function nounSingular(plural) {
    return plural.replace(/ies$/, 'y').replace(/s$/, '');
}

const DEFAULT_PACING = {
    stagger: 60,
    stepGap: 200,
};
const DEFAULT_VERB_ACTIVE = 'Creating';
const DEFAULT_VERB_DONE = 'Created';
const ITEM_RENDER_WINDOW = 6; // show last 6 items in the running step + currently active
class ToolbarStreamRunnerComponent {
    constructor() {
        this.done = output();
        this.errored = output();
        this._records = signal([]);
        this._visibleCount = signal(0);
        this._title = signal('');
        this._preamble = signal(undefined);
        this._summary = signal(undefined);
        this._isRunning = signal(false);
        this._hasRun = signal(false);
        this._cancelled = signal(false);
        this.title = this._title.asReadonly();
        this.preamble = this._preamble.asReadonly();
        this.summary = this._summary.asReadonly();
        this.isIdle = computed(() => !this._hasRun() && !this._isRunning());
        this.isRunning = this._isRunning.asReadonly();
        this.visibleRecords = computed(() => this._records().slice(0, this._visibleCount()));
    }
    prefersReducedMotion() {
        return typeof window !== 'undefined'
            && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches === true;
    }
    /** Imperative entry point: kicks off a streaming run. */
    async start(options) {
        if (this._isRunning()) {
            throw new Error('A run is already in progress');
        }
        const { title, preamble, steps } = options;
        const pacing = { ...DEFAULT_PACING, ...options.pacing };
        const reduceMotion = this.prefersReducedMotion();
        this._cancelled.set(false);
        this._title.set(title);
        this._preamble.set(preamble);
        this._summary.set(undefined);
        this._isRunning.set(true);
        this._hasRun.set(true);
        const records = steps.map((step, index) => ({
            index,
            step,
            status: 'queued',
            items: Array.from({ length: step.total }, (_, i) => ({
                index: i,
                status: 'queued',
            })),
            expanded: false,
            doneCount: 0,
            errorCount: 0,
        }));
        this._records.set(records);
        // All steps visible immediately. Per-step entry stagger is done in CSS
        // (animation-delay on nth-child) so it doesn't block the first runItem.
        this._visibleCount.set(records.length);
        // Per-run cache so ctx.prior() is O(1) per call (NFR001). Each successful
        // runItem appends to priorCache.get(stepIndex); prior() reads with a single
        // Map lookup. labelToIndex resolves string keys without scanning records.
        const priorCache = new Map();
        const labelToIndex = new Map();
        records.forEach((r) => {
            priorCache.set(r.index, []);
            labelToIndex.set(r.step.label, r.index);
        });
        const ctx = {
            prior: (key) => {
                const idx = typeof key === 'number' ? key : labelToIndex.get(key);
                return idx === undefined ? [] : (priorCache.get(idx) ?? []);
            },
        };
        const startedAt = performance.now();
        let totalItems = 0;
        let totalErrors = 0;
        for (let stepIndex = 0; stepIndex < records.length; stepIndex++) {
            if (this.isCancelled())
                break;
            this.updateRecord(stepIndex, { status: 'running' });
            this.scrollToActive();
            const step = records[stepIndex].step;
            for (let itemIndex = 0; itemIndex < step.total; itemIndex++) {
                if (this.isCancelled())
                    break;
                this.updateItem(stepIndex, itemIndex, { status: 'running' });
                try {
                    const value = await step.runItem(itemIndex, ctx);
                    this.updateItem(stepIndex, itemIndex, {
                        status: 'done',
                        value,
                        label: step.describe?.(value) ?? `${nounSingular(step.label)} ${itemIndex + 1}`,
                        detail: step.detail?.(value),
                        href: step.link?.(value),
                    });
                    priorCache.get(stepIndex).push(value);
                    totalItems++;
                }
                catch (err) {
                    const message = err instanceof Error ? err.message : String(err);
                    this.updateItem(stepIndex, itemIndex, { status: 'error', error: message });
                    totalErrors++;
                    this.errored.emit({ stepIndex, itemIndex, error: message });
                }
            }
            // Step-level status: error only if everything failed; otherwise done.
            const finalRecord = this._records()[stepIndex];
            const allFailed = finalRecord.errorCount === finalRecord.items.length;
            this.updateRecord(stepIndex, {
                status: allFailed ? 'error' : 'done',
                error: allFailed ? `Failed to create any ${step.label.toLowerCase()}` : undefined,
            });
            if (!reduceMotion && stepIndex < records.length - 1) {
                await wait(pacing.stepGap);
            }
        }
        // If cancelled mid-run, skip the summary + done event entirely.
        if (this.isCancelled()) {
            this._isRunning.set(false);
            return { totalItems, totalSteps: records.length, errorCount: totalErrors, durationMs: 0 };
        }
        const durationMs = Math.round(performance.now() - startedAt);
        const result = {
            totalItems,
            totalSteps: records.length,
            errorCount: totalErrors,
            durationMs,
        };
        const errorSuffix = totalErrors > 0 ? ` (${totalErrors} failed)` : '';
        this._summary.set(`Generated ${totalItems} ${totalItems === 1 ? 'entity' : 'entities'} across ${records.length} ${records.length === 1 ? 'type' : 'types'} in ${(durationMs / 1000).toFixed(2)}s${errorSuffix}.`);
        this._isRunning.set(false);
        this.done.emit(result);
        return result;
    }
    /** Reset to the empty/idle state. Also cancels any in-flight run. */
    reset() {
        this._cancelled.set(true);
        this._records.set([]);
        this._visibleCount.set(0);
        this._title.set('');
        this._preamble.set(undefined);
        this._summary.set(undefined);
        this._hasRun.set(false);
    }
    isCancelled() {
        return this._cancelled();
    }
    toggleExpanded(record) {
        if (record.status !== 'done' && record.status !== 'error')
            return;
        this.updateRecord(record.index, { expanded: !record.expanded });
    }
    canExpand(record) {
        return (record.status === 'done' || record.status === 'error')
            && record.items.some((it) => it.status !== 'queued');
    }
    stepVerb(record) {
        const active = record.step.verbActive ?? DEFAULT_VERB_ACTIVE;
        const past = record.step.verbDone ?? DEFAULT_VERB_DONE;
        if (record.status === 'queued')
            return '';
        if (record.status === 'running')
            return active;
        if (record.status === 'error')
            return `Failed`;
        return past;
    }
    stepNoun(record) {
        const lower = record.step.label.toLowerCase();
        const total = record.step.total;
        const { doneCount, errorCount } = record;
        if (record.status === 'queued') {
            return `${total} ${lower}`;
        }
        if (record.status === 'running') {
            const inFlight = doneCount + errorCount;
            return inFlight > 0
                ? `${inFlight} of ${total} ${lower}`
                : `${total} ${lower}…`;
        }
        if (record.status === 'error') {
            return `to create ${total} ${lower}`;
        }
        if (errorCount > 0) {
            return `${doneCount} of ${total} ${lower} (${errorCount} failed)`;
        }
        return `${doneCount} ${lower}`;
    }
    itemVerb(record, item) {
        const active = record.step.verbActive ?? DEFAULT_VERB_ACTIVE;
        const past = record.step.verbDone ?? DEFAULT_VERB_DONE;
        switch (item.status) {
            case 'running': return active;
            case 'done': return past;
            case 'error': return 'Failed';
            default: return active;
        }
    }
    itemName(record, item) {
        if (item.label)
            return item.label;
        return `${nounSingular(record.step.label)} ${item.index + 1}`;
    }
    itemDetail(record, item) {
        if (item.status === 'done')
            return item.detail ?? null;
        if (item.status === 'error')
            return item.error ?? 'Failed';
        if (item.status === 'running')
            return record.step.placeholderDetail ?? 'Working…';
        return null;
    }
    shouldShowItems(record) {
        if (record.status === 'queued')
            return false;
        if (record.status === 'running')
            return true;
        return record.expanded;
    }
    visibleItems(record) {
        const nonQueued = record.items.filter((it) => it.status !== 'queued');
        if (record.status === 'running') {
            // Sliding window: show the most recent N items
            return nonQueued.slice(-ITEM_RENDER_WINDOW);
        }
        return nonQueued; // expanded final view shows all
    }
    hiddenItemCount(record) {
        if (record.status !== 'running')
            return 0;
        const nonQueued = record.items.filter((it) => it.status !== 'queued').length;
        return Math.max(0, nonQueued - ITEM_RENDER_WINDOW);
    }
    updateRecord(index, patch) {
        this._records.update((records) => records.map((r) => (r.index === index ? { ...r, ...patch } : r)));
    }
    updateItem(stepIndex, itemIndex, patch) {
        this._records.update((records) => records.map((r) => {
            if (r.index !== stepIndex)
                return r;
            const prev = r.items[itemIndex];
            const next = { ...prev, ...patch };
            const wasFinal = prev.status === 'done' || prev.status === 'error';
            const isDone = next.status === 'done' && !wasFinal;
            const isError = next.status === 'error' && !wasFinal;
            return {
                ...r,
                items: r.items.map((it) => (it.index === itemIndex ? next : it)),
                doneCount: r.doneCount + (isDone ? 1 : 0),
                errorCount: r.errorCount + (isError ? 1 : 0),
            };
        }));
    }
    scrollToActive() {
        if (this.prefersReducedMotion())
            return;
        queueMicrotask(() => {
            this.anchor?.nativeElement.scrollIntoView({
                behavior: 'smooth',
                block: 'end',
            });
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStreamRunnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarStreamRunnerComponent, isStandalone: true, selector: "ndt-stream-runner", outputs: { done: "done", errored: "errored" }, viewQueries: [{ propertyName: "anchor", first: true, predicate: ["anchor"], descendants: true }], ngImport: i0, template: `
    @if (isIdle()) {
      <div class="ndt-stream__empty">
        <ng-content></ng-content>
      </div>
    } @else {
      <div class="ndt-stream" role="log" aria-live="polite">
        <div class="ndt-stream__header">
          <span class="ndt-stream__glyph ndt-stream__glyph--sparkle" aria-hidden="true">
            <svg viewBox="0 0 16 16" width="14" height="14">
              <path d="M8 1.5l1.4 3.6L13 6.5l-3.6 1.4L8 11.5 6.6 7.9 3 6.5l3.6-1.4L8 1.5z M12 10l.6 1.6L14 12.2l-1.4.6L12 14.4l-.6-1.6L10 12.2l1.4-.6L12 10z" fill="currentColor"/>
            </svg>
          </span>
          <div class="ndt-stream__header-text">
            <h3 class="ndt-stream__title">{{ title() }}</h3>
            @if (preamble()) {
              <p class="ndt-stream__preamble">{{ preamble() }}</p>
            }
          </div>
        </div>

        <ol class="ndt-stream__steps">
          @for (record of visibleRecords(); track record.index) {
            <li
              class="ndt-stream__step"
              [class.ndt-stream__step--queued]="record.status === 'queued'"
              [class.ndt-stream__step--running]="record.status === 'running'"
              [class.ndt-stream__step--done]="record.status === 'done'"
              [class.ndt-stream__step--error]="record.status === 'error'"
              [class.ndt-stream__step--expanded]="record.expanded"
            >
              <div class="ndt-stream__step-row">
                <span class="ndt-stream__glyph" aria-hidden="true">
                  @switch (record.status) {
                    @case ('queued') {
                      <svg viewBox="0 0 16 16" width="14" height="14">
                        <circle cx="8" cy="8" r="5" fill="none" stroke="currentColor" stroke-width="1.5"/>
                      </svg>
                    }
                    @case ('running') {
                      <svg viewBox="0 0 16 16" width="14" height="14" class="ndt-stream__pulse">
                        <circle cx="8" cy="8" r="6" fill="currentColor"/>
                        <path d="M8 2a6 6 0 0 1 0 12" fill="none" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
                      </svg>
                    }
                    @case ('done') {
                      <svg viewBox="0 0 16 16" width="14" height="14">
                        <circle cx="8" cy="8" r="6" fill="currentColor"/>
                        <path d="M5 8.2 7 10.2 11 6" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                      </svg>
                    }
                    @case ('error') {
                      <svg viewBox="0 0 16 16" width="14" height="14">
                        <circle cx="8" cy="8" r="6" fill="currentColor"/>
                        <path d="M6 6 10 10 M10 6 6 10" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
                      </svg>
                    }
                  }
                </span>

                <button
                  type="button"
                  class="ndt-stream__label-btn"
                  [disabled]="record.status === 'queued' || record.status === 'running'"
                  [attr.aria-expanded]="(record.status === 'done' || record.status === 'error') ? record.expanded : null"
                  (click)="toggleExpanded(record)"
                >
                  <span class="ndt-stream__verb">{{ stepVerb(record) }}</span>
                  <span class="ndt-stream__noun">{{ stepNoun(record) }}</span>
                  @if (canExpand(record)) {
                    <span
                      class="ndt-stream__chevron"
                      [class.ndt-stream__chevron--open]="record.expanded"
                      aria-hidden="true"
                    >
                      <svg viewBox="0 0 12 12" width="10" height="10">
                        <path d="M3 4.5 6 7.5 9 4.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                    </span>
                  }
                </button>
              </div>

              @if (record.step.description) {
                <p class="ndt-stream__step-description">{{ record.step.description }}</p>
              }

              @if (shouldShowItems(record)) {
                <ul class="ndt-stream__items">
                  @for (item of visibleItems(record); track item.index) {
                    <li
                      class="ndt-stream__item"
                      [class.ndt-stream__item--running]="item.status === 'running'"
                      [class.ndt-stream__item--done]="item.status === 'done'"
                      [class.ndt-stream__item--error]="item.status === 'error'"
                    >
                      <span class="ndt-stream__item-glyph" aria-hidden="true">
                        @switch (item.status) {
                          @case ('running') {
                            <svg viewBox="0 0 12 12" width="11" height="11" class="ndt-stream__spinner">
                              <circle cx="6" cy="6" r="4" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.25"/>
                              <path d="M6 2 a4 4 0 0 1 4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                            </svg>
                          }
                          @case ('done') {
                            <svg viewBox="0 0 12 12" width="11" height="11">
                              <path d="M2.5 6 5 8.3 9.5 3.5" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                          }
                          @case ('error') {
                            <svg viewBox="0 0 12 12" width="11" height="11">
                              <path d="M3 3 9 9 M9 3 3 9" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"/>
                            </svg>
                          }
                        }
                      </span>

                      <div class="ndt-stream__item-content">
                        @if (item.href && item.status === 'done') {
                          <a class="ndt-stream__item-title" [href]="item.href">
                            <span class="ndt-stream__item-verb">{{ itemVerb(record, item) }}</span>
                            <span class="ndt-stream__item-name">{{ itemName(record, item) }}</span>
                            <span class="ndt-stream__item-arrow" aria-hidden="true">→</span>
                          </a>
                        } @else {
                          <span
                            class="ndt-stream__item-title"
                            [class.ndt-stream__item-title--dim]="item.status === 'queued'"
                          >
                            <span class="ndt-stream__item-verb">{{ itemVerb(record, item) }}</span>
                            <span class="ndt-stream__item-name">{{ itemName(record, item) }}</span>
                          </span>
                        }

                        @if (itemDetail(record, item); as detail) {
                          <span
                            class="ndt-stream__item-detail"
                            [class.ndt-stream__item-detail--error]="item.status === 'error'"
                          >
                            {{ detail }}
                          </span>
                        }
                      </div>
                    </li>
                  }
                  @if (hiddenItemCount(record) > 0) {
                    <li class="ndt-stream__more">… {{ hiddenItemCount(record) }} earlier</li>
                  }
                </ul>
              }
            </li>
          }
        </ol>

        @if (summary()) {
          <p class="ndt-stream__summary">{{ summary() }}</p>
        }

        <div #anchor class="ndt-stream__anchor" aria-hidden="true"></div>
      </div>
    }
  `, isInline: true, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:block;height:100%;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\"}.ndt-stream__empty{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;min-height:280px;padding:var(--ndt-spacing-lg);text-align:center;color:var(--ndt-text-secondary)}.ndt-stream{display:flex;flex-direction:column;gap:var(--ndt-spacing-md);padding-top:var(--ndt-spacing-sm);padding-bottom:var(--ndt-spacing-md);font-size:var(--ndt-font-size-sm);color:var(--ndt-text-secondary);font-variant-numeric:tabular-nums;animation:ndt-stream-fade-in .22s cubic-bezier(.16,1,.3,1)}.ndt-stream__header{display:flex;gap:var(--ndt-spacing-sm);align-items:flex-start}.ndt-stream__header-text{display:flex;flex-direction:column;gap:4px;flex:1;min-width:0}.ndt-stream__title{font-size:var(--ndt-font-size-md);font-weight:600;color:var(--ndt-text-primary);margin:0;letter-spacing:-.01em}.ndt-stream__preamble{font-size:var(--ndt-font-size-xs);color:var(--ndt-text-muted);margin:0;line-height:1.55}.ndt-stream__glyph--sparkle{color:var(--ndt-primary);flex-shrink:0;margin-top:2px}.ndt-stream__steps{list-style:none;margin:0;padding:0;display:flex;flex-direction:column}.ndt-stream__step{position:relative;padding:var(--ndt-spacing-xs) 0 12px 28px;animation:ndt-stream-step-in .24s cubic-bezier(.16,1,.3,1) backwards}.ndt-stream__step:before{content:\"\";position:absolute;left:11px;top:0;bottom:0;width:1px;background:var(--ndt-border-subtle)}.ndt-stream__step:first-child:before{top:14px}.ndt-stream__step:last-child:before{bottom:calc(100% - 14px)}.ndt-stream__step:nth-child(2){animation-delay:50ms}.ndt-stream__step:nth-child(3){animation-delay:.1s}.ndt-stream__step:nth-child(4){animation-delay:.15s}.ndt-stream__step:nth-child(5){animation-delay:.2s}.ndt-stream__step:nth-child(6){animation-delay:.25s}.ndt-stream__step:nth-child(7){animation-delay:.3s}.ndt-stream__step:nth-child(n+8){animation-delay:.35s}.ndt-stream__step-row{display:flex;align-items:center;gap:var(--ndt-spacing-sm);position:relative;min-height:18px}.ndt-stream__glyph{position:absolute;left:-22px;top:50%;transform:translateY(-50%);width:14px;height:14px;display:flex;align-items:center;justify-content:center;background:var(--ndt-bg-primary);border-radius:50%;z-index:1}.ndt-stream__glyph svg{overflow:visible}.ndt-stream__step--queued .ndt-stream__glyph svg{color:var(--ndt-border-primary)}.ndt-stream__step--running .ndt-stream__glyph svg,.ndt-stream__step--done .ndt-stream__glyph svg{color:var(--ndt-primary)}.ndt-stream__step--error .ndt-stream__glyph svg{color:var(--ndt-danger)}.ndt-stream__pulse{animation:ndt-stream-pulse 1.4s ease-in-out infinite;transform-origin:center}.ndt-stream__label-btn{display:flex;align-items:center;gap:6px;padding:0;border:0;background:transparent;color:inherit;font:inherit;text-align:left;cursor:default;appearance:none;flex:1;min-width:0}.ndt-stream__label-btn[disabled]{cursor:default}.ndt-stream__label-btn:not([disabled]){cursor:pointer}.ndt-stream__label-btn:focus-visible{outline:2px solid var(--ndt-primary);outline-offset:3px;border-radius:var(--ndt-border-radius-small)}.ndt-stream__verb{font-weight:500;color:var(--ndt-primary);font-size:var(--ndt-font-size-sm);flex-shrink:0}.ndt-stream__step--queued .ndt-stream__verb{color:var(--ndt-text-muted);font-weight:400}.ndt-stream__step--error .ndt-stream__verb{color:var(--ndt-danger)}.ndt-stream__noun{color:var(--ndt-text-primary);font-weight:400;font-size:var(--ndt-font-size-sm);text-overflow:ellipsis;overflow:hidden;white-space:nowrap;flex:1;min-width:0}.ndt-stream__step--queued .ndt-stream__noun{color:var(--ndt-text-muted)}.ndt-stream__chevron{color:var(--ndt-text-muted);transition:transform .2s cubic-bezier(.16,1,.3,1);display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.ndt-stream__chevron--open{transform:rotate(180deg)}.ndt-stream__step-description{margin:4px 0 0;font-size:.7rem;color:var(--ndt-text-muted);line-height:1.5;max-width:60ch}.ndt-stream__items{list-style:none;margin:10px 0 0;padding:0;display:flex;flex-direction:column;gap:10px}.ndt-stream__item{display:flex;align-items:flex-start;gap:10px;padding:6px 8px;margin:0 -8px;border-radius:var(--ndt-border-radius-small);animation:ndt-stream-item-in .2s cubic-bezier(.16,1,.3,1)}.ndt-stream__item--done:hover{background:var(--ndt-hover-bg)}.ndt-stream__item--done:hover .ndt-stream__item-arrow{opacity:1;transform:translate(0)}.ndt-stream__item-glyph{width:11px;height:11px;display:flex;align-items:center;justify-content:center;flex-shrink:0;position:relative;top:4px}.ndt-stream__item--running .ndt-stream__item-glyph{color:var(--ndt-primary)}.ndt-stream__item--done .ndt-stream__item-glyph{color:var(--ndt-success)}.ndt-stream__item--error .ndt-stream__item-glyph{color:var(--ndt-danger)}.ndt-stream__spinner{animation:ndt-stream-spin .9s linear infinite;transform-origin:center}.ndt-stream__item-content{display:flex;flex-direction:column;gap:3px;flex:1;min-width:0;line-height:1.45}.ndt-stream__item-title{font-size:var(--ndt-font-size-xs);font-weight:500;color:var(--ndt-text-primary);text-decoration:none;display:inline-flex;align-items:baseline;gap:5px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;width:fit-content;max-width:100%}.ndt-stream__item-title--dim .ndt-stream__item-name{color:var(--ndt-text-muted)}.ndt-stream__item-verb{font-weight:500;flex-shrink:0}.ndt-stream__item--running .ndt-stream__item-verb{color:var(--ndt-primary)}.ndt-stream__item--done .ndt-stream__item-verb{color:var(--ndt-success)}.ndt-stream__item--error .ndt-stream__item-verb{color:var(--ndt-danger)}.ndt-stream__item-name{color:var(--ndt-text-primary);font-weight:500}a.ndt-stream__item-title:hover .ndt-stream__item-name{text-decoration:underline;text-underline-offset:2px;text-decoration-color:var(--ndt-text-primary)}.ndt-stream__item-arrow{display:inline-block;color:var(--ndt-primary);opacity:0;transform:translate(-2px);transition:opacity .16s ease-out,transform .16s ease-out;font-size:.85rem;flex-shrink:0}.ndt-stream__item-detail{font-size:.7rem;color:var(--ndt-text-muted);text-overflow:ellipsis;overflow:hidden;white-space:nowrap;font-variant-numeric:tabular-nums}.ndt-stream__item-detail--error{color:var(--ndt-danger)}.ndt-stream__more{padding:4px 6px 0 22px;font-size:var(--ndt-font-size-xxs);color:var(--ndt-text-muted);font-style:italic}.ndt-stream__summary{margin:var(--ndt-spacing-xs) 0 0 28px;padding-top:var(--ndt-spacing-sm);border-top:1px solid var(--ndt-border-subtle);font-size:var(--ndt-font-size-xs);color:var(--ndt-text-muted);font-variant-numeric:tabular-nums}.ndt-stream__anchor{height:1px;pointer-events:none}@keyframes ndt-stream-fade-in{0%{opacity:0;transform:translateY(2px)}to{opacity:1;transform:translateY(0)}}@keyframes ndt-stream-step-in{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}@keyframes ndt-stream-item-in{0%{opacity:0;transform:translate(-2px)}to{opacity:1;transform:translate(0)}}@keyframes ndt-stream-pulse{0%,to{transform:scale(.85);opacity:.7}50%{transform:scale(1);opacity:1}}@keyframes ndt-stream-spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@media (prefers-reduced-motion: reduce){.ndt-stream,.ndt-stream__step,.ndt-stream__items,.ndt-stream__item,.ndt-stream__pulse,.ndt-stream__spinner{animation:none}.ndt-stream__chevron,.ndt-stream__item-arrow{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarStreamRunnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-stream-runner', standalone: true, template: `
    @if (isIdle()) {
      <div class="ndt-stream__empty">
        <ng-content></ng-content>
      </div>
    } @else {
      <div class="ndt-stream" role="log" aria-live="polite">
        <div class="ndt-stream__header">
          <span class="ndt-stream__glyph ndt-stream__glyph--sparkle" aria-hidden="true">
            <svg viewBox="0 0 16 16" width="14" height="14">
              <path d="M8 1.5l1.4 3.6L13 6.5l-3.6 1.4L8 11.5 6.6 7.9 3 6.5l3.6-1.4L8 1.5z M12 10l.6 1.6L14 12.2l-1.4.6L12 14.4l-.6-1.6L10 12.2l1.4-.6L12 10z" fill="currentColor"/>
            </svg>
          </span>
          <div class="ndt-stream__header-text">
            <h3 class="ndt-stream__title">{{ title() }}</h3>
            @if (preamble()) {
              <p class="ndt-stream__preamble">{{ preamble() }}</p>
            }
          </div>
        </div>

        <ol class="ndt-stream__steps">
          @for (record of visibleRecords(); track record.index) {
            <li
              class="ndt-stream__step"
              [class.ndt-stream__step--queued]="record.status === 'queued'"
              [class.ndt-stream__step--running]="record.status === 'running'"
              [class.ndt-stream__step--done]="record.status === 'done'"
              [class.ndt-stream__step--error]="record.status === 'error'"
              [class.ndt-stream__step--expanded]="record.expanded"
            >
              <div class="ndt-stream__step-row">
                <span class="ndt-stream__glyph" aria-hidden="true">
                  @switch (record.status) {
                    @case ('queued') {
                      <svg viewBox="0 0 16 16" width="14" height="14">
                        <circle cx="8" cy="8" r="5" fill="none" stroke="currentColor" stroke-width="1.5"/>
                      </svg>
                    }
                    @case ('running') {
                      <svg viewBox="0 0 16 16" width="14" height="14" class="ndt-stream__pulse">
                        <circle cx="8" cy="8" r="6" fill="currentColor"/>
                        <path d="M8 2a6 6 0 0 1 0 12" fill="none" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
                      </svg>
                    }
                    @case ('done') {
                      <svg viewBox="0 0 16 16" width="14" height="14">
                        <circle cx="8" cy="8" r="6" fill="currentColor"/>
                        <path d="M5 8.2 7 10.2 11 6" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
                      </svg>
                    }
                    @case ('error') {
                      <svg viewBox="0 0 16 16" width="14" height="14">
                        <circle cx="8" cy="8" r="6" fill="currentColor"/>
                        <path d="M6 6 10 10 M10 6 6 10" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
                      </svg>
                    }
                  }
                </span>

                <button
                  type="button"
                  class="ndt-stream__label-btn"
                  [disabled]="record.status === 'queued' || record.status === 'running'"
                  [attr.aria-expanded]="(record.status === 'done' || record.status === 'error') ? record.expanded : null"
                  (click)="toggleExpanded(record)"
                >
                  <span class="ndt-stream__verb">{{ stepVerb(record) }}</span>
                  <span class="ndt-stream__noun">{{ stepNoun(record) }}</span>
                  @if (canExpand(record)) {
                    <span
                      class="ndt-stream__chevron"
                      [class.ndt-stream__chevron--open]="record.expanded"
                      aria-hidden="true"
                    >
                      <svg viewBox="0 0 12 12" width="10" height="10">
                        <path d="M3 4.5 6 7.5 9 4.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                      </svg>
                    </span>
                  }
                </button>
              </div>

              @if (record.step.description) {
                <p class="ndt-stream__step-description">{{ record.step.description }}</p>
              }

              @if (shouldShowItems(record)) {
                <ul class="ndt-stream__items">
                  @for (item of visibleItems(record); track item.index) {
                    <li
                      class="ndt-stream__item"
                      [class.ndt-stream__item--running]="item.status === 'running'"
                      [class.ndt-stream__item--done]="item.status === 'done'"
                      [class.ndt-stream__item--error]="item.status === 'error'"
                    >
                      <span class="ndt-stream__item-glyph" aria-hidden="true">
                        @switch (item.status) {
                          @case ('running') {
                            <svg viewBox="0 0 12 12" width="11" height="11" class="ndt-stream__spinner">
                              <circle cx="6" cy="6" r="4" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.25"/>
                              <path d="M6 2 a4 4 0 0 1 4 4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                            </svg>
                          }
                          @case ('done') {
                            <svg viewBox="0 0 12 12" width="11" height="11">
                              <path d="M2.5 6 5 8.3 9.5 3.5" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                          }
                          @case ('error') {
                            <svg viewBox="0 0 12 12" width="11" height="11">
                              <path d="M3 3 9 9 M9 3 3 9" stroke="currentColor" stroke-width="1.75" stroke-linecap="round"/>
                            </svg>
                          }
                        }
                      </span>

                      <div class="ndt-stream__item-content">
                        @if (item.href && item.status === 'done') {
                          <a class="ndt-stream__item-title" [href]="item.href">
                            <span class="ndt-stream__item-verb">{{ itemVerb(record, item) }}</span>
                            <span class="ndt-stream__item-name">{{ itemName(record, item) }}</span>
                            <span class="ndt-stream__item-arrow" aria-hidden="true">→</span>
                          </a>
                        } @else {
                          <span
                            class="ndt-stream__item-title"
                            [class.ndt-stream__item-title--dim]="item.status === 'queued'"
                          >
                            <span class="ndt-stream__item-verb">{{ itemVerb(record, item) }}</span>
                            <span class="ndt-stream__item-name">{{ itemName(record, item) }}</span>
                          </span>
                        }

                        @if (itemDetail(record, item); as detail) {
                          <span
                            class="ndt-stream__item-detail"
                            [class.ndt-stream__item-detail--error]="item.status === 'error'"
                          >
                            {{ detail }}
                          </span>
                        }
                      </div>
                    </li>
                  }
                  @if (hiddenItemCount(record) > 0) {
                    <li class="ndt-stream__more">… {{ hiddenItemCount(record) }} earlier</li>
                  }
                </ul>
              }
            </li>
          }
        </ol>

        @if (summary()) {
          <p class="ndt-stream__summary">{{ summary() }}</p>
        }

        <div #anchor class="ndt-stream__anchor" aria-hidden="true"></div>
      </div>
    }
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{--ndt-border-radius-small: 4px;--ndt-border-radius-medium: 8px;--ndt-border-radius-large: 12px;--ndt-transition-default: all .2s ease-out;--ndt-transition-smooth: all .2s ease-in-out;--ndt-bg-primary: rgb(255, 255, 255);--ndt-bg-gradient: linear-gradient(180deg, rgb(243, 244, 246) 0%, rgba(243, 244, 246, .88) 100%);--ndt-text-primary: rgb(17, 24, 39);--ndt-text-secondary: rgb(55, 65, 81);--ndt-text-muted: rgb(107, 114, 128);--ndt-border-primary: #e5e7eb;--ndt-border-subtle: rgba(17, 24, 39, .1);--ndt-hover-bg: rgba(17, 24, 39, .05);--ndt-hover-danger: rgb(239, 68, 68);--ndt-shadow-toolbar: 0 2px 8px rgba(156, 163, 175, .2);--ndt-shadow-tooltip: 0 0 0 1px rgba(17, 24, 39, .05), 0 4px 8px rgba(107, 114, 128, .15), 0 2px 4px rgba(107, 114, 128, .1);--ndt-shadow-window: 0px 0px 0px 0px rgba(156, 163, 175, .1), 0px 1px 2px 0px rgba(156, 163, 175, .12), 0px 4px 4px 0px rgba(156, 163, 175, .1), 0px 10px 6px 0px rgba(156, 163, 175, .08), 0px 17px 7px 0px rgba(156, 163, 175, .05), 0px 26px 7px 0px rgba(156, 163, 175, .02);--ndt-spacing-xs: 4px;--ndt-spacing-sm: 6px;--ndt-spacing-md: 12px;--ndt-spacing-lg: 16px;--ndt-window-padding: 16px;--ndt-font-size-xxs: .65rem;--ndt-font-size-xs: .75rem;--ndt-font-size-sm: .875rem;--ndt-font-size-md: 1rem;--ndt-font-size-lg: 1.25rem;--ndt-font-size-xl: 2rem;--ndt-background-secondary: var(--ndt-bg-primary);--ndt-background-hover: var(--ndt-hover-bg);--ndt-primary: #635BFF;--ndt-primary-rgb: 99, 91, 255;--ndt-text-on-primary: rgb(255, 255, 255);--ndt-border-color: var(--ndt-border-primary);--ndt-tooltip-bg: rgb(17, 24, 39);--ndt-tooltip-text: rgb(255, 255, 255);--ndt-note-background: rgb(219, 234, 254);--ndt-note-border: rgba(37, 99, 235, .2);--ndt-warning-background: rgb(254, 249, 195);--ndt-warning-border: rgba(202, 138, 4, .2);--ndt-error-background: rgb(254, 226, 226);--ndt-error-border: rgba(220, 38, 38, .2);display:block;height:100%;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\",Segoe UI Symbol,\"Noto Color Emoji\"}.ndt-stream__empty{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;min-height:280px;padding:var(--ndt-spacing-lg);text-align:center;color:var(--ndt-text-secondary)}.ndt-stream{display:flex;flex-direction:column;gap:var(--ndt-spacing-md);padding-top:var(--ndt-spacing-sm);padding-bottom:var(--ndt-spacing-md);font-size:var(--ndt-font-size-sm);color:var(--ndt-text-secondary);font-variant-numeric:tabular-nums;animation:ndt-stream-fade-in .22s cubic-bezier(.16,1,.3,1)}.ndt-stream__header{display:flex;gap:var(--ndt-spacing-sm);align-items:flex-start}.ndt-stream__header-text{display:flex;flex-direction:column;gap:4px;flex:1;min-width:0}.ndt-stream__title{font-size:var(--ndt-font-size-md);font-weight:600;color:var(--ndt-text-primary);margin:0;letter-spacing:-.01em}.ndt-stream__preamble{font-size:var(--ndt-font-size-xs);color:var(--ndt-text-muted);margin:0;line-height:1.55}.ndt-stream__glyph--sparkle{color:var(--ndt-primary);flex-shrink:0;margin-top:2px}.ndt-stream__steps{list-style:none;margin:0;padding:0;display:flex;flex-direction:column}.ndt-stream__step{position:relative;padding:var(--ndt-spacing-xs) 0 12px 28px;animation:ndt-stream-step-in .24s cubic-bezier(.16,1,.3,1) backwards}.ndt-stream__step:before{content:\"\";position:absolute;left:11px;top:0;bottom:0;width:1px;background:var(--ndt-border-subtle)}.ndt-stream__step:first-child:before{top:14px}.ndt-stream__step:last-child:before{bottom:calc(100% - 14px)}.ndt-stream__step:nth-child(2){animation-delay:50ms}.ndt-stream__step:nth-child(3){animation-delay:.1s}.ndt-stream__step:nth-child(4){animation-delay:.15s}.ndt-stream__step:nth-child(5){animation-delay:.2s}.ndt-stream__step:nth-child(6){animation-delay:.25s}.ndt-stream__step:nth-child(7){animation-delay:.3s}.ndt-stream__step:nth-child(n+8){animation-delay:.35s}.ndt-stream__step-row{display:flex;align-items:center;gap:var(--ndt-spacing-sm);position:relative;min-height:18px}.ndt-stream__glyph{position:absolute;left:-22px;top:50%;transform:translateY(-50%);width:14px;height:14px;display:flex;align-items:center;justify-content:center;background:var(--ndt-bg-primary);border-radius:50%;z-index:1}.ndt-stream__glyph svg{overflow:visible}.ndt-stream__step--queued .ndt-stream__glyph svg{color:var(--ndt-border-primary)}.ndt-stream__step--running .ndt-stream__glyph svg,.ndt-stream__step--done .ndt-stream__glyph svg{color:var(--ndt-primary)}.ndt-stream__step--error .ndt-stream__glyph svg{color:var(--ndt-danger)}.ndt-stream__pulse{animation:ndt-stream-pulse 1.4s ease-in-out infinite;transform-origin:center}.ndt-stream__label-btn{display:flex;align-items:center;gap:6px;padding:0;border:0;background:transparent;color:inherit;font:inherit;text-align:left;cursor:default;appearance:none;flex:1;min-width:0}.ndt-stream__label-btn[disabled]{cursor:default}.ndt-stream__label-btn:not([disabled]){cursor:pointer}.ndt-stream__label-btn:focus-visible{outline:2px solid var(--ndt-primary);outline-offset:3px;border-radius:var(--ndt-border-radius-small)}.ndt-stream__verb{font-weight:500;color:var(--ndt-primary);font-size:var(--ndt-font-size-sm);flex-shrink:0}.ndt-stream__step--queued .ndt-stream__verb{color:var(--ndt-text-muted);font-weight:400}.ndt-stream__step--error .ndt-stream__verb{color:var(--ndt-danger)}.ndt-stream__noun{color:var(--ndt-text-primary);font-weight:400;font-size:var(--ndt-font-size-sm);text-overflow:ellipsis;overflow:hidden;white-space:nowrap;flex:1;min-width:0}.ndt-stream__step--queued .ndt-stream__noun{color:var(--ndt-text-muted)}.ndt-stream__chevron{color:var(--ndt-text-muted);transition:transform .2s cubic-bezier(.16,1,.3,1);display:inline-flex;align-items:center;justify-content:center;flex-shrink:0}.ndt-stream__chevron--open{transform:rotate(180deg)}.ndt-stream__step-description{margin:4px 0 0;font-size:.7rem;color:var(--ndt-text-muted);line-height:1.5;max-width:60ch}.ndt-stream__items{list-style:none;margin:10px 0 0;padding:0;display:flex;flex-direction:column;gap:10px}.ndt-stream__item{display:flex;align-items:flex-start;gap:10px;padding:6px 8px;margin:0 -8px;border-radius:var(--ndt-border-radius-small);animation:ndt-stream-item-in .2s cubic-bezier(.16,1,.3,1)}.ndt-stream__item--done:hover{background:var(--ndt-hover-bg)}.ndt-stream__item--done:hover .ndt-stream__item-arrow{opacity:1;transform:translate(0)}.ndt-stream__item-glyph{width:11px;height:11px;display:flex;align-items:center;justify-content:center;flex-shrink:0;position:relative;top:4px}.ndt-stream__item--running .ndt-stream__item-glyph{color:var(--ndt-primary)}.ndt-stream__item--done .ndt-stream__item-glyph{color:var(--ndt-success)}.ndt-stream__item--error .ndt-stream__item-glyph{color:var(--ndt-danger)}.ndt-stream__spinner{animation:ndt-stream-spin .9s linear infinite;transform-origin:center}.ndt-stream__item-content{display:flex;flex-direction:column;gap:3px;flex:1;min-width:0;line-height:1.45}.ndt-stream__item-title{font-size:var(--ndt-font-size-xs);font-weight:500;color:var(--ndt-text-primary);text-decoration:none;display:inline-flex;align-items:baseline;gap:5px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;width:fit-content;max-width:100%}.ndt-stream__item-title--dim .ndt-stream__item-name{color:var(--ndt-text-muted)}.ndt-stream__item-verb{font-weight:500;flex-shrink:0}.ndt-stream__item--running .ndt-stream__item-verb{color:var(--ndt-primary)}.ndt-stream__item--done .ndt-stream__item-verb{color:var(--ndt-success)}.ndt-stream__item--error .ndt-stream__item-verb{color:var(--ndt-danger)}.ndt-stream__item-name{color:var(--ndt-text-primary);font-weight:500}a.ndt-stream__item-title:hover .ndt-stream__item-name{text-decoration:underline;text-underline-offset:2px;text-decoration-color:var(--ndt-text-primary)}.ndt-stream__item-arrow{display:inline-block;color:var(--ndt-primary);opacity:0;transform:translate(-2px);transition:opacity .16s ease-out,transform .16s ease-out;font-size:.85rem;flex-shrink:0}.ndt-stream__item-detail{font-size:.7rem;color:var(--ndt-text-muted);text-overflow:ellipsis;overflow:hidden;white-space:nowrap;font-variant-numeric:tabular-nums}.ndt-stream__item-detail--error{color:var(--ndt-danger)}.ndt-stream__more{padding:4px 6px 0 22px;font-size:var(--ndt-font-size-xxs);color:var(--ndt-text-muted);font-style:italic}.ndt-stream__summary{margin:var(--ndt-spacing-xs) 0 0 28px;padding-top:var(--ndt-spacing-sm);border-top:1px solid var(--ndt-border-subtle);font-size:var(--ndt-font-size-xs);color:var(--ndt-text-muted);font-variant-numeric:tabular-nums}.ndt-stream__anchor{height:1px;pointer-events:none}@keyframes ndt-stream-fade-in{0%{opacity:0;transform:translateY(2px)}to{opacity:1;transform:translateY(0)}}@keyframes ndt-stream-step-in{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}@keyframes ndt-stream-item-in{0%{opacity:0;transform:translate(-2px)}to{opacity:1;transform:translate(0)}}@keyframes ndt-stream-pulse{0%,to{transform:scale(.85);opacity:.7}50%{transform:scale(1);opacity:1}}@keyframes ndt-stream-spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}@media (prefers-reduced-motion: reduce){.ndt-stream,.ndt-stream__step,.ndt-stream__items,.ndt-stream__item,.ndt-stream__pulse,.ndt-stream__spinner{animation:none}.ndt-stream__chevron,.ndt-stream__item-arrow{transition:none}}\n"] }]
        }], propDecorators: { anchor: [{
                type: ViewChild,
                args: ['anchor']
            }] } });

class ToolbarTabComponent {
    constructor() {
        this.label = input.required();
        this.isActive = signal(false);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarTabComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarTabComponent, isStandalone: true, selector: "ndt-tab", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    @if (isActive()) {
      <ng-content />
    }
  `, isInline: true, styles: [":host{display:block}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-tab', standalone: true, template: `
    @if (isActive()) {
      <ng-content />
    }
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block}\n"] }]
        }] });

class ToolbarTabsComponent {
    constructor() {
        this.tabs = contentChildren(ToolbarTabComponent);
        this.activeIndex = signal(0);
        this.activeIndexChange = output();
        this.instanceId = Math.random().toString(36).slice(2, 9);
        effect(() => {
            const tabs = this.tabs();
            const active = this.activeIndex();
            tabs.forEach((tab, i) => tab.isActive.set(i === active));
        });
    }
    selectTab(index) {
        this.activeIndex.set(index);
        this.activeIndexChange.emit(index);
    }
    onKeydown(event, currentIndex) {
        const count = this.tabs().length;
        let newIndex = null;
        switch (event.key) {
            case 'ArrowRight':
                newIndex = (currentIndex + 1) % count;
                break;
            case 'ArrowLeft':
                newIndex = (currentIndex - 1 + count) % count;
                break;
            case 'Home':
                newIndex = 0;
                break;
            case 'End':
                newIndex = count - 1;
                break;
            default:
                return;
        }
        event.preventDefault();
        this.selectTab(newIndex);
        const button = event.target
            .parentElement?.querySelectorAll('[role="tab"]')[newIndex];
        button?.focus();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarTabsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.0.7", type: ToolbarTabsComponent, isStandalone: true, selector: "ndt-tabs", outputs: { activeIndexChange: "activeIndexChange" }, queries: [{ propertyName: "tabs", predicate: ToolbarTabComponent, isSignal: true }], ngImport: i0, template: `
    <div class="tab-bar" role="tablist">
      @for (tab of tabs(); track $index) {
        <button
          class="tab-button"
          [class.tab-button--active]="$index === activeIndex()"
          role="tab"
          [attr.aria-selected]="$index === activeIndex()"
          [attr.tabindex]="$index === activeIndex() ? 0 : -1"
          [attr.id]="'tab-' + instanceId + '-' + $index"
          [attr.aria-controls]="'tabpanel-' + instanceId"
          (click)="selectTab($index)"
          (keydown)="onKeydown($event, $index)"
        >
          {{ tab.label() }}
        </button>
      }
    </div>
    <div
      class="tab-panel"
      role="tabpanel"
      [attr.id]="'tabpanel-' + instanceId"
      [attr.aria-labelledby]="'tab-' + instanceId + '-' + activeIndex()"
    >
      <ng-content />
    </div>
  `, isInline: true, styles: [":host{display:flex;flex-direction:column}.tab-bar{display:flex;gap:var(--ndt-spacing-xs);padding:0;margin:0;border-bottom:1px solid var(--ndt-border-primary);flex-shrink:0}.tab-button{all:unset;display:inline-flex;align-items:center;padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);font-size:var(--ndt-font-size-sm);font-weight:500;color:var(--ndt-text-secondary);cursor:pointer;border-bottom:2px solid transparent;transition:color .15s ease,border-color .15s ease;box-sizing:border-box}.tab-button:hover{color:var(--ndt-text-primary)}.tab-button:focus-visible{outline:2px solid var(--ndt-text-primary);outline-offset:-2px;border-radius:var(--ndt-border-radius-small)}.tab-button--active{color:var(--ndt-text-primary);border-bottom-color:var(--ndt-text-primary);font-weight:600}.tab-panel{flex:1;min-height:0;overflow:auto;padding-top:var(--ndt-spacing-md)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarTabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ndt-tabs', standalone: true, template: `
    <div class="tab-bar" role="tablist">
      @for (tab of tabs(); track $index) {
        <button
          class="tab-button"
          [class.tab-button--active]="$index === activeIndex()"
          role="tab"
          [attr.aria-selected]="$index === activeIndex()"
          [attr.tabindex]="$index === activeIndex() ? 0 : -1"
          [attr.id]="'tab-' + instanceId + '-' + $index"
          [attr.aria-controls]="'tabpanel-' + instanceId"
          (click)="selectTab($index)"
          (keydown)="onKeydown($event, $index)"
        >
          {{ tab.label() }}
        </button>
      }
    </div>
    <div
      class="tab-panel"
      role="tabpanel"
      [attr.id]="'tabpanel-' + instanceId"
      [attr.aria-labelledby]="'tab-' + instanceId + '-' + activeIndex()"
    >
      <ng-content />
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:flex;flex-direction:column}.tab-bar{display:flex;gap:var(--ndt-spacing-xs);padding:0;margin:0;border-bottom:1px solid var(--ndt-border-primary);flex-shrink:0}.tab-button{all:unset;display:inline-flex;align-items:center;padding:var(--ndt-spacing-sm) var(--ndt-spacing-md);font-size:var(--ndt-font-size-sm);font-weight:500;color:var(--ndt-text-secondary);cursor:pointer;border-bottom:2px solid transparent;transition:color .15s ease,border-color .15s ease;box-sizing:border-box}.tab-button:hover{color:var(--ndt-text-primary)}.tab-button:focus-visible{outline:2px solid var(--ndt-text-primary);outline-offset:-2px;border-radius:var(--ndt-border-radius-small)}.tab-button--active{color:var(--ndt-text-primary);border-bottom-color:var(--ndt-text-primary);font-weight:600}.tab-panel{flex:1;min-height:0;overflow:auto;padding-top:var(--ndt-spacing-md)}\n"] }]
        }], ctorParameters: () => [] });

class ToolbarI18nService {
    constructor() {
        this.internalService = inject(ToolbarInternalI18nService);
    }
    /**
     * Sets the available locales displayed in the i18n tool
     */
    setAvailableOptions(locales) {
        this.internalService.setAvailableLocales(locales);
    }
    /**
     * Gets the locale that was forced through the i18n tool
     * @returns Observable of forced locale array (single item or empty)
     */
    getForcedValues() {
        return this.internalService.getForcedLocale();
    }
    /**
     * Gets the forced locale value.
     * For the i18n tool, this returns the same as getForcedValues() since
     * only one locale can be selected at a time.
     */
    getValues() {
        return this.internalService.getForcedLocale();
    }
    // --- Extended i18n accessors ---
    /**
     * Sets the available timezones displayed in the i18n tool.
     * If not called, defaults to a built-in list of common timezones.
     */
    setAvailableTimezones(timezones) {
        this.internalService.setAvailableTimezones(timezones);
    }
    /**
     * Sets the available currencies displayed in the i18n tool.
     * If not called, defaults to a built-in list of common currencies.
     */
    setAvailableCurrencies(currencies) {
        this.internalService.setAvailableCurrencies(currencies);
    }
    /**
     * Gets the timezone that was forced through the i18n tool
     */
    getForcedTimezone() {
        return this.internalService.getForcedTimezone();
    }
    /**
     * Gets the currency that was forced through the i18n tool
     */
    getForcedCurrency() {
        return this.internalService.getForcedCurrency();
    }
    /**
     * Gets the unit system that was forced through the i18n tool
     */
    getUnitSystem() {
        return this.internalService.getForcedUnitSystem();
    }
    /**
     * Whether pseudo-localization mode is enabled
     */
    isPseudoLocalizationEnabled() {
        return this.internalService.getPseudoLocEnabled();
    }
    /**
     * Whether RTL mirroring is enabled
     */
    isRtlEnabled() {
        return this.internalService.getRtlEnabled();
    }
    /**
     * Gets the date format that was forced through the i18n tool
     */
    getForcedDateFormat() {
        return this.internalService.getForcedDateFormat();
    }
    /**
     * Gets the first day of week that was forced through the i18n tool
     */
    getForcedFirstDayOfWeek() {
        return this.internalService.getForcedFirstDayOfWeek();
    }
    /**
     * Gets the number format that was forced through the i18n tool
     */
    getForcedNumberFormat() {
        return this.internalService.getForcedNumberFormat();
    }
    /**
     * Configures which sections are visible in the i18n tool panel
     */
    configure(config) {
        this.internalService.setToolConfig(config);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarI18nService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarI18nService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarI18nService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Public service for managing dev toolbar presets.
 * Allows developers to programmatically save, load, and manage presets.
 */
class ToolbarPresetsService {
    constructor() {
        this.internalService = inject(ToolbarInternalPresetsService);
    }
    /**
     * Get all saved presets as an Observable
     */
    getPresets() {
        return this.internalService.presets$;
    }
    /**
     * Save current toolbar state as a preset
     * @param name - Name for the preset
     * @param description - Optional description
     * @returns The created preset
     */
    savePreset(name, description) {
        return this.internalService.saveCurrentAsPreset(name, description);
    }
    /**
     * Apply a preset (load its configuration into all tools)
     * @param presetId - ID of the preset to apply
     */
    async applyPreset(presetId) {
        return this.internalService.applyPreset(presetId);
    }
    /**
     * Update a preset with current toolbar state
     * @param presetId - ID of the preset to update
     */
    updatePreset(presetId) {
        this.internalService.updatePreset(presetId);
    }
    /**
     * Delete a preset
     * @param presetId - ID of the preset to delete
     */
    deletePreset(presetId) {
        this.internalService.deletePreset(presetId);
    }
    /**
     * Toggle favorite status for a preset
     * @param presetId - ID of the preset to toggle
     */
    toggleFavorite(presetId) {
        this.internalService.toggleFavorite(presetId);
    }
    /**
     * Apply a preset with partial options (only selected categories)
     * @param presetId - ID of the preset to apply
     * @param options - Options for which categories to apply
     */
    async partialApplyPreset(presetId, options) {
        return this.internalService.partialApplyPreset(presetId, options);
    }
    /**
     * Update only the metadata (name, description) of a preset
     * @param presetId - ID of the preset to update
     * @param name - New name for the preset
     * @param description - New description for the preset
     */
    updatePresetMetadata(presetId, name, description) {
        this.internalService.updatePresetMetadata(presetId, name, description);
    }
    /**
     * Export a preset as JSON string
     * @param presetId - ID of the preset to export
     * @returns JSON string representation of the preset
     */
    exportPreset(presetId) {
        const preset = this.internalService.getPresetById(presetId);
        if (!preset)
            return null;
        return JSON.stringify(preset, null, 2);
    }
    /**
     * Import a preset from JSON string
     * @param json - JSON string representation of a preset
     * @returns The imported preset
     * @throws Error if JSON is invalid
     */
    importPreset(json) {
        const preset = JSON.parse(json);
        return this.internalService.addPreset(preset);
    }
    /**
     * Initialize presets with predefined configurations.
     * Useful for setting up default presets that all developers can use.
     * Skips presets that already exist (by name) to avoid duplicates.
     *
     * @param presets - Array of preset configurations to initialize
     * @returns Array of created presets (only newly added ones)
     *
     * @example
     * ```typescript
     * const presetsService = inject(ToolbarPresetsService);
     *
     * presetsService.initializePresets([
     *   {
     *     name: 'Admin User',
     *     description: 'Full access admin configuration',
     *     config: {
     *       featureFlags: {
     *         enabled: ['admin-panel', 'advanced-features'],
     *         disabled: []
     *       },
     *       permissions: {
     *         granted: ['admin', 'write', 'delete'],
     *         denied: []
     *       },
     *       appFeatures: {
     *         enabled: ['analytics', 'reporting'],
     *         disabled: []
     *       },
     *       language: 'en'
     *     }
     *   },
     *   {
     *     name: 'Read-Only User',
     *     description: 'Limited access for viewing only',
     *     config: {
     *       featureFlags: {
     *         enabled: [],
     *         disabled: ['admin-panel', 'advanced-features']
     *       },
     *       permissions: {
     *         granted: ['read'],
     *         denied: ['write', 'delete']
     *       },
     *       appFeatures: {
     *         enabled: [],
     *         disabled: ['analytics', 'reporting']
     *       },
     *       language: null
     *     }
     *   }
     * ]);
     * ```
     */
    initializePresets(presets) {
        const existingPresets = this.internalService.presets();
        const existingNames = new Set(existingPresets.map((p) => p.name.toLowerCase()));
        return presets
            .filter((preset) => !existingNames.has(preset.name.toLowerCase()))
            .map((preset) => this.internalService.addPreset({
            id: '', // Will be generated
            createdAt: '', // Will be generated
            updatedAt: '', // Will be generated
            isSystem: true, // Mark as system preset (not editable)
            ...preset,
        }));
    }
    /**
     * Clear all existing presets and set new initial presets.
     * Use this to replace all presets with a fresh set of configurations.
     *
     * @param presets - Array of preset configurations to set as initial
     * @returns Array of created presets
     */
    setInitialPresets(presets) {
        // Clear existing presets
        const currentPresets = this.internalService.presets();
        currentPresets.forEach((preset) => {
            this.internalService.deletePreset(preset.id);
        });
        // Add new presets
        return this.initializePresets(presets);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarPresetsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarPresetsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.0.7", ngImport: i0, type: ToolbarPresetsService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

// Tree-shakeable tokens for dependency injection

/**
 * Generated bundle index. Do not edit.
 */

export { CURRENCY_SYMBOLS, DEFAULT_CURRENCIES, DEFAULT_TIMEZONES, TOOLBAR_APP_FEATURES, TOOLBAR_CONFIG, TOOLBAR_FEATURE_FLAGS, TOOLBAR_PERMISSIONS, TOOLBAR_POSITIONS, ToolbarAppFeaturesService, ToolbarAppFeaturesToolComponent, ToolbarButtonComponent, ToolbarCardComponent, ToolbarClickableCardComponent, ToolbarComponent, ToolbarConfirmDialogComponent, ToolbarFeatureFlagService, ToolbarI18nService, ToolbarI18nToolComponent, ToolbarIconButtonComponent, ToolbarIconComponent, ToolbarInputComponent, ToolbarLinkButtonComponent, ToolbarListComponent, ToolbarListGroupComponent, ToolbarListItemComponent, ToolbarPermissionsService, ToolbarPermissionsToolComponent, ToolbarPresetsService, ToolbarPresetsToolComponent, ToolbarSelectComponent, ToolbarStepDirective, ToolbarStepViewComponent, ToolbarStreamRunnerComponent, ToolbarTabComponent, ToolbarTabsComponent, ToolbarToolComponent, ToolbarToolHeaderComponent, expandText, formatCurrency, formatCustomDate, formatCustomNumber, formatDate, formatNumber, formatTime, isHorizontalPosition, isSidebarPosition, nounSingular, provideToolbar, pseudoLocalize, wait };
//# sourceMappingURL=ngx-dev-toolbar.mjs.map
