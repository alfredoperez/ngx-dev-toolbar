import { InjectionToken, Type } from '@angular/core';
import { ToolbarConfig } from './models/toolbar-config.interface';
import { ToolbarService } from './models/toolbar.interface';
import { ToolbarAppFeature } from './tools/app-features-tool/app-features.models';
import { ToolbarFlag } from './tools/feature-flags-tool/feature-flags.models';
import { ToolbarPermission } from './tools/permissions-tool/permissions.models';
/**
 * InjectionToken for the Toolbar configuration.
 *
 * Provided automatically by `provideToolbar(config)`.
 * Can be injected to access the toolbar configuration at runtime.
 */
export declare const TOOLBAR_CONFIG: InjectionToken<ToolbarConfig>;
/**
 * InjectionToken for the Feature Flags service.
 *
 * Use this token for tree-shakeable injection of the feature flags service.
 * When using dynamic imports, this token enables complete tree-shaking of
 * the toolbar in production builds.
 *
 * @example
 * ```typescript
 * // In your service
 * private devToolbar = inject(TOOLBAR_FEATURE_FLAGS, { optional: true });
 *
 * // Safe to call - no-op if toolbar is not provided
 * this.devToolbar?.setAvailableOptions(flags);
 * ```
 */
export declare const TOOLBAR_FEATURE_FLAGS: InjectionToken<ToolbarService<ToolbarFlag>>;
/**
 * InjectionToken for the Permissions service.
 *
 * Use this token for tree-shakeable injection of the permissions service.
 * When using dynamic imports, this token enables complete tree-shaking of
 * the toolbar in production builds.
 *
 * @example
 * ```typescript
 * // In your service
 * private devToolbar = inject(TOOLBAR_PERMISSIONS, { optional: true });
 *
 * // Safe to call - no-op if toolbar is not provided
 * this.devToolbar?.setAvailableOptions(permissions);
 * ```
 */
export declare const TOOLBAR_PERMISSIONS: InjectionToken<ToolbarService<ToolbarPermission>>;
/**
 * InjectionToken for the App Features service.
 *
 * Use this token for tree-shakeable injection of the app features service.
 * When using dynamic imports, this token enables complete tree-shaking of
 * the toolbar in production builds.
 *
 * @example
 * ```typescript
 * // In your service
 * private devToolbar = inject(TOOLBAR_APP_FEATURES, { optional: true });
 *
 * // Safe to call - no-op if toolbar is not provided
 * this.devToolbar?.setAvailableOptions(features);
 * ```
 */
export declare const TOOLBAR_APP_FEATURES: InjectionToken<ToolbarService<ToolbarAppFeature>>;
/**
 * InjectionToken for registering custom tool components with the toolbar.
 *
 * Custom tools are Angular components that extend the toolbar with app-specific
 * functionality. They are dynamically rendered inside the toolbar at runtime.
 *
 * Use `provideToolbarCustomTools()` to register custom tool components.
 *
 * @example
 * ```typescript
 * // app.config.ts
 * import { provideToolbar, provideToolbarCustomTools } from 'ngx-dev-toolbar';
 * import { MyCustomToolComponent } from './my-custom-tool.component';
 *
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideToolbar({ ... }),
 *     provideToolbarCustomTools(MyCustomToolComponent),
 *   ],
 * };
 * ```
 */
export declare const TOOLBAR_CUSTOM_TOOLS: InjectionToken<Type<unknown>[]>;
