import { ToolbarWindowOptions } from '../../components/toolbar-tool/toolbar-tool.models';
import { AppFeatureFilter, ToolbarAppFeature } from './app-features.models';
import * as i0 from "@angular/core";
/**
 * Component for managing app features in the dev toolbar.
 *
 * Provides UI for:
 * - Searching features by name and description
 * - Filtering features by state (all/forced/enabled/disabled)
 * - Forcing features to enabled/disabled state via 3-state dropdown
 * - Viewing feature descriptions and current state
 *
 * @example
 * ```html
 * <ndt-app-features-tool />
 * ```
 */
export declare class ToolbarAppFeaturesToolComponent {
    private readonly appFeaturesService;
    private readonly storageService;
    private readonly VIEW_STATE_KEY;
    protected readonly activeFilter: import("@angular/core").WritableSignal<AppFeatureFilter>;
    protected readonly searchQuery: import("@angular/core").WritableSignal<string>;
    protected readonly pinnedIds: import("@angular/core").WritableSignal<Set<string>>;
    protected readonly collapsedGroups: import("@angular/core").WritableSignal<Set<string>>;
    constructor();
    private loadViewState;
    protected readonly features: import("@angular/core").Signal<ToolbarAppFeature[]>;
    protected readonly badgeCount: import("@angular/core").Signal<string>;
    protected readonly hasNoFeatures: import("@angular/core").Signal<boolean>;
    private readonly filteredFeatures;
    protected readonly groupedFeatures: import("@angular/core").Signal<import("../../utils/group-items.util").GroupedItems<ToolbarAppFeature>>;
    protected readonly flatFeatures: import("@angular/core").Signal<ToolbarAppFeature[]>;
    protected readonly hasAnyGroups: import("@angular/core").Signal<boolean>;
    protected readonly hasNoFilteredFeatures: import("@angular/core").Signal<boolean>;
    protected readonly options: ToolbarWindowOptions;
    protected readonly filterOptions: {
        value: string;
        label: string;
    }[];
    protected readonly featureValueOptions: {
        value: string;
        label: string;
    }[];
    protected readonly hasApplyCallback: import("@angular/core").Signal<boolean>;
    protected getApplyState(featureId: string): 'idle' | 'loading' | 'success' | 'error';
    protected onApplyToSource(featureId: string, value: boolean): void;
    /**
     * Handle filter dropdown change.
     * Updates the active filter to show all/forced/enabled/disabled features.
     */
    onFilterChange(value: string | undefined): void;
    /**
     * Handle feature value change from 3-state dropdown.
     * - 'not-forced': Remove forced override
     * - 'on': Force feature to enabled
     * - 'off': Force feature to disabled
     */
    onFeatureChange(featureId: string, value: string): void;
    /**
     * Handle search input change.
     * Updates the search query to filter features by name/description.
     */
    onSearchChange(query: string): void;
    togglePin(featureId: string): void;
    protected isCollapsed(name: string): boolean;
    protected setCollapsed(name: string, collapsed: boolean): void;
    /**
     * Get the dropdown value for a feature's current state.
     * - Returns empty string if not forced (natural state)
     * - Returns 'on' if forced to enabled
     * - Returns 'off' if forced to disabled
     */
    protected getFeatureValue(feature: ToolbarAppFeature): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarAppFeaturesToolComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarAppFeaturesToolComponent, "ndt-app-features-tool", never, {}, {}, never, never, true, never>;
}
