import { Observable } from 'rxjs';
import { ApplyToSourceState } from '../../models/toolbar.interface';
import { ToolbarAppFeature, ForcedAppFeaturesState } from './app-features.models';
import * as i0 from "@angular/core";
/**
 * Internal service for managing app features state and forced overrides.
 *
 * This service handles:
 * - Feature configuration storage
 * - Forced feature state management
 * - localStorage persistence
 * - State validation and cleanup
 *
 * @internal This service is for internal toolbar use only. Consumers should use ToolbarAppFeaturesService.
 */
export declare class ToolbarInternalAppFeaturesService {
    private readonly STORAGE_KEY;
    private storageService;
    private stateService;
    private appFeaturesSubject;
    private forcedFeaturesSubject;
    private readonly forcedFeatures$;
    /**
     * Observable stream of all features with merged forced state
     */
    features$: Observable<ToolbarAppFeature[]>;
    /**
     * Signal containing current features with merged forced state
     */
    features: import("@angular/core").Signal<ToolbarAppFeature[]>;
    constructor();
    /**
     * Set available app features for the application.
     * Validates features, trims whitespace, and triggers validation of forced state.
     *
     * @param features - Array of app features to configure
     * @throws Error if duplicate feature IDs or empty IDs are detected
     */
    setAppFeatures(features: ToolbarAppFeature[]): void;
    /**
     * Get observable stream of app features (natural state, no forced state merged)
     */
    getAppFeatures(): Observable<ToolbarAppFeature[]>;
    /**
     * Get observable stream of features that have forced overrides
     */
    getForcedFeatures(): Observable<ToolbarAppFeature[]>;
    /**
     * Force a feature to enabled or disabled state.
     * Persists the forced state to localStorage.
     *
     * @param featureId - ID of the feature to force
     * @param isEnabled - Whether to force feature to enabled (true) or disabled (false)
     */
    setFeature(featureId: string, isEnabled: boolean): void;
    /**
     * Remove forced override for a feature, returning it to natural state.
     * Persists the change to localStorage.
     *
     * @param featureId - ID of the feature to unforce
     */
    removeFeatureOverride(featureId: string): void;
    /**
     * Apply a preset forced state (for preset integration).
     * Validates and cleans invalid feature IDs before applying.
     *
     * @param state - Forced features state from preset
     */
    applyForcedState(state: ForcedAppFeaturesState): void;
    /**
     * Get current forced state as a snapshot (defensive copy).
     * Useful for preset exports and debugging.
     *
     * @returns Current forced features state
     */
    getCurrentForcedState(): ForcedAppFeaturesState;
    readonly applyCallback: import("@angular/core").WritableSignal<((id: string, value: boolean) => Promise<void>) | null>;
    readonly applyStates: import("@angular/core").WritableSignal<Record<string, ApplyToSourceState>>;
    readonly hasApplyCallback: import("@angular/core").Signal<boolean>;
    setApplyToSource(callback: (id: string, value: boolean) => Promise<void>): void;
    applyToSource(id: string, value: boolean): Promise<void>;
    /**
     * Merge natural app features with forced state.
     *
     * @param appFeatures - Natural feature configuration
     * @param forcedState - Forced overrides from localStorage/toolbar
     * @returns Features with merged forced state
     */
    private mergeForcedState;
    /**
     * Load forced features state from localStorage on initialization.
     * Handles missing or corrupted data gracefully.
     */
    private loadForcedFeatures;
    /**
     * Persist forced features state to localStorage.
     * Handles quota exceeded errors gracefully.
     *
     * @param state - Forced state to persist
     */
    private saveForcedFeatures;
    /**
     * Validate forced feature IDs against configured features and clean up invalid ones.
     * Called after setAppFeatures() to ensure forced state references valid features.
     */
    private validateAndCleanForcedState;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarInternalAppFeaturesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToolbarInternalAppFeaturesService>;
}
