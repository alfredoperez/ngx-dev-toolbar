import { Observable } from 'rxjs';
import { ToolbarService } from '../../models/toolbar.interface';
import { ToolbarFlag } from './feature-flags.models';
import * as i0 from "@angular/core";
export declare class ToolbarFeatureFlagService implements ToolbarService<ToolbarFlag> {
    private internalService;
    /**
     * Sets the available flags that will be displayed in the tool on the dev toolbar
     * @param flags The flags to be displayed
     */
    setAvailableOptions(flags: ToolbarFlag[]): void;
    /**
     * Gets the flags that were forced/modified through the tool on the dev toolbar
     * @returns Observable of forced flags array
     */
    getForcedValues(): Observable<ToolbarFlag[]>;
    /**
     * Gets ALL flag values with overrides already applied.
     * Returns the complete set of flags where overridden values replace base values.
     * Each flag includes an `isForced` property indicating if it was overridden.
     *
     * This method simplifies integration by eliminating the need to manually merge
     * base flags with overrides using combineLatest.
     *
     * @returns Observable of all flags with overrides applied
     *
     * @example
     * ```typescript
     * // Get a specific flag value with overrides applied
     * this.featureFlagsService.getValues().pipe(
     *   map(flags => flags.find(f => f.id === 'newFeature')),
     *   map(flag => flag?.isEnabled ?? false)
     * ).subscribe(isEnabled => {
     *   if (isEnabled) {
     *     // Enable feature
     *   }
     * });
     * ```
     */
    getValues(): Observable<ToolbarFlag[]>;
    /**
     * Registers a callback to persist a forced flag value back to the actual data source.
     * When set, an "apply to source" button appears on each forced flag in the toolbar UI.
     *
     * @param callback - Async function that receives the flag ID and its forced boolean value
     */
    setApplyToSource(callback: (id: string, value: boolean) => Promise<void>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarFeatureFlagService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToolbarFeatureFlagService>;
}
