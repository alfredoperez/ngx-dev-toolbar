import { Observable } from 'rxjs';
import { ApplyToSourceState } from '../../models/toolbar.interface';
import { ToolbarFlag } from './feature-flags.models';
import * as i0 from "@angular/core";
interface ForcedFlagsState {
    enabled: string[];
    disabled: string[];
}
export declare class ToolbarInternalFeatureFlagService {
    private readonly STORAGE_KEY;
    private storageService;
    private stateService;
    private appFlags$;
    private forcedFlagsSubject;
    private readonly forcedFlags$;
    flags$: Observable<ToolbarFlag[]>;
    flags: import("@angular/core").Signal<ToolbarFlag[]>;
    constructor();
    setAppFlags(flags: ToolbarFlag[]): void;
    getAppFlags(): Observable<ToolbarFlag[]>;
    getForcedFlags(): Observable<ToolbarFlag[]>;
    setFlag(flagId: string, isEnabled: boolean): void;
    removeFlagOverride(flagId: string): void;
    private loadForcedFlags;
    /**
     * Apply feature flags from a preset (used by Presets Tool)
     * This method directly sets the forced flags state without user interaction
     */
    applyPresetFlags(presetState: ForcedFlagsState): void;
    /**
     * Get current forced state for saving to preset
     * Returns the raw state of enabled and disabled flag IDs
     */
    getCurrentForcedState(): ForcedFlagsState;
    readonly applyCallback: import("@angular/core").WritableSignal<((id: string, value: boolean) => Promise<void>) | null>;
    readonly applyStates: import("@angular/core").WritableSignal<Record<string, ApplyToSourceState>>;
    readonly hasApplyCallback: import("@angular/core").Signal<boolean>;
    setApplyToSource(callback: (id: string, value: boolean) => Promise<void>): void;
    applyToSource(id: string, value: boolean): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarInternalFeatureFlagService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToolbarInternalFeatureFlagService>;
}
export {};
