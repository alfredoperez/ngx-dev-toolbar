import { ToolbarWindowOptions } from '../../components/toolbar-tool/toolbar-tool.models';
import { FeatureFlagFilter, ToolbarFlag } from './feature-flags.models';
import * as i0 from "@angular/core";
export declare class ToolbarFeatureFlagsToolComponent {
    private readonly featureFlags;
    private readonly storageService;
    private readonly VIEW_STATE_KEY;
    protected readonly activeFilter: import("@angular/core").WritableSignal<FeatureFlagFilter>;
    protected readonly searchQuery: import("@angular/core").WritableSignal<string>;
    protected readonly pinnedIds: import("@angular/core").WritableSignal<Set<string>>;
    protected readonly collapsedGroups: import("@angular/core").WritableSignal<Set<string>>;
    constructor();
    private loadViewState;
    protected readonly flags: import("@angular/core").Signal<ToolbarFlag[]>;
    protected readonly badgeCount: import("@angular/core").Signal<string>;
    protected readonly hasNoFlags: import("@angular/core").Signal<boolean>;
    private readonly filteredFlags;
    protected readonly groupedFlags: import("@angular/core").Signal<import("../../utils/group-items.util").GroupedItems<ToolbarFlag>>;
    protected readonly flatFlags: import("@angular/core").Signal<ToolbarFlag[]>;
    protected readonly hasAnyGroups: import("@angular/core").Signal<boolean>;
    protected readonly hasNoFilteredFlags: import("@angular/core").Signal<boolean>;
    protected readonly options: ToolbarWindowOptions;
    protected readonly filterOptions: {
        value: string;
        label: string;
    }[];
    protected readonly flagValueOptions: {
        value: string;
        label: string;
    }[];
    protected readonly hasApplyCallback: import("@angular/core").Signal<boolean>;
    protected getApplyState(flagId: string): 'idle' | 'loading' | 'success' | 'error';
    protected onApplyToSource(flagId: string, value: boolean): void;
    onFilterChange(value: string | undefined): void;
    onFlagChange(flagId: string, value: string): void;
    onSearchChange(query: string): void;
    togglePin(flagId: string): void;
    protected isCollapsed(name: string): boolean;
    protected setCollapsed(name: string, collapsed: boolean): void;
    protected getFlagValue(flag: ToolbarFlag): string;
    protected getFlagPlaceholder(flag: ToolbarFlag): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarFeatureFlagsToolComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarFeatureFlagsToolComponent, "ndt-feature-flags-tool", never, {}, {}, never, never, true, never>;
}
