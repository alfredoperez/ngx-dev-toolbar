import { Settings } from './settings.models';
import * as i0 from "@angular/core";
export declare class SettingsService {
    private readonly STORAGE_KEY;
    private readonly storageService;
    getSettings(): Settings;
    setSettings(settings: Settings): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SettingsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SettingsService>;
}
