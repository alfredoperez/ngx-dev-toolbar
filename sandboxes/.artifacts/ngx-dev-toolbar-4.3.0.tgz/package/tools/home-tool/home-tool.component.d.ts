import { SelectOption } from '../../components/select/select.component';
import { ToolbarWindowOptions } from '../../components/toolbar-tool/toolbar-tool.models';
import { ToolbarPosition } from '../../models/toolbar-position.model';
import { ToolbarStateService } from '../../toolbar-state.service';
import * as i0 from "@angular/core";
export declare class ToolbarHomeToolComponent {
    protected readonly state: ToolbarStateService;
    private readonly settingsService;
    private readonly storageService;
    readonly badge: import("@angular/core").InputSignal<string | number | undefined>;
    readonly title = "Angular Toolbar";
    readonly options: ToolbarWindowOptions;
    readonly positionOptions: SelectOption[];
    readonly links: readonly [{
        readonly url: "https://alfredoperez.github.io/ngx-dev-toolbar/";
        readonly label: "Docs";
    }, {
        readonly url: "https://github.com/alfredoperez/ngx-dev-toolbar/issues/new/choose";
        readonly label: "Feedback";
    }];
    onPositionChange(position: ToolbarPosition): void;
    onExportSettings(): void;
    onImportSettings(): void;
    onResetSettings(): void;
    protected confirmReset(): void;
    private readonly resetDialog;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarHomeToolComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarHomeToolComponent, "ndt-home-tool", never, { "badge": { "alias": "badge"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
