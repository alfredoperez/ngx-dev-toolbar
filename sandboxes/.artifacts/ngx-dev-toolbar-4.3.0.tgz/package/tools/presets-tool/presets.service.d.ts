import { Observable } from 'rxjs';
import { ToolbarPreset, ToolbarPresetConfig, PartialApplyOptions } from './presets.models';
import * as i0 from "@angular/core";
/**
 * Partial preset for initialization (without generated fields)
 */
export interface InitialPreset {
    name: string;
    description?: string;
    config: ToolbarPresetConfig;
}
/**
 * Public service for managing dev toolbar presets.
 * Allows developers to programmatically save, load, and manage presets.
 */
export declare class ToolbarPresetsService {
    private internalService;
    /**
     * Get all saved presets as an Observable
     */
    getPresets(): Observable<ToolbarPreset[]>;
    /**
     * Save current toolbar state as a preset
     * @param name - Name for the preset
     * @param description - Optional description
     * @returns The created preset
     */
    savePreset(name: string, description?: string): ToolbarPreset;
    /**
     * Apply a preset (load its configuration into all tools)
     * @param presetId - ID of the preset to apply
     */
    applyPreset(presetId: string): Promise<void>;
    /**
     * Update a preset with current toolbar state
     * @param presetId - ID of the preset to update
     */
    updatePreset(presetId: string): void;
    /**
     * Delete a preset
     * @param presetId - ID of the preset to delete
     */
    deletePreset(presetId: string): void;
    /**
     * Toggle favorite status for a preset
     * @param presetId - ID of the preset to toggle
     */
    toggleFavorite(presetId: string): void;
    /**
     * Apply a preset with partial options (only selected categories)
     * @param presetId - ID of the preset to apply
     * @param options - Options for which categories to apply
     */
    partialApplyPreset(presetId: string, options: PartialApplyOptions): Promise<void>;
    /**
     * Update only the metadata (name, description) of a preset
     * @param presetId - ID of the preset to update
     * @param name - New name for the preset
     * @param description - New description for the preset
     */
    updatePresetMetadata(presetId: string, name: string, description?: string): void;
    /**
     * Export a preset as JSON string
     * @param presetId - ID of the preset to export
     * @returns JSON string representation of the preset
     */
    exportPreset(presetId: string): string | null;
    /**
     * Import a preset from JSON string
     * @param json - JSON string representation of a preset
     * @returns The imported preset
     * @throws Error if JSON is invalid
     */
    importPreset(json: string): ToolbarPreset;
    /**
     * Initialize presets with predefined configurations.
     * Useful for setting up default presets that all developers can use.
     * Skips presets that already exist (by name) to avoid duplicates.
     *
     * @param presets - Array of preset configurations to initialize
     * @returns Array of created presets (only newly added ones)
     *
     * @example
     * ```typescript
     * const presetsService = inject(ToolbarPresetsService);
     *
     * presetsService.initializePresets([
     *   {
     *     name: 'Admin User',
     *     description: 'Full access admin configuration',
     *     config: {
     *       featureFlags: {
     *         enabled: ['admin-panel', 'advanced-features'],
     *         disabled: []
     *       },
     *       permissions: {
     *         granted: ['admin', 'write', 'delete'],
     *         denied: []
     *       },
     *       appFeatures: {
     *         enabled: ['analytics', 'reporting'],
     *         disabled: []
     *       },
     *       language: 'en'
     *     }
     *   },
     *   {
     *     name: 'Read-Only User',
     *     description: 'Limited access for viewing only',
     *     config: {
     *       featureFlags: {
     *         enabled: [],
     *         disabled: ['admin-panel', 'advanced-features']
     *       },
     *       permissions: {
     *         granted: ['read'],
     *         denied: ['write', 'delete']
     *       },
     *       appFeatures: {
     *         enabled: [],
     *         disabled: ['analytics', 'reporting']
     *       },
     *       language: null
     *     }
     *   }
     * ]);
     * ```
     */
    initializePresets(presets: InitialPreset[]): ToolbarPreset[];
    /**
     * Clear all existing presets and set new initial presets.
     * Use this to replace all presets with a fresh set of configurations.
     *
     * @param presets - Array of preset configurations to set as initial
     * @returns Array of created presets
     */
    setInitialPresets(presets: InitialPreset[]): ToolbarPreset[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarPresetsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToolbarPresetsService>;
}
