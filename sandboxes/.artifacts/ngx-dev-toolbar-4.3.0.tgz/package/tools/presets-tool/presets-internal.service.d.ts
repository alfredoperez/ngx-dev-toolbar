import { Observable } from 'rxjs';
import { ToolbarPreset, PresetCategoryOptions, PartialApplyOptions } from './presets.models';
import * as i0 from "@angular/core";
/**
 * Internal service for managing presets state.
 * Handles CRUD operations, captures current toolbar config, and applies presets.
 */
export declare class ToolbarInternalPresetsService {
    private readonly STORAGE_KEY;
    private storageService;
    private featureFlagsService;
    private permissionsService;
    private appFeaturesService;
    private i18nService;
    private presetsSubject;
    presets$: Observable<ToolbarPreset[]>;
    presets: import("@angular/core").Signal<ToolbarPreset[]>;
    constructor();
    /**
     * Capture current toolbar state as a new preset
     */
    saveCurrentAsPreset(name: string, description?: string, categoryOptions?: PresetCategoryOptions): ToolbarPreset;
    /**
     * Apply a preset to all tools (THIS IS THE KEY METHOD)
     */
    applyPreset(presetId: string): Promise<void>;
    /**
     * Update an existing preset with current toolbar state
     */
    updatePreset(presetId: string): void;
    /**
     * Delete a preset
     */
    deletePreset(presetId: string): void;
    /**
     * Add a preset (used for import)
     */
    addPreset(preset: ToolbarPreset): ToolbarPreset;
    /**
     * Get a preset by ID
     */
    getPresetById(presetId: string): ToolbarPreset | undefined;
    /**
     * Toggle favorite status for a preset
     */
    toggleFavorite(presetId: string): void;
    /**
     * Apply a preset with partial options (only selected categories)
     */
    partialApplyPreset(presetId: string, options: PartialApplyOptions): Promise<void>;
    /**
     * Update only the metadata (name, description) of a preset without changing config
     */
    updatePresetMetadata(presetId: string, name: string, description?: string): void;
    /**
     * Capture current configuration from all tools
     */
    private captureCurrentConfig;
    /**
     * Load presets from localStorage
     */
    private loadPresets;
    /**
     * Generate unique preset ID
     */
    private generateId;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarInternalPresetsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToolbarInternalPresetsService>;
}
