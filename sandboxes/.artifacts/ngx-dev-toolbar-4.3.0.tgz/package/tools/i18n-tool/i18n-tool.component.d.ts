import { ToolbarWindowOptions } from '../../components/toolbar-tool/toolbar-tool.models';
import { I18nToolConfig } from './i18n.models';
import * as i0 from "@angular/core";
export declare class ToolbarI18nToolComponent {
    private readonly i18nService;
    protected readonly options: ToolbarWindowOptions;
    readonly unitSystemOptions: {
        value: string;
        label: string;
    }[];
    readonly dateFormatOptions: {
        value: string;
        label: string;
    }[];
    readonly firstDayOptions: {
        value: string;
        label: string;
    }[];
    readonly numberFormatOptions: {
        value: string;
        label: string;
    }[];
    activeLocale: import("@angular/core").WritableSignal<string>;
    activeTimezone: import("@angular/core").WritableSignal<string>;
    activeCurrency: import("@angular/core").WritableSignal<string>;
    activeUnitSystem: import("@angular/core").WritableSignal<string>;
    activeDateFormat: import("@angular/core").WritableSignal<string>;
    activeFirstDayOfWeek: import("@angular/core").WritableSignal<string>;
    activeNumberFormat: import("@angular/core").WritableSignal<string>;
    pseudoLocEnabled: import("@angular/core").Signal<boolean>;
    rtlEnabled: import("@angular/core").Signal<boolean>;
    toolConfig: import("@angular/core").Signal<I18nToolConfig>;
    hasAdvancedFormatSettings: import("@angular/core").Signal<boolean>;
    localeOptions: import("@angular/core").Signal<{
        value: string;
        label: string;
    }[]>;
    timezoneOptions: import("@angular/core").Signal<{
        value: string;
        label: string;
    }[]>;
    currencyOptions: import("@angular/core").Signal<{
        value: string;
        label: string;
    }[]>;
    private currentLocaleCode;
    private currentTimezone;
    private currentCurrencyCode;
    private readonly previewDate_;
    previewNumber: import("@angular/core").Signal<string>;
    previewDate: import("@angular/core").Signal<string>;
    previewTime: import("@angular/core").Signal<string>;
    previewCurrencyValue: import("@angular/core").Signal<string>;
    pseudoPreview: import("@angular/core").Signal<string>;
    constructor();
    onLocaleChange(localeId: string): void;
    onTimezoneChange(timezoneId: string): void;
    onCurrencyChange(currencyCode: string): void;
    onUnitSystemChange(unitSystem: string): void;
    onPseudoLocToggle(event: Event): void;
    onRtlToggle(event: Event): void;
    onDateFormatChange(value: string): void;
    onFirstDayOfWeekChange(value: string): void;
    onNumberFormatChange(value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarI18nToolComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarI18nToolComponent, "ndt-i18n-tool", never, {}, {}, never, never, true, never>;
}
