import { Observable } from 'rxjs';
import { ToolbarService } from '../../models/toolbar.interface';
import { I18nCurrency, I18nDateFormat, I18nFirstDayOfWeek, I18nLocale, I18nNumberFormat, I18nTimezone, I18nToolConfig, I18nUnitSystem } from './i18n.models';
import * as i0 from "@angular/core";
export declare class ToolbarI18nService implements ToolbarService<I18nLocale> {
    private internalService;
    /**
     * Sets the available locales displayed in the i18n tool
     */
    setAvailableOptions(locales: I18nLocale[]): void;
    /**
     * Gets the locale that was forced through the i18n tool
     * @returns Observable of forced locale array (single item or empty)
     */
    getForcedValues(): Observable<I18nLocale[]>;
    /**
     * Gets the forced locale value.
     * For the i18n tool, this returns the same as getForcedValues() since
     * only one locale can be selected at a time.
     */
    getValues(): Observable<I18nLocale[]>;
    /**
     * Sets the available timezones displayed in the i18n tool.
     * If not called, defaults to a built-in list of common timezones.
     */
    setAvailableTimezones(timezones: I18nTimezone[]): void;
    /**
     * Sets the available currencies displayed in the i18n tool.
     * If not called, defaults to a built-in list of common currencies.
     */
    setAvailableCurrencies(currencies: I18nCurrency[]): void;
    /**
     * Gets the timezone that was forced through the i18n tool
     */
    getForcedTimezone(): Observable<I18nTimezone | null>;
    /**
     * Gets the currency that was forced through the i18n tool
     */
    getForcedCurrency(): Observable<I18nCurrency | null>;
    /**
     * Gets the unit system that was forced through the i18n tool
     */
    getUnitSystem(): Observable<I18nUnitSystem | null>;
    /**
     * Whether pseudo-localization mode is enabled
     */
    isPseudoLocalizationEnabled(): Observable<boolean>;
    /**
     * Whether RTL mirroring is enabled
     */
    isRtlEnabled(): Observable<boolean>;
    /**
     * Gets the date format that was forced through the i18n tool
     */
    getForcedDateFormat(): Observable<I18nDateFormat | null>;
    /**
     * Gets the first day of week that was forced through the i18n tool
     */
    getForcedFirstDayOfWeek(): Observable<I18nFirstDayOfWeek | null>;
    /**
     * Gets the number format that was forced through the i18n tool
     */
    getForcedNumberFormat(): Observable<I18nNumberFormat | null>;
    /**
     * Configures which sections are visible in the i18n tool panel
     */
    configure(config: I18nToolConfig): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarI18nService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToolbarI18nService>;
}
