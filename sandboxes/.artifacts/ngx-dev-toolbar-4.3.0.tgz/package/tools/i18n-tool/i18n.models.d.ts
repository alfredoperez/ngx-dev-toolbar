export interface I18nLocale {
    id: string;
    name: string;
    code: string;
}
export interface I18nTimezone {
    id: string;
    name: string;
    offset: string;
}
export interface I18nCurrency {
    code: string;
    name: string;
    symbol: string;
}
export type I18nUnitSystem = 'metric' | 'imperial';
export type I18nDateFormat = 'locale-default' | 'MM/DD/YYYY' | 'DD/MM/YYYY' | 'YYYY-MM-DD';
export type I18nFirstDayOfWeek = 'locale-default' | 'sunday' | 'monday' | 'saturday';
export type I18nNumberFormat = 'locale-default' | 'period-comma' | 'comma-period' | 'space-comma';
export interface I18nState {
    locale: I18nLocale | null;
    timezone: I18nTimezone | null;
    currency: I18nCurrency | null;
    unitSystem: I18nUnitSystem | null;
    dateFormat: I18nDateFormat | null;
    firstDayOfWeek: I18nFirstDayOfWeek | null;
    numberFormat: I18nNumberFormat | null;
    pseudoLocEnabled: boolean;
    rtlEnabled: boolean;
}
export interface I18nPresetConfig {
    locale?: string | null;
    timezone?: string | null;
    currency?: string | null;
    unitSystem?: string | null;
    dateFormat?: string | null;
    firstDayOfWeek?: string | null;
    numberFormat?: string | null;
    pseudoLocEnabled?: boolean;
    rtlEnabled?: boolean;
}
export interface I18nToolConfig {
    showLocale?: boolean;
    showTimezone?: boolean;
    showCurrency?: boolean;
    showUnits?: boolean;
    showDateFormat?: boolean;
    showFirstDayOfWeek?: boolean;
    showNumberFormat?: boolean;
    showFormattingPreview?: boolean;
    showStressTesting?: boolean;
}
export declare const DEFAULT_TIMEZONES: I18nTimezone[];
export declare const DEFAULT_CURRENCIES: I18nCurrency[];
export declare const CURRENCY_SYMBOLS: Record<string, string>;
