import { Observable } from 'rxjs';
import { ApplyToSourceState } from '../../models/toolbar.interface';
import { ToolbarPermission, ForcedPermissionsState } from './permissions.models';
import * as i0 from "@angular/core";
export declare class ToolbarInternalPermissionsService {
    private readonly STORAGE_KEY;
    private storageService;
    private stateService;
    private appPermissions$;
    private forcedStateSubject;
    private readonly forcedState$;
    permissions$: Observable<ToolbarPermission[]>;
    permissions: import("@angular/core").Signal<ToolbarPermission[]>;
    constructor();
    setAppPermissions(permissions: ToolbarPermission[]): void;
    setPermission(id: string, granted: boolean): void;
    removePermissionOverride(id: string): void;
    getForcedPermissions(): Observable<ToolbarPermission[]>;
    /**
     * Apply a preset permissions state, replacing the current forced state.
     * Useful for automated testing or restoring saved configurations.
     * @param state The preset forced permissions state to apply
     */
    applyPresetPermissions(state: ForcedPermissionsState): void;
    /**
     * Get the current forced permissions state.
     * Returns a deep copy to prevent external mutations.
     * @returns Current forced permissions state
     */
    getCurrentForcedState(): ForcedPermissionsState;
    private loadForcedState;
    private isValidForcedState;
    readonly applyCallback: import("@angular/core").WritableSignal<((id: string, value: boolean) => Promise<void>) | null>;
    readonly applyStates: import("@angular/core").WritableSignal<Record<string, ApplyToSourceState>>;
    readonly hasApplyCallback: import("@angular/core").Signal<boolean>;
    setApplyToSource(callback: (id: string, value: boolean) => Promise<void>): void;
    applyToSource(id: string, value: boolean): Promise<void>;
    private validateAndCleanForcedState;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarInternalPermissionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToolbarInternalPermissionsService>;
}
