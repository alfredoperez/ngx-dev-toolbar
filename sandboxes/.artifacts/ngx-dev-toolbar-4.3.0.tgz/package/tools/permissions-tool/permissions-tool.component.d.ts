import { ToolbarWindowOptions } from '../../components/toolbar-tool/toolbar-tool.models';
import { PermissionFilter, ToolbarPermission } from './permissions.models';
import * as i0 from "@angular/core";
export declare class ToolbarPermissionsToolComponent {
    private readonly permissionsService;
    private readonly storageService;
    private readonly VIEW_STATE_KEY;
    protected readonly activeFilter: import("@angular/core").WritableSignal<PermissionFilter>;
    protected readonly searchQuery: import("@angular/core").WritableSignal<string>;
    protected readonly pinnedIds: import("@angular/core").WritableSignal<Set<string>>;
    protected readonly collapsedGroups: import("@angular/core").WritableSignal<Set<string>>;
    constructor();
    private loadViewState;
    protected readonly permissions: import("@angular/core").Signal<ToolbarPermission[]>;
    protected readonly badgeCount: import("@angular/core").Signal<string>;
    protected readonly hasNoPermissions: import("@angular/core").Signal<boolean>;
    private readonly filteredPermissions;
    protected readonly groupedPermissions: import("@angular/core").Signal<import("../../utils/group-items.util").GroupedItems<ToolbarPermission>>;
    protected readonly flatPermissions: import("@angular/core").Signal<ToolbarPermission[]>;
    protected readonly hasAnyGroups: import("@angular/core").Signal<boolean>;
    protected readonly hasNoFilteredPermissions: import("@angular/core").Signal<boolean>;
    protected readonly options: ToolbarWindowOptions;
    protected readonly filterOptions: {
        value: string;
        label: string;
    }[];
    protected readonly permissionValueOptions: {
        value: string;
        label: string;
    }[];
    protected readonly hasApplyCallback: import("@angular/core").Signal<boolean>;
    protected getApplyState(permissionId: string): 'idle' | 'loading' | 'success' | 'error';
    protected onApplyToSource(permissionId: string, value: boolean): void;
    onFilterChange(value: string | undefined): void;
    onPermissionChange(id: string, value: string): void;
    onSearchChange(query: string): void;
    togglePin(permissionId: string): void;
    protected isCollapsed(name: string): boolean;
    protected setCollapsed(name: string, collapsed: boolean): void;
    protected getPermissionValue(permission: ToolbarPermission): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarPermissionsToolComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarPermissionsToolComponent, "ndt-permissions-tool", never, {}, {}, never, never, true, never>;
}
