export declare function wait(ms: number): Promise<void>;
export declare function nounSingular(plural: string): string;
