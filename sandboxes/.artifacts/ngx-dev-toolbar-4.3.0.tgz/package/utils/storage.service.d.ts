import * as i0 from "@angular/core";
export declare class ToolbarStorageService {
    private readonly PREFIX;
    private readonly TOOLS_KEY;
    private readonly SETTINGS_KEY;
    set<T>(key: string, value: T): void;
    get<T>(key: string): T | null;
    remove(key: string): void;
    getAllSettings(): Record<string, unknown>;
    setAllSettings(settings: Record<string, unknown>): void;
    clearAllSettings(): void;
    getToolKeys(): string[];
    private addToolKey;
    private removeToolKey;
    private getToolKey;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToolbarStorageService>;
}
