import { ConnectedPosition } from '@angular/cdk/overlay';
import { ToolbarStateService } from '../../toolbar-state.service';
import * as i0 from "@angular/core";
export interface SelectOption {
    value: string;
    label: string;
}
export declare class ToolbarSelectComponent {
    private readonly elementRef;
    readonly devToolbarStateService: ToolbarStateService;
    value: import("@angular/core").ModelSignal<string | undefined>;
    options: import("@angular/core").InputSignal<SelectOption[]>;
    ariaLabel: import("@angular/core").InputSignal<string>;
    label: import("@angular/core").InputSignal<string>;
    size: import("@angular/core").InputSignal<"small" | "medium">;
    placeholder: import("@angular/core").InputSignal<string>;
    readonly theme: import("@angular/core").Signal<"light" | "dark">;
    protected readonly selectMenuId: string;
    isOpen: import("@angular/core").WritableSignal<boolean>;
    triggerWidth: import("@angular/core").WritableSignal<number>;
    isPlaceholder: import("@angular/core").Signal<boolean>;
    selectedLabel: import("@angular/core").Signal<string>;
    positions: ConnectedPosition[];
    toggle(): void;
    close(): void;
    selectOption(option: SelectOption): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarSelectComponent, "ndt-select", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
