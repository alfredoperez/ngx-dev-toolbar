import * as i0 from "@angular/core";
export declare class ToolbarConfirmDialogComponent {
    title: import("@angular/core").InputSignal<string>;
    message: import("@angular/core").InputSignal<string>;
    confirmLabel: import("@angular/core").InputSignal<string>;
    cancelLabel: import("@angular/core").InputSignal<string>;
    danger: import("@angular/core").InputSignal<boolean>;
    confirmed: import("@angular/core").OutputEmitterRef<void>;
    cancelled: import("@angular/core").OutputEmitterRef<void>;
    private readonly dialogRef;
    private result;
    show(): void;
    confirm(): void;
    cancel(): void;
    protected onBackdropClick(event: MouseEvent): void;
    protected onDialogClose(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarConfirmDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarConfirmDialogComponent, "ndt-confirm-dialog", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "confirmLabel": { "alias": "confirmLabel"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "danger": { "alias": "danger"; "required": false; "isSignal": true; }; }, { "confirmed": "confirmed"; "cancelled": "cancelled"; }, never, never, true, never>;
}
