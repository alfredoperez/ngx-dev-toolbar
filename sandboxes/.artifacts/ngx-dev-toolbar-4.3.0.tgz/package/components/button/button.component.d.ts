import { IconName } from '../icons/icon.models';
import * as i0 from "@angular/core";
export declare class ToolbarButtonComponent {
    readonly type: import("@angular/core").InputSignal<"button" | "submit" | "reset">;
    readonly variant: import("@angular/core").InputSignal<"default" | "icon">;
    readonly icon: import("@angular/core").InputSignal<IconName | undefined>;
    readonly label: import("@angular/core").InputSignal<string | undefined>;
    readonly ariaLabel: import("@angular/core").InputSignal<string | undefined>;
    readonly isActive: import("@angular/core").InputSignal<boolean>;
    readonly disabled: import("@angular/core").InputSignal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarButtonComponent, "ndt-button", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "isActive": { "alias": "isActive"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
