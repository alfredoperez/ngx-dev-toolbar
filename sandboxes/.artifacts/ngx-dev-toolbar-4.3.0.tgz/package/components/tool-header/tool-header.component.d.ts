import * as i0 from "@angular/core";
export interface ToolHeaderFilterOption {
    value: string;
    label: string;
    ariaLabel?: string;
}
export declare class ToolbarToolHeaderComponent {
    searchQuery: import("@angular/core").ModelSignal<string>;
    activeFilter: import("@angular/core").ModelSignal<string>;
    searchPlaceholder: import("@angular/core").InputSignal<string>;
    searchAriaLabel: import("@angular/core").InputSignal<string>;
    filterOptions: import("@angular/core").InputSignal<ToolHeaderFilterOption[]>;
    filterAriaLabel: import("@angular/core").InputSignal<string>;
    protected clearSearch(): void;
    protected onFilterClick(value: string): void;
    protected onFilterKeydown(event: KeyboardEvent, value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarToolHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarToolHeaderComponent, "ndt-tool-header", never, { "searchQuery": { "alias": "searchQuery"; "required": false; "isSignal": true; }; "activeFilter": { "alias": "activeFilter"; "required": false; "isSignal": true; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; "isSignal": true; }; "searchAriaLabel": { "alias": "searchAriaLabel"; "required": false; "isSignal": true; }; "filterOptions": { "alias": "filterOptions"; "required": false; "isSignal": true; }; "filterAriaLabel": { "alias": "filterAriaLabel"; "required": false; "isSignal": true; }; }, { "searchQuery": "searchQueryChange"; "activeFilter": "activeFilterChange"; }, never, never, true, never>;
}
