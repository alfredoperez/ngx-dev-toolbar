import { ToolbarStateService } from '../../toolbar-state.service';
import { ToolbarWindowOptions } from '../toolbar-tool/toolbar-tool.models';
import * as i0 from "@angular/core";
export declare class ToolbarWindowComponent {
    readonly devToolbarStateService: ToolbarStateService;
    readonly config: import("@angular/core").InputSignal<ToolbarWindowOptions>;
    readonly closed: import("@angular/core").OutputEmitterRef<void>;
    readonly maximize: import("@angular/core").OutputEmitterRef<void>;
    readonly minimize: import("@angular/core").OutputEmitterRef<void>;
    readonly theme: import("@angular/core").Signal<"light" | "dark">;
    readonly isCompact: import("@angular/core").Signal<boolean>;
    protected onClose(): void;
    protected onMaximize(): void;
    protected onMinimize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarWindowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarWindowComponent, "ndt-window", never, { "config": { "alias": "config"; "required": true; "isSignal": true; }; }, { "closed": "closed"; "maximize": "maximize"; "minimize": "minimize"; }, never, ["*"], true, never>;
}
