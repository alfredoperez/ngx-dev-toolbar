import { ToolbarStepDirective } from './step-view.directive';
import * as i0 from "@angular/core";
export declare class ToolbarStepViewComponent {
    readonly currentStep: import("@angular/core").InputSignal<string>;
    readonly defaultStep: import("@angular/core").InputSignal<string>;
    readonly back: import("@angular/core").OutputEmitterRef<void>;
    readonly steps: import("@angular/core").Signal<readonly ToolbarStepDirective[]>;
    readonly isDefaultStep: import("@angular/core").Signal<boolean>;
    readonly activeStep: import("@angular/core").Signal<ToolbarStepDirective | undefined>;
    readonly activeTitle: import("@angular/core").Signal<string>;
    readonly activeTemplate: import("@angular/core").Signal<import("@angular/core").TemplateRef<any> | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarStepViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarStepViewComponent, "ndt-step-view", never, { "currentStep": { "alias": "currentStep"; "required": true; "isSignal": true; }; "defaultStep": { "alias": "defaultStep"; "required": false; "isSignal": true; }; }, { "back": "back"; }, ["steps"], never, true, never>;
}
