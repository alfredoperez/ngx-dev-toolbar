import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ToolbarStepDirective {
    readonly ndtStep: import("@angular/core").InputSignal<string>;
    readonly stepTitle: import("@angular/core").InputSignal<string>;
    readonly templateRef: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarStepDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarStepDirective, "[ndtStep]", never, { "ndtStep": { "alias": "ndtStep"; "required": true; "isSignal": true; }; "stepTitle": { "alias": "stepTitle"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
