import { IconName } from '../icons/icon.models';
import * as i0 from "@angular/core";
export declare class ToolbarClickableCardComponent {
    readonly icon: import("@angular/core").InputSignal<IconName>;
    readonly title: import("@angular/core").InputSignal<string>;
    readonly subtitle: import("@angular/core").InputSignal<string>;
    readonly click: import("@angular/core").WritableSignal<void>;
    onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarClickableCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarClickableCardComponent, "ndt-clickable-card", never, { "icon": { "alias": "icon"; "required": true; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
