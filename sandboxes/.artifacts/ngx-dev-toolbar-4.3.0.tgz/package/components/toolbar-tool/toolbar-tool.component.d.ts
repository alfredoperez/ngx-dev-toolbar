import { ConnectedPosition } from '@angular/cdk/overlay';
import { ElementRef } from '@angular/core';
import { ToolbarStateService } from '../../toolbar-state.service';
import { IconName } from '../icons/icon.models';
import { ToolbarToolButtonComponent } from '../tool-button/tool-button.component';
import { ToolbarWindowOptions } from './toolbar-tool.models';
import * as i0 from "@angular/core";
export declare class ToolbarToolComponent {
    state: ToolbarStateService;
    buttonContainer: import("@angular/core").Signal<ElementRef<any>>;
    buttonComponent: import("@angular/core").Signal<ToolbarToolButtonComponent | undefined>;
    options: import("@angular/core").InputSignal<ToolbarWindowOptions>;
    icon: import("@angular/core").InputSignal<IconName>;
    toolTitle: import("@angular/core").InputSignal<string>;
    badge: import("@angular/core").InputSignal<string | undefined>;
    isActive: import("@angular/core").Signal<boolean>;
    slideDirection: import("@angular/core").Signal<"right" | "left" | "up" | "down">;
    height: import("@angular/core").Signal<number>;
    width: import("@angular/core").Signal<420 | 320 | 480 | 620 | 400>;
    positions: import("@angular/core").Signal<ConnectedPosition[]>;
    onOpen(): void;
    onClose(): void;
    private getButtonContainerRect;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarToolComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarToolComponent, "ndt-toolbar-tool", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "icon": { "alias": "icon"; "required": true; "isSignal": true; }; "toolTitle": { "alias": "toolTitle"; "required": true; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; }, {}, ["buttonComponent"], ["ndt-tool-button", "*"], true, never>;
}
