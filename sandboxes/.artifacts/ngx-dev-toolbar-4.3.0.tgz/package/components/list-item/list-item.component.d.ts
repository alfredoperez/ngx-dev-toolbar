import { IconName } from '../icons/icon.models';
import * as i0 from "@angular/core";
/**
 * List item component with consistent layout, dot badge indicator,
 * and forced state highlighting.
 *
 * @example
 * ```html
 * <ndt-list-item
 *   title="Analytics Dashboard"
 *   description="Advanced reporting tools"
 *   [isForced]="false"
 *   [currentValue]="true"
 *   [originalValue]="undefined"
 * >
 *   <ndt-select ... />
 * </ndt-list-item>
 * ```
 */
export declare class ToolbarListItemComponent {
    /**
     * Display title for the list item
     * @example "Analytics Dashboard"
     */
    title: import("@angular/core").InputSignal<string>;
    /**
     * Optional description text
     * @example "Advanced reporting and data visualization tools"
     */
    description: import("@angular/core").InputSignal<string | undefined>;
    /**
     * Whether this item's state is forced via the dev toolbar
     */
    isForced: import("@angular/core").InputSignal<boolean>;
    /**
     * Current enabled/granted state of the item
     */
    currentValue: import("@angular/core").InputSignal<boolean>;
    /**
     * Original value before forcing (only present when isForced is true)
     */
    originalValue: import("@angular/core").InputSignal<boolean | undefined>;
    /**
     * Whether to show the "Apply to source" button
     */
    showApply: import("@angular/core").InputSignal<boolean>;
    /**
     * Current state of the apply operation
     */
    applyState: import("@angular/core").InputSignal<"idle" | "loading" | "success" | "error">;
    /**
     * Whether this item is pinned to the top of the list
     */
    isPinned: import("@angular/core").InputSignal<boolean>;
    /**
     * Optional identifier that can be copied to clipboard (e.g., flag ID).
     * When provided, renders a copy button in the action row.
     */
    copyableId: import("@angular/core").InputSignal<string | undefined>;
    /**
     * Emits when the user clicks the pin/unpin button
     */
    pinToggle: import("@angular/core").OutputEmitterRef<void>;
    /**
     * Emits when the user clicks "Apply to source"
     */
    applyToSource: import("@angular/core").OutputEmitterRef<void>;
    protected pinIcon: import("@angular/core").Signal<IconName>;
    protected pinAriaLabel: import("@angular/core").Signal<"Unpin item" | "Pin item">;
    /**
     * Source-of-truth value for the dot indicator. When an item is forced and the
     * upstream original value is known, surface that; otherwise fall back to
     * currentValue. Decouples the dot color from the developer's override so the
     * server-reported state remains visible at a glance.
     */
    protected sourceValue: import("@angular/core").Signal<boolean>;
    /**
     * Tooltip text explaining the current state, with override context when forced
     */
    protected tooltipText: import("@angular/core").Signal<string>;
    protected statusAriaLabel: import("@angular/core").Signal<string>;
    protected readonly copyState: import("@angular/core").WritableSignal<"idle" | "copied">;
    protected copyAriaLabel: import("@angular/core").Signal<string>;
    protected copyId(event: MouseEvent): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarListItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarListItemComponent, "ndt-list-item", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "isForced": { "alias": "isForced"; "required": false; "isSignal": true; }; "currentValue": { "alias": "currentValue"; "required": true; "isSignal": true; }; "originalValue": { "alias": "originalValue"; "required": false; "isSignal": true; }; "showApply": { "alias": "showApply"; "required": false; "isSignal": true; }; "applyState": { "alias": "applyState"; "required": false; "isSignal": true; }; "isPinned": { "alias": "isPinned"; "required": false; "isSignal": true; }; "copyableId": { "alias": "copyableId"; "required": false; "isSignal": true; }; }, { "pinToggle": "pinToggle"; "applyToSource": "applyToSource"; }, never, ["*"], true, never>;
}
