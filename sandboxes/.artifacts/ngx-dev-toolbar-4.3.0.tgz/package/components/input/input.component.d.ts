import * as i0 from "@angular/core";
export declare class ToolbarInputComponent {
    value: import("@angular/core").ModelSignal<string>;
    type: import("@angular/core").InputSignal<string>;
    placeholder: import("@angular/core").InputSignal<string>;
    ariaLabel: import("@angular/core").InputSignal<string>;
    inputClass: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarInputComponent, "ndt-input", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "inputClass": { "alias": "inputClass"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}
