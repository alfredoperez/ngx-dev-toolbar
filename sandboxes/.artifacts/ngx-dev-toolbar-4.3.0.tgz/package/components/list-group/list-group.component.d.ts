import * as i0 from "@angular/core";
/**
 * Collapsible group header that wraps a section of list items.
 *
 * Renders a clickable header with the group name + item count + a chevron
 * indicating collapsed/expanded state. Children projected via `<ng-content>`
 * are hidden when collapsed.
 *
 * @example
 * ```html
 * <ndt-list-group
 *   name="Authentication"
 *   [count]="3"
 *   [collapsed]="isCollapsed"
 *   (collapsedChange)="onToggle($event)"
 * >
 *   <ndt-list-item ... />
 * </ndt-list-group>
 * ```
 */
export declare class ToolbarListGroupComponent {
    /** Display name of the group, shown in the header. */
    name: import("@angular/core").InputSignal<string>;
    /** Number of items in the group, shown next to the name. */
    count: import("@angular/core").InputSignal<number>;
    /** Whether the group is currently collapsed. */
    collapsed: import("@angular/core").InputSignal<boolean>;
    /** Emits the new collapsed value when the user clicks the header. */
    collapsedChange: import("@angular/core").OutputEmitterRef<boolean>;
    protected ariaLabel: import("@angular/core").Signal<string>;
    protected toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarListGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarListGroupComponent, "ndt-list-group", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "count": { "alias": "count"; "required": true; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; }, { "collapsedChange": "collapsedChange"; }, never, ["*"], true, never>;
}
