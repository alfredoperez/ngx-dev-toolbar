import { IconName } from '../icons/icon.models';
import * as i0 from "@angular/core";
export declare class ToolbarLinkButtonComponent {
    readonly url: import("@angular/core").InputSignal<string>;
    readonly icon: import("@angular/core").InputSignal<IconName | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarLinkButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarLinkButtonComponent, "ndt-link-button", never, { "url": { "alias": "url"; "required": true; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
