import * as i0 from "@angular/core";
/**
 * Container component for displaying lists of items with consistent scrolling,
 * empty states, and layout across all tools.
 *
 * @example
 * ```html
 * <ndt-list
 *   [hasItems]="items().length > 0"
 *   [hasResults]="filteredItems().length > 0"
 *   emptyMessage="No items found"
 *   noResultsMessage="No items match your filter"
 * >
 *   @for (item of filteredItems(); track item.id) {
 *     <ndt-list-item ... />
 *   }
 * </ndt-list>
 * ```
 */
export declare class ToolbarListComponent {
    /**
     * Whether the list has any items at all (before filtering).
     * When false, shows the emptyMessage.
     */
    hasItems: import("@angular/core").InputSignal<boolean>;
    /**
     * Whether the list has any results after filtering.
     * When false (but hasItems is true), shows the noResultsMessage.
     */
    hasResults: import("@angular/core").InputSignal<boolean>;
    /**
     * Message to display when there are no items at all.
     * @example "No feature flags found"
     */
    emptyMessage: import("@angular/core").InputSignal<string>;
    /**
     * Optional hint text to display below the empty message.
     * @example "Call setAvailableOptions() to configure features"
     */
    emptyHint: import("@angular/core").InputSignal<string | undefined>;
    /**
     * Message to display when items exist but none match the current filter.
     * @example "No flags match your filter"
     */
    noResultsMessage: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarListComponent, "ndt-list", never, { "hasItems": { "alias": "hasItems"; "required": false; "isSignal": true; }; "hasResults": { "alias": "hasResults"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "emptyHint": { "alias": "emptyHint"; "required": false; "isSignal": true; }; "noResultsMessage": { "alias": "noResultsMessage"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
