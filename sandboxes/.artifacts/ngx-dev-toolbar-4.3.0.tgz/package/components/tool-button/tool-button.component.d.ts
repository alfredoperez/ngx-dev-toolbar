import { ToolbarPosition } from '../../models/toolbar-position.model';
import * as i0 from "@angular/core";
export declare class ToolbarToolButtonComponent {
    private readonly state;
    readonly toolLabel: import("@angular/core").InputSignal<string>;
    readonly toolId: import("@angular/core").InputSignal<string>;
    readonly badge: import("@angular/core").InputSignal<string | undefined>;
    readonly position: import("@angular/core").InputSignal<ToolbarPosition>;
    readonly open: import("@angular/core").OutputEmitterRef<void>;
    readonly isActive: import("@angular/core").Signal<boolean>;
    readonly isToolbarVisible: import("@angular/core").Signal<boolean>;
    readonly isFocused: import("@angular/core").WritableSignal<boolean>;
    readonly tooltip: import("@angular/core").Signal<string>;
    readonly isTooltipVisible: import("@angular/core").Signal<boolean | "">;
    readonly tooltipDirection: import("@angular/core").Signal<"top" | "right" | "bottom" | "left">;
    protected readonly tooltipState: import("@angular/core").WritableSignal<boolean>;
    private readonly hideDelay;
    onClick(): void;
    onMouseEnter(): void;
    onMouseLeave(): void;
    onEscape(): void;
    onFocus(): void;
    onBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarToolButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarToolButtonComponent, "ndt-tool-button", never, { "toolLabel": { "alias": "toolLabel"; "required": true; "isSignal": true; }; "toolId": { "alias": "toolId"; "required": true; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; }, { "open": "open"; }, never, ["*"], true, never>;
}
