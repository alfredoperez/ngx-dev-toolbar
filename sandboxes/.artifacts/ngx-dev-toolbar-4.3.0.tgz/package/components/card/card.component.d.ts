import * as i0 from "@angular/core";
export declare class ToolbarCardComponent {
    readonly click: import("@angular/core").WritableSignal<void>;
    protected readonly isHovered: import("@angular/core").WritableSignal<boolean>;
    onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarCardComponent, "ndt-card", never, {}, {}, never, ["*"], true, never>;
}
