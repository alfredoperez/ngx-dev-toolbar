import { ToolbarTabComponent } from './tab.component';
import * as i0 from "@angular/core";
export declare class ToolbarTabsComponent {
    readonly tabs: import("@angular/core").Signal<readonly ToolbarTabComponent[]>;
    readonly activeIndex: import("@angular/core").WritableSignal<number>;
    readonly activeIndexChange: import("@angular/core").OutputEmitterRef<number>;
    protected readonly instanceId: string;
    constructor();
    selectTab(index: number): void;
    onKeydown(event: KeyboardEvent, currentIndex: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarTabsComponent, "ndt-tabs", never, {}, { "activeIndexChange": "activeIndexChange"; }, ["tabs"], ["*"], true, never>;
}
