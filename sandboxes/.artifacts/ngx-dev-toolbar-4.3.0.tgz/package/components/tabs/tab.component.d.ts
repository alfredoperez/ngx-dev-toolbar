import * as i0 from "@angular/core";
export declare class ToolbarTabComponent {
    readonly label: import("@angular/core").InputSignal<string>;
    readonly isActive: import("@angular/core").WritableSignal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarTabComponent, "ndt-tab", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
