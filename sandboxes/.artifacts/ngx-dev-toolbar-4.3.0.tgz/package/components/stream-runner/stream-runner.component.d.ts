import { StreamItemRecord, StreamRunOptions, StreamRunResult, StreamStepRecord } from './stream-runner.models';
import * as i0 from "@angular/core";
export declare class ToolbarStreamRunnerComponent {
    private anchor?;
    readonly done: import("@angular/core").OutputEmitterRef<StreamRunResult>;
    readonly errored: import("@angular/core").OutputEmitterRef<{
        stepIndex: number;
        itemIndex: number;
        error: string;
    }>;
    private readonly _records;
    private readonly _visibleCount;
    private readonly _title;
    private readonly _preamble;
    private readonly _summary;
    private readonly _isRunning;
    private readonly _hasRun;
    private readonly _cancelled;
    protected readonly title: import("@angular/core").Signal<string>;
    protected readonly preamble: import("@angular/core").Signal<string | undefined>;
    protected readonly summary: import("@angular/core").Signal<string | undefined>;
    protected readonly isIdle: import("@angular/core").Signal<boolean>;
    readonly isRunning: import("@angular/core").Signal<boolean>;
    protected readonly visibleRecords: import("@angular/core").Signal<StreamStepRecord[]>;
    private prefersReducedMotion;
    /** Imperative entry point: kicks off a streaming run. */
    start(options: StreamRunOptions): Promise<StreamRunResult>;
    /** Reset to the empty/idle state. Also cancels any in-flight run. */
    reset(): void;
    private isCancelled;
    protected toggleExpanded(record: StreamStepRecord): void;
    protected canExpand(record: StreamStepRecord): boolean;
    protected stepVerb(record: StreamStepRecord): string;
    protected stepNoun(record: StreamStepRecord): string;
    protected itemVerb(record: StreamStepRecord, item: StreamItemRecord): string;
    protected itemName(record: StreamStepRecord, item: StreamItemRecord): string;
    protected itemDetail(record: StreamStepRecord, item: StreamItemRecord): string | null;
    protected shouldShowItems(record: StreamStepRecord): boolean;
    protected visibleItems(record: StreamStepRecord): StreamItemRecord[];
    protected hiddenItemCount(record: StreamStepRecord): number;
    private updateRecord;
    private updateItem;
    private scrollToActive;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarStreamRunnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarStreamRunnerComponent, "ndt-stream-runner", never, {}, { "done": "done"; "errored": "errored"; }, never, ["*"], true, never>;
}
