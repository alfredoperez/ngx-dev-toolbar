import * as i0 from "@angular/core";
export declare class EditIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditIconComponent, "ndt-edit-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
