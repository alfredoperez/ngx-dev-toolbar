import * as i0 from "@angular/core";
export declare class LightingIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LightingIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LightingIconComponent, "ndt-lighting-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
