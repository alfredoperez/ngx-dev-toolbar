import * as i0 from "@angular/core";
export declare class DatabaseIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatabaseIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatabaseIconComponent, "ndt-database-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
