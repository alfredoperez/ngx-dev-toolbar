import * as i0 from "@angular/core";
export declare class BugIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BugIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BugIconComponent, "ndt-bug-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
