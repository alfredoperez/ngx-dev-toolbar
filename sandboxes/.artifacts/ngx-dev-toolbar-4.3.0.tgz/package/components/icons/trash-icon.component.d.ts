import * as i0 from "@angular/core";
export declare class TrashIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TrashIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TrashIconComponent, "ndt-trash-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
