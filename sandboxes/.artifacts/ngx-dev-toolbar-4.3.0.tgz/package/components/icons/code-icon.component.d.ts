import * as i0 from "@angular/core";
export declare class CodeIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CodeIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CodeIconComponent, "ndt-code-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
