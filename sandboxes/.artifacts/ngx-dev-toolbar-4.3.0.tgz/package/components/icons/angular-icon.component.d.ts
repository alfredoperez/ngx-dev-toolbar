import * as i0 from "@angular/core";
export declare class AngularIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<AngularIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AngularIconComponent, "ndt-angular-icon", never, {}, {}, never, never, true, never>;
}
