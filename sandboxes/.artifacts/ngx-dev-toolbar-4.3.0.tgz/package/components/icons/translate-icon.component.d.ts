import * as i0 from "@angular/core";
export declare class TranslateIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TranslateIconComponent, "ndt-translate-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
