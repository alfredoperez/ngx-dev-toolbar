import * as i0 from "@angular/core";
export declare class UsersIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UsersIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UsersIconComponent, "ndt-users-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
