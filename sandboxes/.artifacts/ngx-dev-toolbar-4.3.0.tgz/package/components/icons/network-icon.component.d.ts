import * as i0 from "@angular/core";
export declare class NetworkIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<NetworkIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NetworkIconComponent, "ndt-network-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
