import * as i0 from "@angular/core";
export declare class TerminalIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TerminalIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TerminalIconComponent, "ndt-terminal-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
