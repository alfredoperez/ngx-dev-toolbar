import { IconName } from './icon.models';
import * as i0 from "@angular/core";
export declare class ToolbarIconComponent {
    private readonly stateService;
    name: import("@angular/core").InputSignal<IconName>;
    fill: import("@angular/core").Signal<"#000000" | "#FFFFFF">;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarIconComponent, "ndt-icon", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
