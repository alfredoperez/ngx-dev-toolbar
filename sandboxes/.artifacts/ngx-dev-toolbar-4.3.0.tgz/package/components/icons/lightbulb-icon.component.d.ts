import * as i0 from "@angular/core";
export declare class LightbulbIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LightbulbIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LightbulbIconComponent, "ndt-lightbulb-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
