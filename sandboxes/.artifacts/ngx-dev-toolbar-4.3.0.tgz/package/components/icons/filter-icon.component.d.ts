import * as i0 from "@angular/core";
export declare class FilterIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterIconComponent, "ndt-filter-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
