import * as i0 from "@angular/core";
export declare class LayoutIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LayoutIconComponent, "ndt-layout-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
