import * as i0 from "@angular/core";
export declare class ExportIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ExportIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ExportIconComponent, "ndt-export-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
