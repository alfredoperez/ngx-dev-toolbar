import * as i0 from "@angular/core";
export declare class GearIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GearIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GearIconComponent, "ndt-gear-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
