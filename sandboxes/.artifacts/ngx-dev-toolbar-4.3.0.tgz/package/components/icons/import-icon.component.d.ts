import * as i0 from "@angular/core";
export declare class ImportIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImportIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImportIconComponent, "ndt-import-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
