import * as i0 from "@angular/core";
export declare class RefreshIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RefreshIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RefreshIconComponent, "ndt-refresh-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
