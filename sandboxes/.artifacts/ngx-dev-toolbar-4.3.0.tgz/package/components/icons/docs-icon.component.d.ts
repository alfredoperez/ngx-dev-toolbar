import * as i0 from "@angular/core";
export declare class DocsIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocsIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocsIconComponent, "ndt-docs-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
