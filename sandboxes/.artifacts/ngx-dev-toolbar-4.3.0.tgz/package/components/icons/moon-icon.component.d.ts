import * as i0 from "@angular/core";
export declare class MoonIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MoonIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MoonIconComponent, "ndt-moon-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
