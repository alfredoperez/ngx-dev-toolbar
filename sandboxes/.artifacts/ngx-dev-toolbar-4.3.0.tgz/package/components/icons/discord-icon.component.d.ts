import * as i0 from "@angular/core";
export declare class DiscordIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DiscordIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DiscordIconComponent, "ndt-discord-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
