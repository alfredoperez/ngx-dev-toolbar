import * as i0 from "@angular/core";
export declare class LockIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LockIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LockIconComponent, "ndt-lock-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
