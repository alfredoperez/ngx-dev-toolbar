import * as i0 from "@angular/core";
export declare class PuzzleIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PuzzleIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PuzzleIconComponent, "ndt-puzzle-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
