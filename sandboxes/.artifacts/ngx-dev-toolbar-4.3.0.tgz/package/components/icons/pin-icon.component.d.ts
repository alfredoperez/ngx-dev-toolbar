import * as i0 from "@angular/core";
export declare class PinIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PinIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PinIconComponent, "ndt-pin-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
