import * as i0 from "@angular/core";
export declare class GitBranchIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GitBranchIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GitBranchIconComponent, "ndt-git-branch-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
