import * as i0 from "@angular/core";
export declare class GlobeIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobeIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GlobeIconComponent, "ndt-globe-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
