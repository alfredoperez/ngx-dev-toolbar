import * as i0 from "@angular/core";
export declare class StarIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<StarIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StarIconComponent, "ndt-star-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
