import * as i0 from "@angular/core";
export declare class ToggleLeftIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToggleLeftIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToggleLeftIconComponent, "ndt-toggle-left-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
