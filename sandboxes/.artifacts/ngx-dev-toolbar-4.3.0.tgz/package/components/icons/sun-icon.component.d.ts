import * as i0 from "@angular/core";
export declare class SunIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SunIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SunIconComponent, "ndt-sun-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
