import * as i0 from "@angular/core";
export declare class GaugeIconComponent {
    fill: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GaugeIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GaugeIconComponent, "ndt-gauge-icon", never, { "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
