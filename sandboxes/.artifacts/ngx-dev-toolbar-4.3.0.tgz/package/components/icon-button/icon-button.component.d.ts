import { IconName } from '../icons/icon.models';
import * as i0 from "@angular/core";
export declare class ToolbarIconButtonComponent {
    readonly icon: import("@angular/core").InputSignal<IconName | undefined>;
    readonly tooltip: import("@angular/core").InputSignal<string | undefined>;
    readonly ariaLabel: import("@angular/core").InputSignal<string | undefined>;
    readonly size: import("@angular/core").InputSignal<"sm" | "md">;
    readonly variant: import("@angular/core").InputSignal<"ghost" | "outlined">;
    protected isHovered: import("@angular/core").WritableSignal<boolean>;
    protected isTooltipVisible: import("@angular/core").Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarIconButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarIconButtonComponent, "ndt-icon-button", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
