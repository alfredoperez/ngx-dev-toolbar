import { DestroyRef, OnDestroy, OnInit } from '@angular/core';
import { ToolbarStateService } from './toolbar-state.service';
import { ToolbarConfig } from './models/toolbar-config.interface';
import { SettingsService } from './tools/home-tool/settings.service';
import * as i0 from "@angular/core";
export declare class ToolbarComponent implements OnInit, OnDestroy {
    private document;
    state: ToolbarStateService;
    destroyRef: DestroyRef;
    settingsService: SettingsService;
    private customToolTypes;
    private customToolsContainer;
    config: import("@angular/core").InputSignal<ToolbarConfig>;
    private globalStyleElement?;
    private keyboardShortcut;
    private hideShortcut;
    private mouseLeave;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    onMouseEnter(): void;
    onMouseLeave(): void;
    private toggleDevTools;
    /**
     * Injects global theme styles into the document head to make CSS variables
     * available to CDK overlays and other elements rendered outside Shadow DOM.
     * Uses light theme only.
     */
    private injectGlobalStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarComponent, "ndt-toolbar", never, { "config": { "alias": "config"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
