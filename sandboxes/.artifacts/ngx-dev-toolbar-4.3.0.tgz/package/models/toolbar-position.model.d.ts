export type ToolbarPosition = 'top' | 'right' | 'bottom' | 'left' | 'sidebar-right' | 'sidebar-left';
export declare const TOOLBAR_POSITIONS: readonly ToolbarPosition[];
export declare function isHorizontalPosition(position: ToolbarPosition): boolean;
export declare function isSidebarPosition(position: ToolbarPosition): boolean;
